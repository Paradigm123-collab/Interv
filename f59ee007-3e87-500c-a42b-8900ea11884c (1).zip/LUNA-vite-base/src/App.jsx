import { HashRouter, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import DashboardPage from './pages/DashboardPage';
import JobManagementPage from './pages/JobManagementPage';
import SchedulingPage from './pages/SchedulingPage';
import LiveInterviewPage from './pages/LiveInterviewPage';
import AIEvaluationPage from './pages/AIEvaluationPage';
import CandidateProfilePage from './pages/CandidateProfilePage';
import EmployerCandidateSearchPage from './pages/EmployerCandidateSearchPage';
import QuestionBankPage from './pages/QuestionBankPage';
import VideoRecordingsPage from './pages/VideoRecordingsPage';
import BiasDetectionPage from './pages/BiasDetectionPage';
import InterviewPrepPage from './pages/InterviewPrepPage';
import CollaborativeEvaluationPage from './pages/CollaborativeEvaluationPage';
import CandidateFeedbackPage from './pages/CandidateFeedbackPage';
import SkillsAssessmentPage from './pages/SkillsAssessmentPage';
import CompliancePage from './pages/CompliancePage';
import ProctoringPage from './pages/ProctoringPage';
import PanelManagementPage from './pages/PanelManagementPage';
import ErrorBoundary from './components/common/ErrorBoundary';

export default function App() {
  return (
    <ErrorBoundary>
      <HashRouter>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/jobs" element={<JobManagementPage />} />
          <Route path="/scheduling" element={<SchedulingPage />} />
          <Route path="/interview/:interviewId" element={<LiveInterviewPage />} />
          <Route path="/interview" element={<LiveInterviewPage />} />
          <Route path="/evaluations" element={<AIEvaluationPage />} />
          <Route path="/candidate/profile" element={<CandidateProfilePage />} />
          <Route path="/employer/candidates" element={<EmployerCandidateSearchPage />} />
          <Route path="/employer/candidates/:candidateId" element={<EmployerCandidateSearchPage />} />
          <Route path="/questions" element={<QuestionBankPage />} />
          <Route path="/recordings" element={<VideoRecordingsPage />} />
          <Route path="/bias-detection" element={<BiasDetectionPage />} />
          <Route path="/interview-prep" element={<InterviewPrepPage />} />
          <Route path="/collaborative-evaluation" element={<CollaborativeEvaluationPage />} />
          <Route path="/candidate-feedback" element={<CandidateFeedbackPage />} />
          <Route path="/skills-assessment" element={<SkillsAssessmentPage />} />
          <Route path="/compliance" element={<CompliancePage />} />
          <Route path="/proctoring" element={<ProctoringPage />} />
          <Route path="/panel-management" element={<PanelManagementPage />} />
        </Routes>
      </HashRouter>
    </ErrorBoundary>
  );
}

export default function BiasAlertCard({ alert, onViewAlert }) {
  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'high':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'medium':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'low':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Active':
        return 'bg-red-100 text-red-800';
      case 'Under Review':
        return 'bg-amber-100 text-amber-800';
      case 'Resolved':
        return 'bg-green-100 text-green-800';
      case 'Monitoring':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  return (
    <div
      onClick={() => onViewAlert(alert)}
      className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-slate-100 cursor-pointer group hover:scale-105 active:scale-95"
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${alert.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
          <span className="text-white text-xl font-bold">
            {alert.type === 'Question Bias' ? '❓' : 
             alert.type === 'Evaluation Bias' ? '📊' : '⚖️'}
          </span>
        </div>
        <div className="flex flex-col items-end space-y-2">
          <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getSeverityColor(alert.severity)}`}>
            {alert.severity.toUpperCase()}
          </span>
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(alert.status)}`}>
            {alert.status}
          </span>
        </div>
      </div>

      {/* Content */}
      <h3 className="font-semibold text-slate-800 mb-2 line-clamp-2 group-hover:text-indigo-600 transition-colors">
        {alert.title}
      </h3>
      <p className="text-sm text-slate-600 mb-4 line-clamp-2">
        {alert.description}
      </p>

      {/* Affected Item */}
      <div className="bg-slate-50 rounded-lg p-3 mb-4">
        <p className="text-xs text-slate-500 mb-1">Affected Item</p>
        <p className="text-sm font-medium text-slate-800">{alert.affectedItem}</p>
      </div>

      {/* Bias Score */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-medium text-slate-700">Bias Score</span>
          <span className={`text-sm font-bold ${
            alert.biasScore >= 70 ? 'text-red-600' :
            alert.biasScore >= 50 ? 'text-amber-600' :
            'text-blue-600'
          }`}>
            {alert.biasScore}
          </span>
        </div>
        <div className="w-full bg-slate-200 rounded-full h-2">
          <div
            className={`h-2 rounded-full transition-all duration-500 ${
              alert.biasScore >= 70 ? 'bg-gradient-to-r from-red-500 to-pink-500' :
              alert.biasScore >= 50 ? 'bg-gradient-to-r from-amber-500 to-yellow-500' :
              'bg-gradient-to-r from-blue-500 to-cyan-500'
            }`}
            style={{ width: `${alert.biasScore}%` }}
          ></div>
        </div>
      </div>

      {/* Category */}
      <div className="flex items-center justify-between pt-4 border-t border-slate-100">
        <span className="text-xs text-slate-500">{alert.detectedAt}</span>
        <span className="px-2 py-1 bg-indigo-50 text-indigo-700 rounded text-xs font-medium">
          {alert.category}
        </span>
      </div>

      {/* View Details */}
      <div className="mt-4 text-center">
        <span className="text-indigo-600 text-sm font-medium group-hover:translate-x-1 transition-transform inline-block">
          View Details & Recommendations →
        </span>
      </div>
    </div>
  );
}
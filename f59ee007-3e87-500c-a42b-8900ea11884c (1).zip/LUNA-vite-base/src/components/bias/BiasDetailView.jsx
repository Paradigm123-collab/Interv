import { useState } from 'react';

export default function BiasDetailView({ alert, onBack, currentRole }) {
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', label: 'Overview', icon: '📋' },
    { id: 'analysis', label: 'AI Analysis', icon: '🤖' },
    { id: 'recommendations', label: 'Recommendations', icon: '💡' },
    { id: 'history', label: 'History', icon: '📊' }
  ];

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'high':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'medium':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'low':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const aiAnalysis = {
    summary: 'Our AI system has detected potential bias in this content based on language patterns, historical data, and fairness metrics. The analysis indicates that certain phrases and criteria may inadvertently disadvantage specific demographic groups.',
    detectedPatterns: [
      'Use of gendered language that may discourage certain applicants',
      'Cultural assumptions that may not be universally applicable',
      'Age-related terminology that could be discriminatory',
      'Educational background preferences that may limit diversity'
    ],
    impactAssessment: {
      potentialReach: '500+ candidates',
      affectedGroups: ['Women', 'Non-native speakers', 'Career changers'],
      severityJustification: 'High severity due to direct impact on candidate pool diversity and potential legal implications'
    },
    confidence: 92
  };

  const similarCases = [
    {
      id: 1,
      title: 'Similar bias pattern in Product Manager role',
      date: '1 week ago',
      resolution: 'Language updated, diversity improved by 35%'
    },
    {
      id: 2,
      title: 'Gender bias in technical job description',
      date: '2 weeks ago',
      resolution: 'Implemented inclusive language guidelines'
    },
    {
      id: 3,
      title: 'Age-related bias in senior position',
      date: '3 weeks ago',
      resolution: 'Removed age-specific requirements'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100">
        <button
          onClick={onBack}
          className="text-indigo-600 hover:text-indigo-700 font-medium mb-6 flex items-center space-x-2"
        >
          <span>←</span>
          <span>Back to Alerts</span>
        </button>

        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-4 mb-4">
              <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${alert.color} flex items-center justify-center`}>
                <span className="text-white text-3xl">
                  {alert.type === 'Question Bias' ? '❓' : 
                   alert.type === 'Evaluation Bias' ? '📊' : '⚖️'}
                </span>
              </div>
              <div>
                <h1 className="text-3xl font-bold text-slate-800 mb-2">{alert.title}</h1>
                <div className="flex items-center space-x-4">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getSeverityColor(alert.severity)}`}>
                    {alert.severity.toUpperCase()} SEVERITY
                  </span>
                  <span className="text-sm text-slate-600">
                    <span className="mr-1">📁</span>
                    {alert.type}
                  </span>
                  <span className="text-sm text-slate-600">
                    <span className="mr-1">🏷️</span>
                    {alert.category}
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-slate-50 rounded-xl p-4 mb-4">
              <p className="text-sm text-slate-600 mb-1">Affected Item</p>
              <p className="text-lg font-semibold text-slate-800">{alert.affectedItem}</p>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="bg-gradient-to-br from-red-50 to-pink-50 rounded-xl p-4 border border-red-100">
                <p className="text-sm text-slate-600 mb-1">Bias Score</p>
                <p className="text-3xl font-bold text-red-600">{alert.biasScore}</p>
              </div>
              <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl p-4 border border-blue-100">
                <p className="text-sm text-slate-600 mb-1">AI Confidence</p>
                <p className="text-3xl font-bold text-blue-600">{aiAnalysis.confidence}%</p>
              </div>
              <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-4 border border-green-100">
                <p className="text-sm text-slate-600 mb-1">Status</p>
                <p className="text-xl font-bold text-green-600">{alert.status}</p>
              </div>
            </div>
          </div>

          <div className="flex flex-col space-y-3 ml-6">
            <button className="px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all duration-200 shadow-lg font-medium">
              Mark as Resolved
            </button>
            <button className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium">
              Apply Recommendations
            </button>
            <button className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium">
              Export Report
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
        <div className="flex border-b border-slate-200 overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 px-6 py-4 font-medium transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <span className="mr-2">{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </div>

        <div className="p-8">
          {/* Overview Tab */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-bold text-slate-800 mb-4">Description</h3>
                <p className="text-slate-700 leading-relaxed">{alert.description}</p>
              </div>

              <div className="bg-amber-50 rounded-xl p-6 border border-amber-200">
                <h4 className="font-bold text-amber-900 mb-3 flex items-center">
                  <span className="mr-2">⚠️</span>
                  Why This Matters
                </h4>
                <p className="text-amber-800 text-sm leading-relaxed">
                  Bias in hiring processes can lead to discrimination, reduced diversity, legal issues, and damage to company reputation. 
                  Addressing these issues proactively ensures fair treatment of all candidates and helps build a more inclusive workplace.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-bold text-slate-800 mb-4">Impact Assessment</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-slate-50 rounded-lg p-4">
                    <p className="text-sm text-slate-600 mb-2">Potential Reach</p>
                    <p className="text-2xl font-bold text-slate-800">{aiAnalysis.impactAssessment.potentialReach}</p>
                  </div>
                  <div className="bg-slate-50 rounded-lg p-4">
                    <p className="text-sm text-slate-600 mb-2">Affected Groups</p>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {aiAnalysis.impactAssessment.affectedGroups.map((group, index) => (
                        <span key={index} className="px-2 py-1 bg-indigo-100 text-indigo-800 rounded text-xs font-medium">
                          {group}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="bg-slate-50 rounded-lg p-4">
                    <p className="text-sm text-slate-600 mb-2">Detection Time</p>
                    <p className="text-lg font-semibold text-slate-800">{alert.detectedAt}</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* AI Analysis Tab */}
          {activeTab === 'analysis' && (
            <div className="space-y-6">
              <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6 border border-purple-100">
                <h3 className="text-xl font-bold text-slate-800 mb-4 flex items-center">
                  <span className="mr-2">🤖</span>
                  AI Analysis Summary
                </h3>
                <p className="text-slate-700 leading-relaxed">{aiAnalysis.summary}</p>
              </div>

              <div>
                <h4 className="font-bold text-slate-800 mb-4">Detected Patterns</h4>
                <div className="space-y-3">
                  {aiAnalysis.detectedPatterns.map((pattern, index) => (
                    <div key={index} className="bg-slate-50 rounded-lg p-4 flex items-start space-x-3">
                      <span className="text-red-500 text-xl">⚠️</span>
                      <p className="text-slate-700 flex-1">{pattern}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-blue-50 rounded-xl p-6 border border-blue-100">
                <h4 className="font-bold text-blue-900 mb-3">Severity Justification</h4>
                <p className="text-blue-800 text-sm">{aiAnalysis.impactAssessment.severityJustification}</p>
              </div>

              <div>
                <h4 className="font-bold text-slate-800 mb-4">Similar Cases</h4>
                <div className="space-y-3">
                  {similarCases.map((case_) => (
                    <div key={case_.id} className="bg-slate-50 rounded-lg p-4 hover:bg-slate-100 transition-colors">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h5 className="font-semibold text-slate-800 mb-1">{case_.title}</h5>
                          <p className="text-sm text-slate-600 mb-2">{case_.date}</p>
                          <p className="text-sm text-green-700 font-medium">✓ {case_.resolution}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Recommendations Tab */}
          {activeTab === 'recommendations' && (
            <div className="space-y-6">
              <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-6 border border-green-100">
                <h3 className="text-xl font-bold text-slate-800 mb-4 flex items-center">
                  <span className="mr-2">💡</span>
                  Recommended Actions
                </h3>
                <p className="text-slate-700 mb-4">
                  Follow these AI-generated recommendations to address the identified bias and improve fairness in your hiring process.
                </p>
              </div>

              <div className="space-y-4">
                {alert.recommendations.map((recommendation, index) => (
                  <div key={index} className="bg-white border-2 border-slate-200 rounded-xl p-6 hover:border-indigo-300 transition-all">
                    <div className="flex items-start space-x-4">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center flex-shrink-0">
                        <span className="text-white font-bold">{index + 1}</span>
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-slate-800 mb-2">{recommendation}</h4>
                        <div className="flex items-center space-x-4 mt-4">
                          <button className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all text-sm font-medium">
                            Apply Now
                          </button>
                          <button className="px-4 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-all text-sm font-medium">
                            Learn More
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-blue-50 rounded-xl p-6 border border-blue-100">
                <h4 className="font-bold text-blue-900 mb-3 flex items-center">
                  <span className="mr-2">📚</span>
                  Additional Resources
                </h4>
                <ul className="space-y-2 text-sm text-blue-800">
                  <li>• Best practices for inclusive job descriptions</li>
                  <li>• Guide to bias-free interview questions</li>
                  <li>• Diversity and inclusion training materials</li>
                  <li>• Legal compliance checklist for hiring</li>
                </ul>
              </div>
            </div>
          )}

          {/* History Tab */}
          {activeTab === 'history' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-slate-800 mb-4">Alert Timeline</h3>
              
              <div className="space-y-4">
                {[
                  {
                    action: 'Alert Created',
                    user: 'AI System',
                    time: alert.detectedAt,
                    description: 'Bias pattern automatically detected by AI monitoring system',
                    icon: '🚨',
                    color: 'from-red-500 to-pink-500'
                  },
                  {
                    action: 'Under Review',
                    user: 'John Anderson',
                    time: '1 hour ago',
                    description: 'Alert assigned to hiring manager for review',
                    icon: '👁️',
                    color: 'from-amber-500 to-yellow-500'
                  },
                  {
                    action: 'Analysis Completed',
                    user: 'AI System',
                    time: '30 minutes ago',
                    description: 'Detailed bias analysis and recommendations generated',
                    icon: '🤖',
                    color: 'from-purple-500 to-pink-500'
                  }
                ].map((event, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${event.color} flex items-center justify-center flex-shrink-0`}>
                      <span className="text-white text-xl">{event.icon}</span>
                    </div>
                    <div className="flex-1 bg-slate-50 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold text-slate-800">{event.action}</h4>
                        <span className="text-xs text-slate-500">{event.time}</span>
                      </div>
                      <p className="text-sm text-slate-600 mb-1">{event.description}</p>
                      <p className="text-xs text-slate-500">by {event.user}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
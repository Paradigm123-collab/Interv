import { useState } from 'react';
import BiasAlertCard from './BiasAlertCard';
import BiasFilters from './BiasFilters';
import BiasMetricsOverview from './BiasMetricsOverview';

export default function BiasDetectionDashboard({ onViewAlert, currentRole }) {
  const [filters, setFilters] = useState({
    search: '',
    severity: 'all',
    type: 'all',
    status: 'all',
    dateRange: 'all'
  });

  const allAlerts = [
    {
      id: 1,
      type: 'Question Bias',
      severity: 'high',
      title: 'Gender-biased language detected in job posting',
      description: 'The job description contains terms like "rockstar" and "ninja" which may discourage female applicants',
      affectedItem: 'Senior React Developer - Job Posting',
      detectedAt: '2 hours ago',
      status: 'Active',
      recommendations: [
        'Replace "rockstar" with "experienced professional"',
        'Use gender-neutral language throughout',
        'Add inclusive language statement'
      ],
      biasScore: 78,
      category: 'Gender',
      color: 'from-red-500 to-pink-500'
    },
    {
      id: 2,
      type: 'Evaluation Bias',
      severity: 'medium',
      title: 'Inconsistent scoring pattern detected',
      description: 'Panelist shows tendency to rate candidates from certain universities higher',
      affectedItem: 'John Anderson - Panelist Evaluations',
      detectedAt: '5 hours ago',
      status: 'Under Review',
      recommendations: [
        'Review evaluation criteria with panelist',
        'Implement blind evaluation for university background',
        'Provide bias awareness training'
      ],
      biasScore: 62,
      category: 'Educational Background',
      color: 'from-amber-500 to-yellow-500'
    },
    {
      id: 3,
      type: 'Question Bias',
      severity: 'high',
      title: 'Age-related bias in interview question',
      description: 'Question "How many years until retirement?" may discriminate based on age',
      affectedItem: 'Product Manager Interview - Question #7',
      detectedAt: '1 day ago',
      status: 'Resolved',
      recommendations: [
        'Remove age-related questions',
        'Focus on skills and experience',
        'Update question bank guidelines'
      ],
      biasScore: 85,
      category: 'Age',
      color: 'from-red-500 to-orange-500'
    },
    {
      id: 4,
      type: 'Scoring Bias',
      severity: 'low',
      title: 'Minor scoring variance detected',
      description: 'Slight preference for candidates with similar background to interviewer',
      affectedItem: 'Sarah Mitchell - Interview Scores',
      detectedAt: '2 days ago',
      status: 'Monitoring',
      recommendations: [
        'Continue monitoring pattern',
        'Diversify interview panel',
        'Implement structured scoring rubric'
      ],
      biasScore: 35,
      category: 'Background Similarity',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      id: 5,
      type: 'Question Bias',
      severity: 'medium',
      title: 'Cultural bias in technical question',
      description: 'Question assumes familiarity with Western pop culture references',
      affectedItem: 'Frontend Developer Interview - Question #12',
      detectedAt: '3 days ago',
      status: 'Active',
      recommendations: [
        'Use culturally neutral examples',
        'Focus on technical concepts only',
        'Review all questions for cultural assumptions'
      ],
      biasScore: 58,
      category: 'Cultural',
      color: 'from-purple-500 to-pink-500'
    },
    {
      id: 6,
      type: 'Evaluation Bias',
      severity: 'high',
      title: 'Name-based bias pattern identified',
      description: 'Statistical analysis shows correlation between candidate names and scores',
      affectedItem: 'Platform-wide Evaluation Data',
      detectedAt: '4 days ago',
      status: 'Under Review',
      recommendations: [
        'Implement anonymous candidate profiles',
        'Conduct bias training for all evaluators',
        'Review and adjust evaluation process'
      ],
      biasScore: 72,
      category: 'Name/Ethnicity',
      color: 'from-red-500 to-pink-500'
    },
    {
      id: 7,
      type: 'Scoring Bias',
      severity: 'medium',
      title: 'Communication style preference detected',
      description: 'Evaluators consistently rate extroverted communication styles higher',
      affectedItem: 'Multiple Panelist Evaluations',
      detectedAt: '5 days ago',
      status: 'Active',
      recommendations: [
        'Clarify communication evaluation criteria',
        'Value diverse communication styles',
        'Provide examples of effective introverted communication'
      ],
      biasScore: 54,
      category: 'Personality',
      color: 'from-amber-500 to-orange-500'
    },
    {
      id: 8,
      type: 'Question Bias',
      severity: 'low',
      title: 'Minor language complexity issue',
      description: 'Question uses unnecessarily complex vocabulary that may disadvantage non-native speakers',
      affectedItem: 'Data Scientist Interview - Question #5',
      detectedAt: '1 week ago',
      status: 'Resolved',
      recommendations: [
        'Simplify question language',
        'Use clear, direct terminology',
        'Ensure questions test skills, not language proficiency'
      ],
      biasScore: 42,
      category: 'Language',
      color: 'from-blue-500 to-indigo-500'
    }
  ];

  const filteredAlerts = allAlerts.filter(alert => {
    const matchesSearch = filters.search === '' || 
      alert.title.toLowerCase().includes(filters.search.toLowerCase()) ||
      alert.description.toLowerCase().includes(filters.search.toLowerCase()) ||
      alert.affectedItem.toLowerCase().includes(filters.search.toLowerCase());
    
    const matchesSeverity = filters.severity === 'all' || alert.severity === filters.severity;
    const matchesType = filters.type === 'all' || alert.type === filters.type;
    const matchesStatus = filters.status === 'all' || alert.status === filters.status;

    return matchesSearch && matchesSeverity && matchesType && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Metrics Overview */}
      <BiasMetricsOverview alerts={allAlerts} currentRole={currentRole} />

      {/* Filters */}
      <BiasFilters filters={filters} onFilterChange={setFilters} />

      {/* Alerts Grid */}
      {filteredAlerts.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAlerts.map(alert => (
            <BiasAlertCard 
              key={alert.id} 
              alert={alert} 
              onViewAlert={onViewAlert}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl p-12 text-center shadow-lg border border-slate-100">
          <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-4xl">🔍</span>
          </div>
          <h3 className="text-xl font-semibold text-slate-800 mb-2">No bias alerts found</h3>
          <p className="text-slate-600">Try adjusting your filters or check back later</p>
        </div>
      )}
    </div>
  );
}
export default function BiasMetricsOverview({ alerts, currentRole }) {
  const stats = {
    total: alerts.length,
    high: alerts.filter(a => a.severity === 'high').length,
    medium: alerts.filter(a => a.severity === 'medium').length,
    low: alerts.filter(a => a.severity === 'low').length,
    active: alerts.filter(a => a.status === 'Active').length,
    resolved: alerts.filter(a => a.status === 'Resolved').length,
    avgBiasScore: Math.round(alerts.reduce((sum, a) => sum + a.biasScore, 0) / alerts.length)
  };

  const metrics = [
    {
      label: 'Total Alerts',
      value: stats.total,
      change: '+3 this week',
      trend: 'up',
      color: 'from-blue-500 to-cyan-500',
      icon: '🚨'
    },
    {
      label: 'High Severity',
      value: stats.high,
      change: 'Needs attention',
      trend: 'warning',
      color: 'from-red-500 to-pink-500',
      icon: '⚠️'
    },
    {
      label: 'Active Alerts',
      value: stats.active,
      change: 'In progress',
      trend: 'neutral',
      color: 'from-amber-500 to-yellow-500',
      icon: '🔄'
    },
    {
      label: 'Resolved',
      value: stats.resolved,
      change: '+2 this week',
      trend: 'down',
      color: 'from-green-500 to-emerald-500',
      icon: '✅'
    },
    {
      label: 'Avg Bias Score',
      value: stats.avgBiasScore,
      change: 'Lower is better',
      trend: 'neutral',
      color: 'from-purple-500 to-pink-500',
      icon: '📊'
    },
    {
      label: 'Fairness Rating',
      value: `${100 - stats.avgBiasScore}%`,
      change: 'Platform-wide',
      trend: 'up',
      color: 'from-indigo-500 to-purple-500',
      icon: '⚖️'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
      {metrics.map((metric, index) => (
        <div
          key={index}
          className="bg-white rounded-xl p-6 shadow-lg border border-slate-100 hover:shadow-xl transition-all duration-300"
        >
          <div className="flex items-center justify-between mb-4">
            <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${metric.color} flex items-center justify-center`}>
              <span className="text-white text-2xl">{metric.icon}</span>
            </div>
          </div>
          <p className="text-sm text-slate-600 mb-1">{metric.label}</p>
          <div className="flex items-end justify-between">
            <p className="text-3xl font-bold text-slate-800">{metric.value}</p>
          </div>
          <p className={`text-xs mt-2 ${
            metric.trend === 'up' ? 'text-green-600' :
            metric.trend === 'down' ? 'text-red-600' :
            metric.trend === 'warning' ? 'text-amber-600' :
            'text-slate-500'
          }`}>
            {metric.change}
          </p>
        </div>
      ))}
    </div>
  );
}
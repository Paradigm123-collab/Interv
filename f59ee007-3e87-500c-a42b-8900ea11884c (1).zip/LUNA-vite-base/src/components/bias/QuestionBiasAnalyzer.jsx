import { useState } from 'react';

export default function QuestionBiasAnalyzer({ onClose, currentRole }) {
  const [questionText, setQuestionText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);

  const handleAnalyze = () => {
    if (!questionText.trim()) {
      alert('Please enter a question to analyze');
      return;
    }

    setIsAnalyzing(true);

    setTimeout(() => {
      const result = {
        biasScore: Math.floor(Math.random() * 40) + 30,
        detectedBiases: [
          {
            type: 'Gender Bias',
            severity: 'medium',
            description: 'Contains gendered language that may discourage certain applicants',
            examples: ['he/she', 'guys', 'rockstar'],
            suggestion: 'Use gender-neutral terms like "they", "team members", "experienced professional"'
          },
          {
            type: 'Cultural Bias',
            severity: 'low',
            description: 'References cultural context that may not be universal',
            examples: ['American football analogy'],
            suggestion: 'Use universally understood examples or technical terminology'
          }
        ],
        fairnessScore: 72,
        recommendations: [
          'Replace gendered pronouns with "they/them"',
          'Remove cultural-specific references',
          'Focus on skills and competencies',
          'Use inclusive language throughout'
        ],
        improvedVersion: questionText.replace(/he|she/gi, 'they').replace(/his|her/gi, 'their')
      };

      setAnalysisResult(result);
      setIsAnalyzing(false);
    }, 2000);
  };

  const getBiasScoreColor = (score) => {
    if (score >= 70) return 'text-red-600';
    if (score >= 50) return 'text-amber-600';
    return 'text-green-600';
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <span className="text-3xl">🔍</span>
              <div>
                <h3 className="text-xl font-bold">Question Bias Analyzer</h3>
                <p className="text-sm opacity-90">AI-powered fairness check for interview questions</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:bg-white/20 rounded-lg p-2 transition-colors"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
          <div className="space-y-6">
            {/* Input Section */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Enter Interview Question
              </label>
              <textarea
                value={questionText}
                onChange={(e) => setQuestionText(e.target.value)}
                placeholder="Type or paste your interview question here..."
                rows={6}
                className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
              />
              <p className="text-sm text-slate-500 mt-2">
                💡 Tip: Our AI will analyze the question for potential bias in language, assumptions, and fairness
              </p>
            </div>

            {/* Analyze Button */}
            {!analysisResult && (
              <button
                onClick={handleAnalyze}
                disabled={isAnalyzing || !questionText.trim()}
                className="w-full px-6 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all duration-200 shadow-lg font-medium disabled:opacity-50 flex items-center justify-center space-x-2"
              >
                {isAnalyzing ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Analyzing...</span>
                  </>
                ) : (
                  <>
                    <span>🤖</span>
                    <span>Analyze for Bias</span>
                  </>
                )}
              </button>
            )}

            {/* Analysis Results */}
            {analysisResult && (
              <div className="space-y-6">
                {/* Scores */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gradient-to-br from-red-50 to-pink-50 rounded-xl p-6 border border-red-100">
                    <p className="text-sm text-slate-600 mb-2">Bias Score</p>
                    <p className={`text-4xl font-bold ${getBiasScoreColor(analysisResult.biasScore)}`}>
                      {analysisResult.biasScore}
                    </p>
                    <p className="text-xs text-slate-500 mt-2">Lower is better</p>
                  </div>
                  <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-6 border border-green-100">
                    <p className="text-sm text-slate-600 mb-2">Fairness Score</p>
                    <p className="text-4xl font-bold text-green-600">{analysisResult.fairnessScore}</p>
                    <p className="text-xs text-slate-500 mt-2">Higher is better</p>
                  </div>
                </div>

                {/* Detected Biases */}
                <div>
                  <h4 className="font-bold text-slate-800 mb-4">Detected Biases</h4>
                  <div className="space-y-3">
                    {analysisResult.detectedBiases.map((bias, index) => (
                      <div key={index} className="bg-amber-50 rounded-lg p-4 border border-amber-200">
                        <div className="flex items-start justify-between mb-2">
                          <h5 className="font-semibold text-amber-900">{bias.type}</h5>
                          <span className={`px-2 py-1 rounded text-xs font-medium ${
                            bias.severity === 'high' ? 'bg-red-100 text-red-800' :
                            bias.severity === 'medium' ? 'bg-amber-100 text-amber-800' :
                            'bg-blue-100 text-blue-800'
                          }`}>
                            {bias.severity.toUpperCase()}
                          </span>
                        </div>
                        <p className="text-sm text-amber-800 mb-2">{bias.description}</p>
                        <div className="bg-white rounded p-2 mb-2">
                          <p className="text-xs text-slate-600 mb-1">Examples found:</p>
                          <div className="flex flex-wrap gap-1">
                            {bias.examples.map((example, i) => (
                              <span key={i} className="px-2 py-1 bg-red-100 text-red-800 rounded text-xs">
                                {example}
                              </span>
                            ))}
                          </div>
                        </div>
                        <p className="text-sm text-green-700 font-medium">✓ {bias.suggestion}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Recommendations */}
                <div className="bg-blue-50 rounded-xl p-6 border border-blue-100">
                  <h4 className="font-bold text-blue-900 mb-3 flex items-center">
                    <span className="mr-2">💡</span>
                    Recommendations
                  </h4>
                  <ul className="space-y-2">
                    {analysisResult.recommendations.map((rec, index) => (
                      <li key={index} className="text-sm text-blue-800 flex items-start">
                        <span className="mr-2">•</span>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Improved Version */}
                <div>
                  <h4 className="font-bold text-slate-800 mb-3">Suggested Improved Version</h4>
                  <div className="bg-green-50 rounded-lg p-4 border border-green-200">
                    <p className="text-slate-700">{analysisResult.improvedVersion}</p>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center space-x-4">
                  <button
                    onClick={() => {
                      setQuestionText(analysisResult.improvedVersion);
                      setAnalysisResult(null);
                    }}
                    className="flex-1 px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all duration-200 shadow-lg font-medium"
                  >
                    Use Improved Version
                  </button>
                  <button
                    onClick={() => setAnalysisResult(null)}
                    className="flex-1 px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium"
                  >
                    Analyze Another
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-slate-200 p-6 bg-slate-50">
          <div className="flex items-center justify-between">
            <p className="text-sm text-slate-600">
              💡 This analysis is powered by advanced AI algorithms trained on fairness and inclusion best practices
            </p>
            <button
              onClick={onClose}
              className="px-6 py-3 text-slate-700 hover:bg-slate-200 rounded-lg transition-colors font-medium"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
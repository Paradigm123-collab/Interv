export default function CandidateOverviewCard({ candidate }) {
  return (
    <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
      <div className="h-32 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600"></div>
      <div className="px-8 pb-8">
        <div className="flex items-start -mt-16 mb-6">
          <img
            src={candidate.avatar}
            alt={candidate.name}
            className="w-32 h-32 rounded-2xl border-4 border-white shadow-xl"
          />
          <div className="ml-6 flex-1 mt-16">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-3xl font-bold text-slate-800 mb-1">{candidate.name}</h2>
                <p className="text-lg text-slate-600 mb-2">{candidate.position}</p>
                <div className="flex items-center space-x-4 text-sm text-slate-500">
                  <span className="flex items-center">
                    <span className="mr-1">🏢</span>
                    {candidate.company}
                  </span>
                  <span className="flex items-center">
                    <span className="mr-1">📅</span>
                    {candidate.interviewDate}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl p-4 border border-indigo-100">
            <p className="text-sm text-slate-600 mb-1">Overall Score</p>
            <p className="text-3xl font-bold text-indigo-600">{candidate.overallScore}</p>
          </div>
          <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl p-4 border border-blue-100">
            <p className="text-sm text-slate-600 mb-1">Technical</p>
            <p className="text-3xl font-bold text-blue-600">{candidate.technicalScore}</p>
          </div>
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-4 border border-green-100">
            <p className="text-sm text-slate-600 mb-1">Communication</p>
            <p className="text-3xl font-bold text-green-600">{candidate.communicationScore}</p>
          </div>
          <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-4 border border-purple-100">
            <p className="text-sm text-slate-600 mb-1">Evaluations</p>
            <p className="text-3xl font-bold text-purple-600">
              {candidate.evaluationsComplete}/{candidate.panelistsAssigned}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
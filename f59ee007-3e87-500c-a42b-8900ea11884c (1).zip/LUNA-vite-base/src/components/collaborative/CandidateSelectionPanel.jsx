import { useState } from 'react';

export default function CandidateSelectionPanel({ onSelectCandidate }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  const candidates = [
    {
      id: 1,
      name: 'Sarah Mitchell',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      position: 'Senior React Developer',
      company: 'TechCorp Solutions',
      interviewDate: '2024-12-28',
      status: 'Pending Evaluation',
      panelistsAssigned: 4,
      evaluationsComplete: 2,
      overallScore: 88,
      technicalScore: 90,
      communicationScore: 85,
      color: 'from-green-500 to-emerald-500'
    },
    {
      id: 2,
      name: 'Michael Chen',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      position: 'Full Stack Engineer',
      company: 'Innovation Labs',
      interviewDate: '2024-12-27',
      status: 'In Discussion',
      panelistsAssigned: 3,
      evaluationsComplete: 3,
      overallScore: 82,
      technicalScore: 85,
      communicationScore: 80,
      color: 'from-blue-500 to-cyan-500'
    },
    {
      id: 3,
      name: 'Emily Rodriguez',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
      position: 'Frontend Developer',
      company: 'Digital Dynamics',
      interviewDate: '2024-12-26',
      status: 'Consensus Reached',
      panelistsAssigned: 4,
      evaluationsComplete: 4,
      overallScore: 86,
      technicalScore: 88,
      communicationScore: 84,
      color: 'from-purple-500 to-pink-500'
    },
    {
      id: 4,
      name: 'David Park',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
      position: 'UI/UX Designer',
      company: 'Creative Studios',
      interviewDate: '2024-12-25',
      status: 'Pending Evaluation',
      panelistsAssigned: 3,
      evaluationsComplete: 1,
      overallScore: 91,
      technicalScore: 92,
      communicationScore: 90,
      color: 'from-orange-500 to-red-500'
    },
    {
      id: 5,
      name: 'Lisa Anderson',
      avatar: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop',
      position: 'Product Manager',
      company: 'StartupHub Inc',
      interviewDate: '2024-12-24',
      status: 'In Discussion',
      panelistsAssigned: 4,
      evaluationsComplete: 3,
      overallScore: 87,
      technicalScore: 86,
      communicationScore: 89,
      color: 'from-indigo-500 to-purple-500'
    },
    {
      id: 6,
      name: 'James Wilson',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop',
      position: 'DevOps Engineer',
      company: 'CloudTech Systems',
      interviewDate: '2024-12-23',
      status: 'Consensus Reached',
      panelistsAssigned: 3,
      evaluationsComplete: 3,
      overallScore: 72,
      technicalScore: 78,
      communicationScore: 70,
      color: 'from-red-500 to-pink-500'
    },
    {
      id: 7,
      name: 'Maria Garcia',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop',
      position: 'Data Scientist',
      company: 'Analytics Pro',
      interviewDate: '2024-12-22',
      status: 'Pending Evaluation',
      panelistsAssigned: 4,
      evaluationsComplete: 2,
      overallScore: 89,
      technicalScore: 91,
      communicationScore: 87,
      color: 'from-teal-500 to-cyan-500'
    },
    {
      id: 8,
      name: 'Robert Taylor',
      avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop',
      position: 'Backend Developer',
      company: 'ServerTech Inc',
      interviewDate: '2024-12-21',
      status: 'In Discussion',
      panelistsAssigned: 3,
      evaluationsComplete: 2,
      overallScore: 84,
      technicalScore: 86,
      communicationScore: 82,
      color: 'from-amber-500 to-yellow-500'
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'Pending Evaluation':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'In Discussion':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Consensus Reached':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const filteredCandidates = candidates.filter(candidate => {
    const matchesSearch = 
      candidate.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      candidate.position.toLowerCase().includes(searchQuery.toLowerCase()) ||
      candidate.company.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = filterStatus === 'all' || candidate.status === filterStatus;
    
    return matchesSearch && matchesStatus;
  });

  const stats = {
    total: candidates.length,
    pending: candidates.filter(c => c.status === 'Pending Evaluation').length,
    inDiscussion: candidates.filter(c => c.status === 'In Discussion').length,
    consensus: candidates.filter(c => c.status === 'Consensus Reached').length
  };

  return (
    <div className="space-y-6">
      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Total Candidates</p>
              <p className="text-3xl font-bold text-slate-800">{stats.total}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">👥</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Pending</p>
              <p className="text-3xl font-bold text-amber-600">{stats.pending}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-yellow-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">⏳</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">In Discussion</p>
              <p className="text-3xl font-bold text-blue-600">{stats.inDiscussion}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">💬</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Consensus</p>
              <p className="text-3xl font-bold text-green-600">{stats.consensus}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">✅</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Search Candidates
            </label>
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by name, position, or company..."
                className="w-full px-4 py-3 pl-10 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              />
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400">
                🔍
              </span>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Filter by Status
            </label>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            >
              <option value="all">All Status</option>
              <option value="Pending Evaluation">Pending Evaluation</option>
              <option value="In Discussion">In Discussion</option>
              <option value="Consensus Reached">Consensus Reached</option>
            </select>
          </div>
        </div>
      </div>

      {/* Candidates Grid */}
      {filteredCandidates.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCandidates.map(candidate => (
            <div
              key={candidate.id}
              onClick={() => onSelectCandidate(candidate)}
              className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-slate-100 cursor-pointer group hover:scale-105 active:scale-95"
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <img
                    src={candidate.avatar}
                    alt={candidate.name}
                    className="w-14 h-14 rounded-full border-2 border-indigo-200 group-hover:scale-110 transition-transform"
                  />
                  <div>
                    <h3 className="font-bold text-slate-800 group-hover:text-indigo-600 transition-colors">
                      {candidate.name}
                    </h3>
                    <p className="text-sm text-slate-600">{candidate.position}</p>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(candidate.status)}`}>
                  {candidate.status}
                </span>
              </div>

              {/* Company */}
              <div className="flex items-center text-sm text-slate-600 mb-4">
                <span className="mr-2">🏢</span>
                <span>{candidate.company}</span>
              </div>

              {/* Progress */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-slate-600">Evaluation Progress</span>
                  <span className="text-sm font-bold text-indigo-600">
                    {candidate.evaluationsComplete}/{candidate.panelistsAssigned}
                  </span>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-2">
                  <div
                    className="h-2 rounded-full bg-gradient-to-r from-indigo-600 to-purple-600 transition-all duration-500"
                    style={{ width: `${(candidate.evaluationsComplete / candidate.panelistsAssigned) * 100}%` }}
                  ></div>
                </div>
              </div>

              {/* Scores */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-lg p-3 border border-indigo-100">
                  <p className="text-xs text-slate-600 mb-1">Overall Score</p>
                  <p className="text-2xl font-bold text-indigo-600">{candidate.overallScore}</p>
                </div>
                <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-lg p-3 border border-blue-100">
                  <p className="text-xs text-slate-600 mb-1">Technical</p>
                  <p className="text-2xl font-bold text-blue-600">{candidate.technicalScore}</p>
                </div>
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between pt-4 mt-4 border-t border-slate-100">
                <span className="text-xs text-slate-500">{candidate.interviewDate}</span>
                <span className="text-indigo-600 text-sm font-medium group-hover:translate-x-1 transition-transform">
                  View Workspace →
                </span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl p-12 text-center shadow-lg border border-slate-100">
          <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-4xl">🔍</span>
          </div>
          <h3 className="text-xl font-semibold text-slate-800 mb-2">No candidates found</h3>
          <p className="text-slate-600">Try adjusting your search or filters</p>
        </div>
      )}
    </div>
  );
}
import { useState } from 'react';
import PanelistScoresPanel from './PanelistScoresPanel';
import DiscussionPanel from './DiscussionPanel';
import ConsensusPanel from './ConsensusPanel';
import CandidateOverviewCard from './CandidateOverviewCard';

export default function CollaborativeWorkspace({ candidate, onBack }) {
  const [activeTab, setActiveTab] = useState('scores');

  const tabs = [
    { id: 'scores', label: 'Panelist Scores', icon: '📊', count: 4 },
    { id: 'discussion', label: 'Discussion', icon: '💬', count: 12 },
    { id: 'consensus', label: 'Consensus', icon: '✅', count: null }
  ];

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="flex items-center space-x-2 text-indigo-600 hover:text-indigo-700 font-medium transition-colors"
      >
        <span>←</span>
        <span>Back to Candidate Selection</span>
      </button>

      {/* Candidate Overview */}
      <CandidateOverviewCard candidate={candidate} />

      {/* Workspace Tabs */}
      <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
        <div className="flex border-b border-slate-200 overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 px-6 py-4 font-medium transition-all whitespace-nowrap flex items-center justify-center space-x-2 ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
              {tab.count !== null && (
                <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                  activeTab === tab.id
                    ? 'bg-white/20 text-white'
                    : 'bg-slate-100 text-slate-600'
                }`}>
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>

        <div className="p-8">
          {activeTab === 'scores' && <PanelistScoresPanel candidate={candidate} />}
          {activeTab === 'discussion' && <DiscussionPanel candidate={candidate} />}
          {activeTab === 'consensus' && <ConsensusPanel candidate={candidate} />}
        </div>
      </div>
    </div>
  );
}
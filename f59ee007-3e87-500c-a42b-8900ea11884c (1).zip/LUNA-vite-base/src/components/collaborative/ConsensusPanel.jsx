import { useState } from 'react';

export default function ConsensusPanel({ candidate }) {
  const [finalDecision, setFinalDecision] = useState(null);
  const [decisionNotes, setDecisionNotes] = useState('');

  const consensusData = {
    totalPanelists: 4,
    votesSubmitted: 3,
    recommendations: {
      highlyRecommended: 1,
      recommended: 2,
      notRecommended: 0
    },
    averageScores: {
      overall: 88,
      technical: 89,
      communication: 87,
      problemSolving: 89,
      cultureFit: 88
    },
    keyAgreements: [
      'Strong technical foundation in React and modern web technologies',
      'Excellent problem-solving approach and analytical thinking',
      'Good cultural fit with team values and work style',
      'Clear communication and ability to explain complex concepts'
    ],
    keyDisagreements: [
      'Level of experience with testing frameworks (some see as critical, others as learnable)',
      'Depth of system architecture knowledge (opinions vary on current level vs. potential)',
      'Need for additional technical deep-dive interview (split opinion)'
    ],
    nextSteps: [
      'Schedule follow-up technical interview focused on system design',
      'Discuss compensation expectations and timeline',
      'Prepare offer package if technical deep-dive is successful',
      'Coordinate with HR on onboarding timeline'
    ]
  };

  const handleSubmitDecision = () => {
    if (finalDecision && decisionNotes.trim()) {
      alert(`Final Decision: ${finalDecision}\n\nNotes: ${decisionNotes}\n\nThis will be saved and shared with the team!`);
    } else {
      alert('Please select a decision and add notes before submitting.');
    }
  };

  const getProgressPercentage = () => {
    return (consensusData.votesSubmitted / consensusData.totalPanelists) * 100;
  };

  const getRecommendationPercentage = (type) => {
    const total = Object.values(consensusData.recommendations).reduce((sum, val) => sum + val, 0);
    return total > 0 ? (consensusData.recommendations[type] / total) * 100 : 0;
  };

  return (
    <div className="space-y-6">
      {/* Consensus Progress */}
      <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl p-6 border border-indigo-100">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-slate-800">🎯 Consensus Building Progress</h3>
          <span className="text-2xl font-bold text-indigo-600">
            {consensusData.votesSubmitted}/{consensusData.totalPanelists}
          </span>
        </div>
        <div className="w-full bg-slate-200 rounded-full h-4 mb-2">
          <div
            className="h-4 rounded-full bg-gradient-to-r from-indigo-600 to-purple-600 transition-all duration-500"
            style={{ width: `${getProgressPercentage()}%` }}
          ></div>
        </div>
        <p className="text-sm text-slate-600">
          {consensusData.votesSubmitted === consensusData.totalPanelists
            ? '✅ All panelists have submitted their evaluations'
            : `⏳ Waiting for ${consensusData.totalPanelists - consensusData.votesSubmitted} more evaluation(s)`}
        </p>
      </div>

      {/* Recommendation Distribution */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
        <h3 className="text-lg font-bold text-slate-800 mb-4">📊 Recommendation Distribution</h3>
        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-green-700">Highly Recommended</span>
              <span className="text-sm font-bold text-green-700">
                {consensusData.recommendations.highlyRecommended} ({Math.round(getRecommendationPercentage('highlyRecommended'))}%)
              </span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-3">
              <div
                className="h-3 rounded-full bg-gradient-to-r from-green-500 to-emerald-500"
                style={{ width: `${getRecommendationPercentage('highlyRecommended')}%` }}
              ></div>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-blue-700">Recommended</span>
              <span className="text-sm font-bold text-blue-700">
                {consensusData.recommendations.recommended} ({Math.round(getRecommendationPercentage('recommended'))}%)
              </span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-3">
              <div
                className="h-3 rounded-full bg-gradient-to-r from-blue-500 to-cyan-500"
                style={{ width: `${getRecommendationPercentage('recommended')}%` }}
              ></div>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-red-700">Not Recommended</span>
              <span className="text-sm font-bold text-red-700">
                {consensusData.recommendations.notRecommended} ({Math.round(getRecommendationPercentage('notRecommended'))}%)
              </span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-3">
              <div
                className="h-3 rounded-full bg-gradient-to-r from-red-500 to-pink-500"
                style={{ width: `${getRecommendationPercentage('notRecommended')}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Average Scores */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
        <h3 className="text-lg font-bold text-slate-800 mb-4">📈 Consensus Scores</h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {Object.entries(consensusData.averageScores).map(([key, value]) => (
            <div key={key} className="bg-gradient-to-br from-slate-50 to-slate-100 rounded-lg p-4 border border-slate-200 text-center">
              <p className="text-xs text-slate-600 mb-1 capitalize">
                {key.replace(/([A-Z])/g, ' $1').trim()}
              </p>
              <p className="text-3xl font-bold text-indigo-600">{value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Key Agreements */}
      <div className="bg-green-50 rounded-xl p-6 border border-green-100">
        <h3 className="text-lg font-bold text-green-900 mb-4 flex items-center">
          <span className="mr-2">✅</span>
          Key Agreements
        </h3>
        <ul className="space-y-3">
          {consensusData.keyAgreements.map((agreement, index) => (
            <li key={index} className="flex items-start text-green-800">
              <span className="mr-3 mt-1">•</span>
              <span>{agreement}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Key Disagreements */}
      <div className="bg-amber-50 rounded-xl p-6 border border-amber-100">
        <h3 className="text-lg font-bold text-amber-900 mb-4 flex items-center">
          <span className="mr-2">⚠️</span>
          Points of Discussion
        </h3>
        <ul className="space-y-3">
          {consensusData.keyDisagreements.map((disagreement, index) => (
            <li key={index} className="flex items-start text-amber-800">
              <span className="mr-3 mt-1">•</span>
              <span>{disagreement}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Recommended Next Steps */}
      <div className="bg-blue-50 rounded-xl p-6 border border-blue-100">
        <h3 className="text-lg font-bold text-blue-900 mb-4 flex items-center">
          <span className="mr-2">🎯</span>
          Recommended Next Steps
        </h3>
        <ol className="space-y-3">
          {consensusData.nextSteps.map((step, index) => (
            <li key={index} className="flex items-start text-blue-800">
              <span className="mr-3 font-bold">{index + 1}.</span>
              <span>{step}</span>
            </li>
          ))}
        </ol>
      </div>

      {/* Final Decision Form */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
        <h3 className="text-lg font-bold text-slate-800 mb-4">🎯 Final Hiring Decision</h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Select Final Decision
            </label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <button
                onClick={() => setFinalDecision('Proceed with Offer')}
                className={`p-4 rounded-lg border-2 transition-all ${
                  finalDecision === 'Proceed with Offer'
                    ? 'border-green-500 bg-green-50'
                    : 'border-slate-200 hover:border-green-300'
                }`}
              >
                <div className="text-center">
                  <span className="text-3xl mb-2 block">✅</span>
                  <p className="font-semibold text-slate-800">Proceed with Offer</p>
                </div>
              </button>

              <button
                onClick={() => setFinalDecision('Additional Interview')}
                className={`p-4 rounded-lg border-2 transition-all ${
                  finalDecision === 'Additional Interview'
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-slate-200 hover:border-blue-300'
                }`}
              >
                <div className="text-center">
                  <span className="text-3xl mb-2 block">🔄</span>
                  <p className="font-semibold text-slate-800">Additional Interview</p>
                </div>
              </button>

              <button
                onClick={() => setFinalDecision('Decline')}
                className={`p-4 rounded-lg border-2 transition-all ${
                  finalDecision === 'Decline'
                    ? 'border-red-500 bg-red-50'
                    : 'border-slate-200 hover:border-red-300'
                }`}
              >
                <div className="text-center">
                  <span className="text-3xl mb-2 block">❌</span>
                  <p className="font-semibold text-slate-800">Decline</p>
                </div>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Decision Notes & Rationale
            </label>
            <textarea
              value={decisionNotes}
              onChange={(e) => setDecisionNotes(e.target.value)}
              placeholder="Explain the reasoning behind this decision and any important considerations..."
              rows="6"
              className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
            />
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-200">
            <p className="text-sm text-slate-600">
              This decision will be shared with all panelists and HR
            </p>
            <button
              onClick={handleSubmitDecision}
              disabled={!finalDecision || !decisionNotes.trim()}
              className="px-8 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Submit Final Decision
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
import { useState } from 'react';

export default function DiscussionPanel({ candidate }) {
  const [newMessage, setNewMessage] = useState('');
  const [replyingTo, setReplyingTo] = useState(null);

  const discussions = [
    {
      id: 1,
      author: 'Dr. Sarah Johnson',
      authorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      role: 'Senior Technical Lead',
      timestamp: '2 hours ago',
      message: 'I was really impressed with the candidate\'s approach to the system design question. The way they broke down the problem showed excellent architectural thinking.',
      likes: 3,
      replies: [
        {
          id: 11,
          author: 'Mark Wilson',
          authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
          role: 'Engineering Manager',
          timestamp: '1 hour ago',
          message: 'I agree! Though I think they could benefit from more experience with microservices architecture. What do you think about their scalability considerations?',
          likes: 2
        },
        {
          id: 12,
          author: 'Dr. Sarah Johnson',
          authorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
          role: 'Senior Technical Lead',
          timestamp: '45 minutes ago',
          message: 'Good point. They did mention horizontal scaling but didn\'t dive deep into service decomposition. That could be addressed through mentorship.',
          likes: 1
        }
      ]
    },
    {
      id: 2,
      author: 'Emily Chen',
      authorAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
      role: 'Product Manager',
      timestamp: '3 hours ago',
      message: 'From a product perspective, I loved how they asked clarifying questions about user needs before jumping into solutions. This shows great product thinking.',
      likes: 4,
      replies: []
    },
    {
      id: 3,
      author: 'Mark Wilson',
      authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      role: 'Engineering Manager',
      timestamp: '5 hours ago',
      message: 'One concern I have is their limited experience with testing frameworks. How critical is this for the role we\'re hiring for?',
      likes: 2,
      replies: [
        {
          id: 31,
          author: 'Emily Chen',
          authorAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
          role: 'Product Manager',
          timestamp: '4 hours ago',
          message: 'I think it\'s something they can learn on the job. Their problem-solving skills are more important for this role.',
          likes: 3
        }
      ]
    },
    {
      id: 4,
      author: 'Dr. Sarah Johnson',
      authorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      role: 'Senior Technical Lead',
      timestamp: '1 day ago',
      message: 'Should we schedule a follow-up technical deep-dive? I\'d like to explore their understanding of performance optimization in more detail.',
      likes: 5,
      replies: [
        {
          id: 41,
          author: 'Mark Wilson',
          authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
          role: 'Engineering Manager',
          timestamp: '1 day ago',
          message: 'I think that would be valuable. Let\'s coordinate on timing.',
          likes: 2
        }
      ]
    }
  ];

  const handleSubmit = (e) => {
    e.preventDefault();
    if (newMessage.trim()) {
      alert(`Message posted: ${newMessage}\n\nThis will be implemented with backend integration!`);
      setNewMessage('');
      setReplyingTo(null);
    }
  };

  const handleLike = (discussionId) => {
    alert(`Liked discussion #${discussionId}\n\nLike functionality will be implemented with backend!`);
  };

  const handleReply = (discussionId) => {
    setReplyingTo(discussionId);
  };

  return (
    <div className="space-y-6">
      {/* Discussion Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-4 border border-blue-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Total Messages</p>
              <p className="text-3xl font-bold text-blue-600">12</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">💬</span>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-4 border border-purple-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Active Participants</p>
              <p className="text-3xl font-bold text-purple-600">4</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">👥</span>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-4 border border-green-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Last Activity</p>
              <p className="text-lg font-bold text-green-600">2 hours ago</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">⏰</span>
            </div>
          </div>
        </div>
      </div>

      {/* New Message Form */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            {replyingTo && (
              <div className="mb-3 p-3 bg-blue-50 rounded-lg border border-blue-200 flex items-center justify-between">
                <span className="text-sm text-blue-800">
                  💬 Replying to discussion #{replyingTo}
                </span>
                <button
                  type="button"
                  onClick={() => setReplyingTo(null)}
                  className="text-blue-600 hover:text-blue-700"
                >
                  ✕
                </button>
              </div>
            )}
            <textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Share your thoughts about this candidate..."
              rows="4"
              className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-sm text-slate-600">
              <span>💡</span>
              <span>Be constructive and specific in your feedback</span>
            </div>
            <button
              type="submit"
              disabled={!newMessage.trim()}
              className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Post Message
            </button>
          </div>
        </form>
      </div>

      {/* Discussion Thread */}
      <div className="space-y-4">
        {discussions.map((discussion) => (
          <div key={discussion.id} className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
            {/* Main Discussion */}
            <div className="flex items-start space-x-4">
              <img
                src={discussion.authorAvatar}
                alt={discussion.author}
                className="w-12 h-12 rounded-full border-2 border-indigo-200"
              />
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <h4 className="font-bold text-slate-800">{discussion.author}</h4>
                    <p className="text-sm text-slate-600">{discussion.role}</p>
                  </div>
                  <span className="text-xs text-slate-500">{discussion.timestamp}</span>
                </div>
                <p className="text-slate-700 mb-4">{discussion.message}</p>
                <div className="flex items-center space-x-4">
                  <button
                    onClick={() => handleLike(discussion.id)}
                    className="flex items-center space-x-2 text-sm text-slate-600 hover:text-indigo-600 transition-colors"
                  >
                    <span>👍</span>
                    <span>{discussion.likes}</span>
                  </button>
                  <button
                    onClick={() => handleReply(discussion.id)}
                    className="flex items-center space-x-2 text-sm text-slate-600 hover:text-indigo-600 transition-colors"
                  >
                    <span>💬</span>
                    <span>Reply</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Replies */}
            {discussion.replies.length > 0 && (
              <div className="mt-4 ml-16 space-y-4">
                {discussion.replies.map((reply) => (
                  <div key={reply.id} className="bg-slate-50 rounded-lg p-4 border border-slate-200">
                    <div className="flex items-start space-x-3">
                      <img
                        src={reply.authorAvatar}
                        alt={reply.author}
                        className="w-10 h-10 rounded-full border-2 border-slate-200"
                      />
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <div>
                            <h5 className="font-semibold text-slate-800 text-sm">{reply.author}</h5>
                            <p className="text-xs text-slate-600">{reply.role}</p>
                          </div>
                          <span className="text-xs text-slate-500">{reply.timestamp}</span>
                        </div>
                        <p className="text-sm text-slate-700 mb-3">{reply.message}</p>
                        <button
                          onClick={() => handleLike(reply.id)}
                          className="flex items-center space-x-2 text-xs text-slate-600 hover:text-indigo-600 transition-colors"
                        >
                          <span>👍</span>
                          <span>{reply.likes}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
import { useState } from 'react';

export default function PanelistScoresPanel({ candidate }) {
  const [sortBy, setSortBy] = useState('overall');

  const panelistEvaluations = [
    {
      id: 1,
      panelistName: 'Dr. Sarah Johnson',
      panelistAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      role: 'Senior Technical Lead',
      submittedAt: '2 hours ago',
      overallScore: 92,
      technicalScore: 95,
      communicationScore: 88,
      problemSolvingScore: 93,
      cultureFitScore: 90,
      recommendation: 'Highly Recommended',
      keyStrengths: [
        'Exceptional React expertise',
        'Strong system design skills',
        'Clear communication'
      ],
      concerns: [
        'Limited experience with testing frameworks'
      ],
      notes: 'Outstanding candidate with deep technical knowledge. Shows great potential for senior role.'
    },
    {
      id: 2,
      panelistName: 'Mark Wilson',
      panelistAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      role: 'Engineering Manager',
      submittedAt: '5 hours ago',
      overallScore: 85,
      technicalScore: 88,
      communicationScore: 82,
      problemSolvingScore: 86,
      cultureFitScore: 84,
      recommendation: 'Recommended',
      keyStrengths: [
        'Good problem-solving approach',
        'Team player mentality',
        'Adaptable to new technologies'
      ],
      concerns: [
        'Could improve on system architecture knowledge',
        'Needs more experience with large-scale applications'
      ],
      notes: 'Solid candidate with good fundamentals. Would benefit from mentorship in architecture.'
    },
    {
      id: 3,
      panelistName: 'Emily Chen',
      panelistAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
      role: 'Product Manager',
      submittedAt: '1 day ago',
      overallScore: 88,
      technicalScore: 85,
      communicationScore: 92,
      problemSolvingScore: 87,
      cultureFitScore: 89,
      recommendation: 'Recommended',
      keyStrengths: [
        'Excellent stakeholder communication',
        'User-focused approach',
        'Strong collaboration skills'
      ],
      concerns: [
        'Technical depth could be stronger'
      ],
      notes: 'Great fit from product perspective. Communication skills are exceptional.'
    },
    {
      id: 4,
      panelistName: 'John Anderson',
      panelistAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
      role: 'Tech Lead',
      submittedAt: 'Pending',
      overallScore: null,
      technicalScore: null,
      communicationScore: null,
      problemSolvingScore: null,
      cultureFitScore: null,
      recommendation: null,
      keyStrengths: [],
      concerns: [],
      notes: null
    }
  ];

  const completedEvaluations = panelistEvaluations.filter(e => e.overallScore !== null);
  const pendingEvaluations = panelistEvaluations.filter(e => e.overallScore === null);

  const averageScores = {
    overall: Math.round(completedEvaluations.reduce((sum, e) => sum + e.overallScore, 0) / completedEvaluations.length),
    technical: Math.round(completedEvaluations.reduce((sum, e) => sum + e.technicalScore, 0) / completedEvaluations.length),
    communication: Math.round(completedEvaluations.reduce((sum, e) => sum + e.communicationScore, 0) / completedEvaluations.length),
    problemSolving: Math.round(completedEvaluations.reduce((sum, e) => sum + e.problemSolvingScore, 0) / completedEvaluations.length),
    cultureFit: Math.round(completedEvaluations.reduce((sum, e) => sum + e.cultureFitScore, 0) / completedEvaluations.length)
  };

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 80) return 'text-blue-600';
    if (score >= 70) return 'text-amber-600';
    return 'text-red-600';
  };

  const getRecommendationColor = (recommendation) => {
    switch (recommendation) {
      case 'Highly Recommended':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Recommended':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Not Recommended':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Average Scores Overview */}
      <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl p-6 border border-indigo-100">
        <h3 className="text-lg font-bold text-slate-800 mb-4">📊 Average Scores Across All Panelists</h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {Object.entries(averageScores).map(([key, value]) => (
            <div key={key} className="text-center">
              <p className="text-sm text-slate-600 mb-1 capitalize">
                {key.replace(/([A-Z])/g, ' $1').trim()}
              </p>
              <p className={`text-3xl font-bold ${getScoreColor(value)}`}>{value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Sort Options */}
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold text-slate-800">Individual Panelist Evaluations</h3>
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
        >
          <option value="overall">Sort by Overall Score</option>
          <option value="technical">Sort by Technical Score</option>
          <option value="recent">Sort by Most Recent</option>
        </select>
      </div>

      {/* Completed Evaluations */}
      <div className="space-y-4">
        {completedEvaluations.map((evaluation) => (
          <div
            key={evaluation.id}
            className="bg-white rounded-xl p-6 shadow-lg border border-slate-100 hover:shadow-xl transition-all duration-300"
          >
            {/* Panelist Header */}
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center space-x-4">
                <img
                  src={evaluation.panelistAvatar}
                  alt={evaluation.panelistName}
                  className="w-16 h-16 rounded-full border-2 border-indigo-200"
                />
                <div>
                  <h4 className="font-bold text-slate-800 text-lg">{evaluation.panelistName}</h4>
                  <p className="text-sm text-slate-600">{evaluation.role}</p>
                  <p className="text-xs text-slate-500 mt-1">Submitted {evaluation.submittedAt}</p>
                </div>
              </div>
              <span className={`px-4 py-2 rounded-lg text-sm font-medium border ${getRecommendationColor(evaluation.recommendation)}`}>
                {evaluation.recommendation}
              </span>
            </div>

            {/* Scores Grid */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
              <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-lg p-4 border border-indigo-100">
                <p className="text-xs text-slate-600 mb-1">Overall</p>
                <p className={`text-2xl font-bold ${getScoreColor(evaluation.overallScore)}`}>
                  {evaluation.overallScore}
                </p>
              </div>
              <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-lg p-4 border border-blue-100">
                <p className="text-xs text-slate-600 mb-1">Technical</p>
                <p className={`text-2xl font-bold ${getScoreColor(evaluation.technicalScore)}`}>
                  {evaluation.technicalScore}
                </p>
              </div>
              <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg p-4 border border-green-100">
                <p className="text-xs text-slate-600 mb-1">Communication</p>
                <p className={`text-2xl font-bold ${getScoreColor(evaluation.communicationScore)}`}>
                  {evaluation.communicationScore}
                </p>
              </div>
              <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg p-4 border border-purple-100">
                <p className="text-xs text-slate-600 mb-1">Problem Solving</p>
                <p className={`text-2xl font-bold ${getScoreColor(evaluation.problemSolvingScore)}`}>
                  {evaluation.problemSolvingScore}
                </p>
              </div>
              <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-lg p-4 border border-amber-100">
                <p className="text-xs text-slate-600 mb-1">Culture Fit</p>
                <p className={`text-2xl font-bold ${getScoreColor(evaluation.cultureFitScore)}`}>
                  {evaluation.cultureFitScore}
                </p>
              </div>
            </div>

            {/* Feedback Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-green-50 rounded-lg p-4 border border-green-100">
                <h5 className="font-semibold text-green-900 mb-3 flex items-center">
                  <span className="mr-2">✅</span>
                  Key Strengths
                </h5>
                <ul className="space-y-2">
                  {evaluation.keyStrengths.map((strength, index) => (
                    <li key={index} className="text-sm text-green-800 flex items-start">
                      <span className="mr-2">•</span>
                      <span>{strength}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-amber-50 rounded-lg p-4 border border-amber-100">
                <h5 className="font-semibold text-amber-900 mb-3 flex items-center">
                  <span className="mr-2">⚠️</span>
                  Areas of Concern
                </h5>
                <ul className="space-y-2">
                  {evaluation.concerns.map((concern, index) => (
                    <li key={index} className="text-sm text-amber-800 flex items-start">
                      <span className="mr-2">•</span>
                      <span>{concern}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Notes */}
            {evaluation.notes && (
              <div className="mt-6 bg-slate-50 rounded-lg p-4 border border-slate-200">
                <h5 className="font-semibold text-slate-800 mb-2 flex items-center">
                  <span className="mr-2">📝</span>
                  Additional Notes
                </h5>
                <p className="text-sm text-slate-700">{evaluation.notes}</p>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Pending Evaluations */}
      {pendingEvaluations.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-xl font-bold text-slate-800">⏳ Pending Evaluations</h3>
          {pendingEvaluations.map((evaluation) => (
            <div
              key={evaluation.id}
              className="bg-amber-50 rounded-xl p-6 border border-amber-200"
            >
              <div className="flex items-center space-x-4">
                <img
                  src={evaluation.panelistAvatar}
                  alt={evaluation.panelistName}
                  className="w-16 h-16 rounded-full border-2 border-amber-300"
                />
                <div className="flex-1">
                  <h4 className="font-bold text-slate-800 text-lg">{evaluation.panelistName}</h4>
                  <p className="text-sm text-slate-600">{evaluation.role}</p>
                  <p className="text-sm text-amber-700 mt-1">⏳ Evaluation pending</p>
                </div>
                <button
                  onClick={() => alert(`Send reminder to ${evaluation.panelistName}`)}
                  className="px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors font-medium"
                >
                  Send Reminder
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
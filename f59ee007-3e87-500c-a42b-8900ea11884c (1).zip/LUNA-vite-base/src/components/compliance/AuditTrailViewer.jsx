import { useState } from 'react';

export default function AuditTrailViewer({ onBack }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterUser, setFilterUser] = useState('all');
  const [dateRange, setDateRange] = useState('7days');

  const auditLogs = [
    {
      id: 1,
      timestamp: '2024-12-28 14:32:15',
      user: 'John Anderson',
      userRole: 'Admin',
      action: 'Updated Compliance Rule',
      category: 'Configuration',
      details: 'Modified data retention policy from 60 to 90 days',
      ipAddress: '192.168.1.100',
      status: 'Success',
      affectedRecords: 1
    },
    {
      id: 2,
      timestamp: '2024-12-28 13:15:42',
      user: 'Sarah Mitchell',
      userRole: 'HR Manager',
      action: 'Accessed Candidate Data',
      category: 'Data Access',
      details: 'Viewed profile for candidate ID: 12345',
      ipAddress: '192.168.1.105',
      status: 'Success',
      affectedRecords: 1
    },
    {
      id: 3,
      timestamp: '2024-12-28 12:45:30',
      user: 'System',
      userRole: 'Automated',
      action: 'Generated Compliance Report',
      category: 'Reporting',
      details: 'Monthly GDPR compliance report generated',
      ipAddress: 'Internal',
      status: 'Success',
      affectedRecords: 0
    },
    {
      id: 4,
      timestamp: '2024-12-28 11:20:18',
      user: 'Michael Chen',
      userRole: 'Recruiter',
      action: 'Failed Login Attempt',
      category: 'Security',
      details: 'Multiple failed login attempts detected',
      ipAddress: '192.168.1.110',
      status: 'Failed',
      affectedRecords: 0
    },
    {
      id: 5,
      timestamp: '2024-12-28 10:05:55',
      user: 'Emily Rodriguez',
      userRole: 'Compliance Officer',
      action: 'Reviewed Audit Trail',
      category: 'Audit',
      details: 'Reviewed audit logs for December 2024',
      ipAddress: '192.168.1.115',
      status: 'Success',
      affectedRecords: 0
    },
    {
      id: 6,
      timestamp: '2024-12-28 09:30:22',
      user: 'David Park',
      userRole: 'HR Manager',
      action: 'Deleted Interview Recording',
      category: 'Data Management',
      details: 'Removed recording older than retention period',
      ipAddress: '192.168.1.120',
      status: 'Success',
      affectedRecords: 1
    },
    {
      id: 7,
      timestamp: '2024-12-27 16:45:10',
      user: 'Lisa Anderson',
      userRole: 'Admin',
      action: 'Created New Compliance Rule',
      category: 'Configuration',
      details: 'Added rule for candidate consent tracking',
      ipAddress: '192.168.1.125',
      status: 'Success',
      affectedRecords: 1
    },
    {
      id: 8,
      timestamp: '2024-12-27 15:20:33',
      user: 'System',
      userRole: 'Automated',
      action: 'Data Backup Completed',
      category: 'System',
      details: 'Automated daily backup completed successfully',
      ipAddress: 'Internal',
      status: 'Success',
      affectedRecords: 0
    },
    {
      id: 9,
      timestamp: '2024-12-27 14:10:45',
      user: 'James Wilson',
      userRole: 'Recruiter',
      action: 'Exported Candidate List',
      category: 'Data Export',
      details: 'Exported list of 50 candidates for review',
      ipAddress: '192.168.1.130',
      status: 'Success',
      affectedRecords: 50
    },
    {
      id: 10,
      timestamp: '2024-12-27 13:05:28',
      user: 'Maria Garcia',
      userRole: 'Compliance Officer',
      action: 'Updated Privacy Policy',
      category: 'Configuration',
      details: 'Updated privacy policy to reflect new regulations',
      ipAddress: '192.168.1.135',
      status: 'Success',
      affectedRecords: 1
    }
  ];

  const filteredLogs = auditLogs.filter(log => {
    const matchesSearch = searchQuery === '' ||
      log.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.details.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesType = filterType === 'all' || log.category === filterType;
    const matchesUser = filterUser === 'all' || log.user === filterUser;
    
    return matchesSearch && matchesType && matchesUser;
  });

  const uniqueUsers = [...new Set(auditLogs.map(log => log.user))];
  const uniqueCategories = [...new Set(auditLogs.map(log => log.category))];

  const getStatusColor = (status) => {
    switch (status) {
      case 'Success':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Failed':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'Warning':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'Configuration':
        return '⚙️';
      case 'Data Access':
        return '👁️';
      case 'Reporting':
        return '📊';
      case 'Security':
        return '🔒';
      case 'Audit':
        return '🔍';
      case 'Data Management':
        return '💾';
      case 'System':
        return '🖥️';
      case 'Data Export':
        return '📤';
      default:
        return '📋';
    }
  };

  const handleExport = () => {
    alert('Exporting audit trail...\n\nFormat: CSV\nRecords: ' + filteredLogs.length + '\nDate Range: ' + dateRange + '\n\nExport functionality will be available with backend integration!');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
        <button
          onClick={onBack}
          className="text-indigo-600 hover:text-indigo-700 font-medium mb-4 flex items-center space-x-2"
        >
          <span>←</span>
          <span>Back to Dashboard</span>
        </button>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-800 mb-2">Audit Trail</h1>
            <p className="text-slate-600">Complete activity log with advanced filtering</p>
          </div>
          <button
            onClick={handleExport}
            className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium flex items-center space-x-2"
          >
            <span>📥</span>
            <span>Export Logs</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Search
            </label>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search logs..."
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Category
            </label>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Categories</option>
              {uniqueCategories.map((category) => (
                <option key={category} value={category}>{category}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              User
            </label>
            <select
              value={filterUser}
              onChange={(e) => setFilterUser(e.target.value)}
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Users</option>
              {uniqueUsers.map((user) => (
                <option key={user} value={user}>{user}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Date Range
            </label>
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="24hours">Last 24 Hours</option>
              <option value="7days">Last 7 Days</option>
              <option value="30days">Last 30 Days</option>
              <option value="90days">Last 90 Days</option>
              <option value="custom">Custom Range</option>
            </select>
          </div>
        </div>
      </div>

      {/* Results Summary */}
      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-4 border border-indigo-100">
        <p className="text-sm text-slate-700">
          Showing <span className="font-bold text-indigo-600">{filteredLogs.length}</span> of <span className="font-bold">{auditLogs.length}</span> audit logs
        </p>
      </div>

      {/* Audit Logs Table */}
      <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase">Timestamp</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase">User</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase">Action</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase">Category</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase">Details</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-slate-800">{log.timestamp}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div>
                      <div className="text-sm font-medium text-slate-800">{log.user}</div>
                      <div className="text-xs text-slate-500">{log.userRole}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-slate-800">{log.action}</div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="inline-flex items-center px-3 py-1 rounded-lg text-xs font-medium bg-slate-100 text-slate-800">
                      <span className="mr-1">{getCategoryIcon(log.category)}</span>
                      {log.category}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-slate-600 max-w-md">{log.details}</div>
                    <div className="text-xs text-slate-500 mt-1">
                      IP: {log.ipAddress} • Records: {log.affectedRecords}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-lg text-xs font-medium border ${getStatusColor(log.status)}`}>
                      {log.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
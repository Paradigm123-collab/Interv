import { useState } from 'react';

export default function ComplianceDashboard({ onViewAuditTrail, onManageRules, onGenerateReport }) {
  const [timeRange, setTimeRange] = useState('30days');

  const complianceMetrics = {
    overallScore: 94,
    activeRules: 28,
    violations: 3,
    auditsCompleted: 156,
    dataRequests: 12,
    trend: '+5%'
  };

  const complianceCategories = [
    {
      id: 1,
      name: 'Data Privacy',
      score: 96,
      status: 'Excellent',
      rules: 8,
      lastAudit: '2 days ago',
      color: 'from-green-500 to-emerald-500',
      icon: '🔒'
    },
    {
      id: 2,
      name: 'Equal Opportunity',
      score: 92,
      status: 'Good',
      rules: 6,
      lastAudit: '1 week ago',
      color: 'from-blue-500 to-cyan-500',
      icon: '⚖️'
    },
    {
      id: 3,
      name: 'Interview Recording',
      score: 98,
      status: 'Excellent',
      rules: 5,
      lastAudit: '3 days ago',
      color: 'from-purple-500 to-pink-500',
      icon: '🎥'
    },
    {
      id: 4,
      name: 'Candidate Rights',
      score: 90,
      status: 'Good',
      rules: 7,
      lastAudit: '5 days ago',
      color: 'from-indigo-500 to-purple-500',
      icon: '👤'
    },
    {
      id: 5,
      name: 'Data Retention',
      score: 88,
      status: 'Needs Attention',
      rules: 4,
      lastAudit: '1 week ago',
      color: 'from-amber-500 to-orange-500',
      icon: '💾'
    },
    {
      id: 6,
      name: 'AI Ethics',
      score: 95,
      status: 'Excellent',
      rules: 6,
      lastAudit: '4 days ago',
      color: 'from-teal-500 to-cyan-500',
      icon: '🤖'
    }
  ];

  const recentViolations = [
    {
      id: 1,
      type: 'Data Retention',
      severity: 'Medium',
      description: 'Interview recordings older than 90 days not archived',
      affectedRecords: 12,
      detectedDate: '2024-12-28',
      status: 'In Progress',
      assignedTo: 'Compliance Team'
    },
    {
      id: 2,
      type: 'Candidate Consent',
      severity: 'Low',
      description: 'Missing consent documentation for 3 candidates',
      affectedRecords: 3,
      detectedDate: '2024-12-27',
      status: 'Resolved',
      assignedTo: 'HR Department'
    },
    {
      id: 3,
      type: 'Access Control',
      severity: 'High',
      description: 'Unauthorized access attempt to candidate data',
      affectedRecords: 1,
      detectedDate: '2024-12-26',
      status: 'Under Investigation',
      assignedTo: 'Security Team'
    }
  ];

  const upcomingAudits = [
    {
      id: 1,
      name: 'Quarterly GDPR Compliance Review',
      date: '2025-01-15',
      type: 'Internal',
      scope: 'Data Privacy & Protection',
      status: 'Scheduled'
    },
    {
      id: 2,
      name: 'Equal Opportunity Assessment',
      date: '2025-01-20',
      type: 'External',
      scope: 'Hiring Practices',
      status: 'Scheduled'
    },
    {
      id: 3,
      name: 'AI Ethics Evaluation',
      date: '2025-01-25',
      type: 'Internal',
      scope: 'AI Interview System',
      status: 'Scheduled'
    }
  ];

  const getScoreColor = (score) => {
    if (score >= 95) return 'text-green-600';
    if (score >= 85) return 'text-blue-600';
    if (score >= 75) return 'text-amber-600';
    return 'text-red-600';
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Excellent':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Good':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Needs Attention':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'High':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'Medium':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Low':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Overview Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Compliance Score</p>
              <p className={`text-3xl font-bold ${getScoreColor(complianceMetrics.overallScore)}`}>
                {complianceMetrics.overallScore}%
              </p>
              <p className="text-xs text-green-600 font-medium mt-1">{complianceMetrics.trend}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">✅</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Active Rules</p>
              <p className="text-3xl font-bold text-blue-600">{complianceMetrics.activeRules}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">📋</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Violations</p>
              <p className="text-3xl font-bold text-amber-600">{complianceMetrics.violations}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-orange-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">⚠️</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Audits Done</p>
              <p className="text-3xl font-bold text-purple-600">{complianceMetrics.auditsCompleted}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">🔍</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Data Requests</p>
              <p className="text-3xl font-bold text-indigo-600">{complianceMetrics.dataRequests}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">📨</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Time Range</p>
              <select
                value={timeRange}
                onChange={(e) => setTimeRange(e.target.value)}
                className="text-sm font-semibold text-slate-800 border-none focus:outline-none bg-transparent"
              >
                <option value="7days">7 Days</option>
                <option value="30days">30 Days</option>
                <option value="90days">90 Days</option>
                <option value="1year">1 Year</option>
              </select>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-slate-500 to-slate-600 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">📅</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <button
          onClick={onViewAuditTrail}
          className="bg-white rounded-xl p-6 shadow-lg border border-slate-100 hover:shadow-xl transition-all duration-300 group hover:scale-105 active:scale-95 text-left"
        >
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
              <span className="text-white text-2xl">📜</span>
            </div>
            <div>
              <h3 className="font-semibold text-slate-800 group-hover:text-indigo-600 transition-colors">
                View Audit Trail
              </h3>
              <p className="text-sm text-slate-600">Complete activity logs</p>
            </div>
          </div>
        </button>

        <button
          onClick={onManageRules}
          className="bg-white rounded-xl p-6 shadow-lg border border-slate-100 hover:shadow-xl transition-all duration-300 group hover:scale-105 active:scale-95 text-left"
        >
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
              <span className="text-white text-2xl">⚙️</span>
            </div>
            <div>
              <h3 className="font-semibold text-slate-800 group-hover:text-indigo-600 transition-colors">
                Manage Rules
              </h3>
              <p className="text-sm text-slate-600">Configure compliance</p>
            </div>
          </div>
        </button>

        <button
          onClick={onGenerateReport}
          className="bg-white rounded-xl p-6 shadow-lg border border-slate-100 hover:shadow-xl transition-all duration-300 group hover:scale-105 active:scale-95 text-left"
        >
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
              <span className="text-white text-2xl">📊</span>
            </div>
            <div>
              <h3 className="font-semibold text-slate-800 group-hover:text-indigo-600 transition-colors">
                Generate Report
              </h3>
              <p className="text-sm text-slate-600">Compliance reports</p>
            </div>
          </div>
        </button>

        <button
          onClick={() => alert('Data privacy settings will be available with backend integration!')}
          className="bg-white rounded-xl p-6 shadow-lg border border-slate-100 hover:shadow-xl transition-all duration-300 group hover:scale-105 active:scale-95 text-left"
        >
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
              <span className="text-white text-2xl">🔐</span>
            </div>
            <div>
              <h3 className="font-semibold text-slate-800 group-hover:text-indigo-600 transition-colors">
                Privacy Settings
              </h3>
              <p className="text-sm text-slate-600">GDPR/CCPA controls</p>
            </div>
          </div>
        </button>
      </div>

      {/* Compliance Categories */}
      <div>
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Compliance Categories</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {complianceCategories.map((category) => (
            <div
              key={category.id}
              className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100 hover:shadow-xl transition-all duration-300 group hover:scale-105 active:scale-95 cursor-pointer"
              onClick={() => alert(`View details for ${category.name} compliance`)}
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${category.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                  <span className="text-3xl">{category.icon}</span>
                </div>
                <span className={`px-3 py-1 rounded-lg text-xs font-medium border ${getStatusColor(category.status)}`}>
                  {category.status}
                </span>
              </div>
              <h3 className="text-lg font-bold text-slate-800 mb-2 group-hover:text-indigo-600 transition-colors">
                {category.name}
              </h3>
              <div className="space-y-3">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-slate-600">Compliance Score</span>
                    <span className={`text-lg font-bold ${getScoreColor(category.score)}`}>
                      {category.score}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full bg-gradient-to-r ${category.color} transition-all duration-500`}
                      style={{ width: `${category.score}%` }}
                    ></div>
                  </div>
                </div>
                <div className="flex items-center justify-between text-sm text-slate-600">
                  <span>Active Rules: {category.rules}</span>
                  <span>Last Audit: {category.lastAudit}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Violations */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-slate-800">Recent Violations</h2>
          <button
            onClick={() => alert('View all violations history')}
            className="text-indigo-600 hover:text-indigo-700 font-medium text-sm hover:scale-105 active:scale-95 transition-transform"
          >
            View All →
          </button>
        </div>
        <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
          {recentViolations.map((violation, index) => (
            <div
              key={violation.id}
              className={`p-6 hover:bg-slate-50 transition-colors cursor-pointer ${
                index !== recentViolations.length - 1 ? 'border-b border-slate-100' : ''
              }`}
              onClick={() => alert(`View details for violation: ${violation.description}`)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <span className={`px-3 py-1 rounded-lg text-xs font-medium border ${getSeverityColor(violation.severity)}`}>
                      {violation.severity}
                    </span>
                    <h3 className="font-semibold text-slate-800">{violation.type}</h3>
                  </div>
                  <p className="text-sm text-slate-700 mb-3">{violation.description}</p>
                  <div className="flex flex-wrap gap-4 text-sm text-slate-600">
                    <span>📊 Affected: {violation.affectedRecords} records</span>
                    <span>📅 Detected: {violation.detectedDate}</span>
                    <span>👤 Assigned: {violation.assignedTo}</span>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-lg text-xs font-medium ml-4 ${
                  violation.status === 'Resolved'
                    ? 'bg-green-100 text-green-800 border border-green-200'
                    : violation.status === 'In Progress'
                    ? 'bg-blue-100 text-blue-800 border border-blue-200'
                    : 'bg-amber-100 text-amber-800 border border-amber-200'
                }`}>
                  {violation.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Upcoming Audits */}
      <div>
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Upcoming Audits</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {upcomingAudits.map((audit) => (
            <div
              key={audit.id}
              className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100 hover:shadow-xl transition-all duration-300 hover:scale-105 active:scale-95 cursor-pointer"
              onClick={() => alert(`View details for: ${audit.name}`)}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
                  <span className="text-white text-2xl">📋</span>
                </div>
                <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-lg text-xs font-medium border border-blue-200">
                  {audit.type}
                </span>
              </div>
              <h3 className="font-bold text-slate-800 mb-2">{audit.name}</h3>
              <div className="space-y-2 text-sm text-slate-600">
                <p className="flex items-center">
                  <span className="mr-2">📅</span>
                  {audit.date}
                </p>
                <p className="flex items-center">
                  <span className="mr-2">🎯</span>
                  {audit.scope}
                </p>
                <p className="flex items-center">
                  <span className="mr-2">✅</span>
                  {audit.status}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
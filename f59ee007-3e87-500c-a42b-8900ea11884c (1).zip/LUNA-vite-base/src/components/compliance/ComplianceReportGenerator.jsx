import { useState } from 'react';

export default function ComplianceReportGenerator({ onBack }) {
  const [reportType, setReportType] = useState('gdpr');
  const [dateRange, setDateRange] = useState('monthly');
  const [includeDetails, setIncludeDetails] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);

  const reportTemplates = [
    {
      id: 'gdpr',
      name: 'GDPR Compliance Report',
      description: 'Comprehensive report on GDPR compliance status and data processing activities',
      icon: '🇪🇺',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      id: 'ccpa',
      name: 'CCPA Compliance Report',
      description: 'California Consumer Privacy Act compliance and data rights management',
      icon: '🇺🇸',
      color: 'from-purple-500 to-pink-500'
    },
    {
      id: 'eeo',
      name: 'Equal Opportunity Report',
      description: 'Diversity and equal opportunity metrics in hiring process',
      icon: '⚖️',
      color: 'from-green-500 to-emerald-500'
    },
    {
      id: 'audit',
      name: 'Audit Trail Summary',
      description: 'Complete audit trail summary with key activities and violations',
      icon: '📋',
      color: 'from-indigo-500 to-purple-500'
    },
    {
      id: 'security',
      name: 'Security Compliance Report',
      description: 'Security measures, access controls, and incident reports',
      icon: '🔒',
      color: 'from-orange-500 to-red-500'
    },
    {
      id: 'custom',
      name: 'Custom Report',
      description: 'Build a custom report with selected compliance metrics',
      icon: '⚙️',
      color: 'from-amber-500 to-yellow-500'
    }
  ];

  const handleGenerateReport = () => {
    setIsGenerating(true);
    
    setTimeout(() => {
      setIsGenerating(false);
      const message = document.createElement('div');
      message.className = 'fixed top-20 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
      message.innerHTML = `
        <div class="flex items-center space-x-3">
          <span class="text-xl">✅</span>
          <div>
            <p class="font-semibold">Report Generated Successfully!</p>
            <p class="text-sm opacity-90">Your compliance report is ready for download</p>
          </div>
        </div>
      `;
      document.body.appendChild(message);
      setTimeout(() => message.remove(), 4000);
    }, 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
        <button
          onClick={onBack}
          className="text-indigo-600 hover:text-indigo-700 font-medium mb-4 flex items-center space-x-2"
        >
          <span>←</span>
          <span>Back to Dashboard</span>
        </button>
        <div>
          <h1 className="text-2xl font-bold text-slate-800 mb-2">Compliance Report Generator</h1>
          <p className="text-slate-600">Generate comprehensive compliance reports for legal and audit requirements</p>
        </div>
      </div>

      {/* Report Templates */}
      <div>
        <h2 className="text-xl font-bold text-slate-800 mb-4">Select Report Type</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reportTemplates.map((template) => (
            <button
              key={template.id}
              onClick={() => setReportType(template.id)}
              className={`bg-white rounded-2xl p-6 shadow-lg border-2 transition-all duration-300 text-left hover:scale-105 active:scale-95 ${
                reportType === template.id
                  ? 'border-indigo-500 shadow-xl'
                  : 'border-slate-100 hover:border-indigo-200'
              }`}
            >
              <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${template.color} flex items-center justify-center mb-4`}>
                <span className="text-3xl">{template.icon}</span>
              </div>
              <h3 className="font-bold text-slate-800 mb-2">{template.name}</h3>
              <p className="text-sm text-slate-600">{template.description}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Report Configuration */}
      <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
        <h2 className="text-xl font-bold text-slate-800 mb-6">Report Configuration</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Date Range
            </label>
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="weekly">Last Week</option>
              <option value="monthly">Last Month</option>
              <option value="quarterly">Last Quarter</option>
              <option value="yearly">Last Year</option>
              <option value="custom">Custom Range</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Report Format
            </label>
            <select
              className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="pdf">PDF Document</option>
              <option value="excel">Excel Spreadsheet</option>
              <option value="csv">CSV File</option>
              <option value="json">JSON Data</option>
            </select>
          </div>
        </div>

        <div className="mt-6 space-y-4">
          <label className="flex items-center space-x-3 cursor-pointer">
            <input
              type="checkbox"
              checked={includeDetails}
              onChange={(e) => setIncludeDetails(e.target.checked)}
              className="w-5 h-5 text-indigo-600 rounded focus:ring-2 focus:ring-indigo-500"
            />
            <div>
              <p className="font-medium text-slate-800">Include Detailed Breakdown</p>
              <p className="text-sm text-slate-600">Add detailed metrics and individual records</p>
            </div>
          </label>

          <label className="flex items-center space-x-3 cursor-pointer">
            <input
              type="checkbox"
              defaultChecked
              className="w-5 h-5 text-indigo-600 rounded focus:ring-2 focus:ring-indigo-500"
            />
            <div>
              <p className="font-medium text-slate-800">Include Visualizations</p>
              <p className="text-sm text-slate-600">Add charts and graphs for better understanding</p>
            </div>
          </label>

          <label className="flex items-center space-x-3 cursor-pointer">
            <input
              type="checkbox"
              defaultChecked
              className="w-5 h-5 text-indigo-600 rounded focus:ring-2 focus:ring-indigo-500"
            />
            <div>
              <p className="font-medium text-slate-800">Include Recommendations</p>
              <p className="text-sm text-slate-600">Add AI-generated compliance recommendations</p>
            </div>
          </label>
        </div>
      </div>

      {/* Report Preview */}
      <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl p-8 border border-indigo-100">
        <h2 className="text-xl font-bold text-slate-800 mb-4">Report Preview</h2>
        <div className="bg-white rounded-xl p-6 shadow-lg">
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <div>
                <h3 className="font-bold text-slate-800">
                  {reportTemplates.find(t => t.id === reportType)?.name}
                </h3>
                <p className="text-sm text-slate-600">
                  Period: {dateRange === 'monthly' ? 'Last Month' : dateRange === 'quarterly' ? 'Last Quarter' : 'Custom Range'}
                </p>
              </div>
              <span className="text-3xl">
                {reportTemplates.find(t => t.id === reportType)?.icon}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-4 bg-slate-50 rounded-lg">
                <p className="text-sm text-slate-600 mb-1">Compliance Score</p>
                <p className="text-2xl font-bold text-green-600">94%</p>
              </div>
              <div className="text-center p-4 bg-slate-50 rounded-lg">
                <p className="text-sm text-slate-600 mb-1">Total Records</p>
                <p className="text-2xl font-bold text-blue-600">1,247</p>
              </div>
              <div className="text-center p-4 bg-slate-50 rounded-lg">
                <p className="text-sm text-slate-600 mb-1">Violations</p>
                <p className="text-2xl font-bold text-amber-600">3</p>
              </div>
            </div>
            <p className="text-sm text-slate-600 italic">
              * This is a preview. Actual report will contain detailed metrics and analysis.
            </p>
          </div>
        </div>
      </div>

      {/* Generate Button */}
      <div className="flex items-center justify-end space-x-4">
        <button
          onClick={onBack}
          className="px-6 py-3 text-slate-700 hover:bg-slate-100 rounded-lg transition-colors font-medium"
        >
          Cancel
        </button>
        <button
          onClick={handleGenerateReport}
          disabled={isGenerating}
          className="px-8 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium flex items-center space-x-2 disabled:opacity-50"
        >
          {isGenerating ? (
            <>
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              <span>Generating...</span>
            </>
          ) : (
            <>
              <span>📊</span>
              <span>Generate Report</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
}
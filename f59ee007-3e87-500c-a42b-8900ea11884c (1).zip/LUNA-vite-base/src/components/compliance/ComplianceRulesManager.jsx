import { useState } from 'react';

export default function ComplianceRulesManager({ onBack }) {
  const [activeTab, setActiveTab] = useState('active');
  const [showCreateModal, setShowCreateModal] = useState(false);

  const complianceRules = [
    {
      id: 1,
      name: 'Data Retention Policy',
      category: 'Data Privacy',
      description: 'Interview recordings must be deleted after 90 days unless legally required',
      severity: 'High',
      status: 'Active',
      lastModified: '2024-12-15',
      modifiedBy: 'John Anderson',
      affectedRecords: 1247,
      automationEnabled: true
    },
    {
      id: 2,
      name: 'Candidate Consent Tracking',
      category: 'Candidate Rights',
      description: 'All candidates must provide explicit consent before interview recording',
      severity: 'Critical',
      status: 'Active',
      lastModified: '2024-12-10',
      modifiedBy: 'Sarah Mitchell',
      affectedRecords: 2156,
      automationEnabled: true
    },
    {
      id: 3,
      name: 'Equal Opportunity Monitoring',
      category: 'Equal Opportunity',
      description: 'Track and report on diversity metrics in hiring process',
      severity: 'High',
      status: 'Active',
      lastModified: '2024-12-05',
      modifiedBy: 'Emily Rodriguez',
      affectedRecords: 3421,
      automationEnabled: true
    },
    {
      id: 4,
      name: 'AI Bias Detection',
      category: 'AI Ethics',
      description: 'Monitor AI interview questions for potential bias indicators',
      severity: 'High',
      status: 'Active',
      lastModified: '2024-12-01',
      modifiedBy: 'David Park',
      affectedRecords: 892,
      automationEnabled: true
    },
    {
      id: 5,
      name: 'Access Control Audit',
      category: 'Security',
      description: 'Log all access to sensitive candidate information',
      severity: 'Critical',
      status: 'Active',
      lastModified: '2024-11-28',
      modifiedBy: 'Lisa Anderson',
      affectedRecords: 5678,
      automationEnabled: true
    },
    {
      id: 6,
      name: 'GDPR Right to Erasure',
      category: 'Data Privacy',
      description: 'Process candidate data deletion requests within 30 days',
      severity: 'Critical',
      status: 'Active',
      lastModified: '2024-11-25',
      modifiedBy: 'James Wilson',
      affectedRecords: 45,
      automationEnabled: false
    },
    {
      id: 7,
      name: 'Interview Recording Quality',
      category: 'Interview Recording',
      description: 'Ensure minimum video quality standards for all recordings',
      severity: 'Medium',
      status: 'Draft',
      lastModified: '2024-11-20',
      modifiedBy: 'Maria Garcia',
      affectedRecords: 0,
      automationEnabled: false
    },
    {
      id: 8,
      name: 'Candidate Feedback Collection',
      category: 'Candidate Rights',
      description: 'Collect feedback from candidates after interview completion',
      severity: 'Low',
      status: 'Active',
      lastModified: '2024-11-15',
      modifiedBy: 'Robert Taylor',
      affectedRecords: 1834,
      automationEnabled: true
    }
  ];

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'Critical':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'High':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Medium':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Low':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Active':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Draft':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Inactive':
        return 'bg-slate-100 text-slate-800 border-slate-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const filteredRules = complianceRules.filter(rule => {
    if (activeTab === 'all') return true;
    return rule.status.toLowerCase() === activeTab;
  });

  const handleToggleAutomation = (ruleId) => {
    alert(`Toggling automation for rule ID: ${ruleId}\n\nThis will be implemented with backend integration!`);
  };

  const handleEditRule = (rule) => {
    alert(`Editing rule: ${rule.name}\n\nRule editor will be available with backend integration!`);
  };

  const handleDeleteRule = (rule) => {
    if (confirm(`Are you sure you want to delete the rule: ${rule.name}?`)) {
      alert('Rule deletion will be implemented with backend integration!');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
        <button
          onClick={onBack}
          className="text-indigo-600 hover:text-indigo-700 font-medium mb-4 flex items-center space-x-2"
        >
          <span>←</span>
          <span>Back to Dashboard</span>
        </button>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-800 mb-2">Compliance Rules Manager</h1>
            <p className="text-slate-600">Configure and manage compliance requirements</p>
          </div>
          <button
            onClick={() => setShowCreateModal(true)}
            className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium flex items-center space-x-2"
          >
            <span>➕</span>
            <span>Create Rule</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl p-2 shadow-lg border border-slate-100 inline-flex">
        <button
          onClick={() => setActiveTab('all')}
          className={`px-6 py-2 rounded-lg font-medium transition-all ${
            activeTab === 'all'
              ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
              : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          All Rules ({complianceRules.length})
        </button>
        <button
          onClick={() => setActiveTab('active')}
          className={`px-6 py-2 rounded-lg font-medium transition-all ${
            activeTab === 'active'
              ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
              : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          Active ({complianceRules.filter(r => r.status === 'Active').length})
        </button>
        <button
          onClick={() => setActiveTab('draft')}
          className={`px-6 py-2 rounded-lg font-medium transition-all ${
            activeTab === 'draft'
              ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
              : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          Draft ({complianceRules.filter(r => r.status === 'Draft').length})
        </button>
      </div>

      {/* Rules List */}
      <div className="space-y-4">
        {filteredRules.map((rule) => (
          <div
            key={rule.id}
            className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100 hover:shadow-xl transition-all duration-300"
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-3">
                  <h3 className="text-lg font-bold text-slate-800">{rule.name}</h3>
                  <span className={`px-3 py-1 rounded-lg text-xs font-medium border ${getSeverityColor(rule.severity)}`}>
                    {rule.severity}
                  </span>
                  <span className={`px-3 py-1 rounded-lg text-xs font-medium border ${getStatusColor(rule.status)}`}>
                    {rule.status}
                  </span>
                </div>
                <p className="text-sm text-slate-700 mb-4">{rule.description}</p>
                <div className="flex flex-wrap gap-4 text-sm text-slate-600">
                  <span className="flex items-center">
                    <span className="mr-1">📂</span>
                    {rule.category}
                  </span>
                  <span className="flex items-center">
                    <span className="mr-1">📊</span>
                    {rule.affectedRecords} records
                  </span>
                  <span className="flex items-center">
                    <span className="mr-1">📅</span>
                    Modified: {rule.lastModified}
                  </span>
                  <span className="flex items-center">
                    <span className="mr-1">👤</span>
                    By: {rule.modifiedBy}
                  </span>
                </div>
              </div>
              <div className="flex flex-col space-y-2 ml-6">
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-slate-600">Automation:</span>
                  <button
                    onClick={() => handleToggleAutomation(rule.id)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      rule.automationEnabled ? 'bg-green-600' : 'bg-slate-300'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        rule.automationEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>
                <button
                  onClick={() => handleEditRule(rule)}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm font-medium"
                >
                  Edit Rule
                </button>
                <button
                  onClick={() => handleDeleteRule(rule)}
                  className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm font-medium"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Create Rule Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full p-8">
            <h2 className="text-2xl font-bold text-slate-800 mb-6">Create New Compliance Rule</h2>
            <p className="text-slate-600 mb-6">
              Rule creation form will be available with backend integration!
            </p>
            <div className="flex items-center justify-end space-x-4">
              <button
                onClick={() => setShowCreateModal(false)}
                className="px-6 py-3 text-slate-700 hover:bg-slate-100 rounded-lg transition-colors font-medium"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  alert('Rule creation will be implemented with backend integration!');
                  setShowCreateModal(false);
                }}
                className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium"
              >
                Create Rule
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
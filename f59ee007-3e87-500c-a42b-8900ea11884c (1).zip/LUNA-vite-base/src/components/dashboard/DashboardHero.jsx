export default function DashboardHero({ currentRole }) {
  const heroContent = {
    employer: {
      title: 'Welcome Back, Hiring Manager!',
      subtitle: 'Streamline your recruitment process with AI-powered video interviews',
      gradient: 'from-indigo-600 to-purple-600'
    },
    candidate: {
      title: 'Your Interview Journey Starts Here',
      subtitle: 'Prepare, practice, and excel in your upcoming video interviews',
      gradient: 'from-blue-600 to-cyan-600'
    },
    panelist: {
      title: 'Expert Panel Dashboard',
      subtitle: 'Review interviews and provide valuable feedback to candidates',
      gradient: 'from-purple-600 to-pink-600'
    },
    admin: {
      title: 'System Administration Center',
      subtitle: 'Monitor platform performance and manage all operations',
      gradient: 'from-slate-700 to-slate-900'
    }
  };

  const content = heroContent[currentRole];

  return (
    <section className="relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-0 left-0 w-96 h-96 bg-indigo-300 rounded-full mix-blend-multiply filter blur-3xl animate-blob"></div>
          <div className="absolute top-0 right-0 w-96 h-96 bg-purple-300 rounded-full mix-blend-multiply filter blur-3xl animate-blob animation-delay-2000"></div>
          <div className="absolute bottom-0 left-1/2 w-96 h-96 bg-pink-300 rounded-full mix-blend-multiply filter blur-3xl animate-blob animation-delay-4000"></div>
        </div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
        <div className="text-center">
          <h1 className={`text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 bg-gradient-to-r ${content.gradient} bg-clip-text text-transparent animate-fade-in`}>
            {content.title}
          </h1>
          <p className="text-xl sm:text-2xl text-slate-600 max-w-3xl mx-auto mb-8 animate-fade-in-delay">
            {content.subtitle}
          </p>
          
          {/* Quick Stats */}
          <div className="flex flex-wrap justify-center gap-6 mt-12">
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl px-6 py-4 shadow-lg hover:shadow-xl transition-shadow">
              <p className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                {currentRole === 'employer' ? '24' : currentRole === 'candidate' ? '3' : currentRole === 'panelist' ? '12' : '156'}
              </p>
              <p className="text-sm text-slate-600 mt-1">
                {currentRole === 'employer' ? 'Active Jobs' : currentRole === 'candidate' ? 'Interviews' : currentRole === 'panelist' ? 'Pending Reviews' : 'Total Users'}
              </p>
            </div>
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl px-6 py-4 shadow-lg hover:shadow-xl transition-shadow">
              <p className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                {currentRole === 'employer' ? '89' : currentRole === 'candidate' ? '85%' : currentRole === 'panelist' ? '$2,450' : '98.5%'}
              </p>
              <p className="text-sm text-slate-600 mt-1">
                {currentRole === 'employer' ? 'Candidates' : currentRole === 'candidate' ? 'Success Rate' : currentRole === 'panelist' ? 'Earnings' : 'Uptime'}
              </p>
            </div>
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl px-6 py-4 shadow-lg hover:shadow-xl transition-shadow">
              <p className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                {currentRole === 'employer' ? '12' : currentRole === 'candidate' ? '2' : currentRole === 'panelist' ? '8' : '45'}
              </p>
              <p className="text-sm text-slate-600 mt-1">
                {currentRole === 'employer' ? 'New Today' : currentRole === 'candidate' ? 'Upcoming' : currentRole === 'panelist' ? 'Completed' : 'Active Jobs'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
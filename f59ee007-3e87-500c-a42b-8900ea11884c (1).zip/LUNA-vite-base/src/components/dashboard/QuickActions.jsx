import { useNavigate } from 'react-router-dom';

export default function QuickActions({ currentRole }) {
  const navigate = useNavigate();

const handleActionClick = (action) => {
    // Handle Post New Job action
    if (action.title === 'Post New Job') {
      navigate('/jobs');
      return;
    }

    // Handle Schedule Interview action
    if (action.title === 'Schedule Interview' || action.title === 'View Schedule') {
      navigate('/scheduling');
      return;
    }

    // Handle Start Live Interview action
    if (action.title === 'Start Live Interview') {
      navigate('/interview');
      return;
    }

    // Handle View Analytics action
    if (action.title === 'View Analytics') {
      navigate('/evaluations');
      return;
    }

    // Handle Manage Profile action for candidates
    if (action.title === 'Manage Profile') {
      navigate('/candidate/profile');
      return;
    }

    // Handle Search Candidates action for employers
    if (action.title === 'Search Candidates') {
      navigate('/employer/candidates');
      return;
    }

    // Handle View Recordings action
    if (action.title === 'View Recordings' || action.title === 'Review Interview') {
      navigate('/recordings');
      return;
    }

    // Handle Bias Detection action
    if (action.title === 'Bias Detection') {
      navigate('/bias-detection');
      return;
    }

    // Handle Collaborative Evaluation action
    if (action.title === 'Collaborative Evaluation') {
      navigate('/collaborative-evaluation');
      return;
    }

    // Handle Submit Feedback action
    if (action.title === 'Submit Feedback') {
      navigate('/candidate-feedback');
      return;
    }

    // Show loading state for other actions
    const button = event.currentTarget;
    button.classList.add('scale-95');
    
    setTimeout(() => {
      button.classList.remove('scale-95');
      
      // Show action-specific message
      const messages = {
        'Setup AI Interview': 'Launching AI interview configuration...',
        'Assign Human Interviewer': 'Opening panelist selection...',
        'Browse Jobs': 'Searching available positions...',
        'Practice with AI': 'Starting AI practice session...',
        'Prepare for Human Interview': 'Loading interview preparation guide...',
        'View Feedback': 'Fetching your feedback history...',
        'Payment History': 'Fetching payment records...',
        'User Management': 'Opening user management panel...',
        'System Settings': 'Loading system configuration...',
        'Reports': 'Generating reports...',
        'Support Tickets': 'Opening support ticket system...'
      };

      const message = document.createElement('div');
      message.className = 'fixed top-20 right-4 bg-indigo-600 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
      message.innerHTML = `
        <div class="flex items-center space-x-3">
          <div class="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
          <span>${messages[action.title] || 'Processing...'}</span>
        </div>
      `;
      document.body.appendChild(message);
      
      setTimeout(() => {
        message.remove();
        alert(`${action.title} feature will be fully implemented with backend integration!\n\nThis will include:\n- ${action.description}\n- Real-time updates\n- Data persistence\n- Full functionality`);
      }, 1500);
    }, 200);
  };

const actions = {
    employer: [
      { title: 'Post New Job', icon: '➕', color: 'from-indigo-500 to-purple-600', description: 'Create a new job posting', route: '/jobs' },
      { title: 'Search Candidates', icon: '🔍', color: 'from-blue-500 to-cyan-600', description: 'Find and evaluate candidates', route: '/employer/candidates' },
      { title: 'Skills Assessment', icon: '🎯', color: 'from-orange-500 to-red-600', description: 'Create skill tests', route: '/skills-assessment' },
      { title: 'View Analytics', icon: '📊', color: 'from-purple-500 to-pink-600', description: 'Check hiring metrics' }
    ],
    candidate: [
      { title: 'Browse Jobs', icon: '🔍', color: 'from-blue-500 to-cyan-600', description: 'Find opportunities' },
      { title: 'Manage Profile', icon: '👤', color: 'from-indigo-500 to-purple-600', description: 'Update your profile', route: '/candidate/profile' },
      { title: 'Submit Feedback', icon: '💬', color: 'from-green-500 to-emerald-600', description: 'Share your experience', route: '/candidate-feedback' },
      { title: 'View Recordings', icon: '🎥', color: 'from-purple-500 to-pink-600', description: 'Review your interviews', route: '/recordings' }
    ],
    panelist: [
      { title: 'Collaborative Evaluation', icon: '🤝', color: 'from-green-500 to-emerald-600', description: 'Team evaluation workspace', route: '/collaborative-evaluation' },
      { title: 'View Recordings', icon: '🎥', color: 'from-indigo-500 to-purple-600', description: 'Review interview recordings', route: '/recordings' },
      { title: 'View Schedule', icon: '📅', color: 'from-blue-500 to-cyan-600', description: 'Check assignments', route: '/scheduling' },
      { title: 'Payment History', icon: '💰', color: 'from-amber-500 to-yellow-500', description: 'Track earnings' }
    ],
    admin: [
      { title: 'AI Proctoring', icon: '🎥', color: 'from-blue-500 to-cyan-600', description: 'Real-time monitoring', route: '/proctoring' },
      { title: 'Panel Management', icon: '👥', color: 'from-purple-500 to-pink-600', description: 'Manage panelists', route: '/panel-management' },
      { title: 'Compliance & Audit', icon: '🔒', color: 'from-green-500 to-emerald-600', description: 'Compliance management', route: '/compliance' },
      { title: 'Bias Detection', icon: '⚖️', color: 'from-orange-500 to-red-600', description: 'Platform-wide fairness', route: '/bias-detection' }
    ]
  };

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 bg-white/50">
      <h2 className="text-2xl font-bold text-slate-800 mb-8 text-center">Quick Actions</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {actions[currentRole].map((action, index) => (
          <button
            key={index}
            onClick={() => handleActionClick(action)}
            className="group bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-slate-100 text-left hover:scale-105 active:scale-95"
          >
            <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${action.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
              <span className="text-2xl">{action.icon}</span>
            </div>
            <h3 className="font-semibold text-slate-800 mb-2 group-hover:text-indigo-600 transition-colors">
              {action.title}
            </h3>
            <p className="text-sm text-slate-600">{action.description}</p>
          </button>
        ))}
      </div>
    </section>
  );
}
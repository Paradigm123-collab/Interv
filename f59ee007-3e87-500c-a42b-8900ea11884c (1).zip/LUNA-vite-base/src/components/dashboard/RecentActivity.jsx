export default function RecentActivity({ currentRole }) {
  const activities = {
    employer: [
      { id: 1, type: 'application', message: 'New application received for Senior React Developer', time: '5 minutes ago', icon: '📩' },
      { id: 2, type: 'interview', message: 'Interview completed with Sarah Mitchell', time: '1 hour ago', icon: '✅' },
      { id: 3, type: 'alert', message: 'Integrity alert for Michael Chen interview', time: '2 hours ago', icon: '⚠️' },
      { id: 4, type: 'application', message: '3 new applications for Product Manager role', time: '3 hours ago', icon: '📩' },
      { id: 5, type: 'interview', message: 'Interview scheduled with Emily Rodriguez', time: '5 hours ago', icon: '📅' }
    ],
    candidate: [
      { id: 1, type: 'feedback', message: 'New feedback received from TechCorp Solutions', time: '30 minutes ago', icon: '💬' },
      { id: 2, type: 'interview', message: 'Interview reminder: Tomorrow at 2:00 PM', time: '2 hours ago', icon: '🔔' },
      { id: 3, type: 'application', message: 'Your application was viewed by Innovation Labs', time: '4 hours ago', icon: '👁️' },
      { id: 4, type: 'interview', message: 'Interview scheduled for Jan 2, 2025', time: '1 day ago', icon: '📅' },
      { id: 5, type: 'feedback', message: 'Positive feedback from Digital Dynamics', time: '2 days ago', icon: '⭐' }
    ],
    panelist: [
      { id: 1, type: 'assignment', message: 'New interview assigned: Sarah Mitchell', time: '1 hour ago', icon: '📋' },
      { id: 2, type: 'payment', message: 'Payment of $150 processed', time: '3 hours ago', icon: '💰' },
      { id: 3, type: 'review', message: 'Feedback submitted for Michael Chen', time: '5 hours ago', icon: '✅' },
      { id: 4, type: 'assignment', message: 'Interview scheduled for tomorrow', time: '1 day ago', icon: '📅' },
      { id: 5, type: 'payment', message: 'Monthly earnings: $2,450', time: '2 days ago', icon: '💵' }
    ],
    admin: [
      { id: 1, type: 'user', message: 'New employer registered: TechCorp Solutions', time: '10 minutes ago', icon: '👤' },
      { id: 2, type: 'system', message: 'System backup completed successfully', time: '1 hour ago', icon: '💾' },
      { id: 3, type: 'alert', message: 'High server load detected', time: '2 hours ago', icon: '⚠️' },
      { id: 4, type: 'payment', message: 'Payment batch processed: $12,500', time: '4 hours ago', icon: '💳' },
      { id: 5, type: 'user', message: '25 new users registered today', time: '6 hours ago', icon: '📈' }
    ]
  };

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-bold text-slate-800">Recent Activity</h2>
        <button className="text-indigo-600 hover:text-indigo-700 font-medium text-sm">
          View All →
        </button>
      </div>
      <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
{activities[currentRole].map((activity, index) => (
          <button
            key={activity.id}
            onClick={() => {
              alert(`Activity Details:\n\n${activity.message}\nTime: ${activity.time}\n\nClick to view full details and take action!`);
            }}
            className={`w-full p-6 hover:bg-slate-50 transition-colors text-left ${
              index !== activities[currentRole].length - 1 ? 'border-b border-slate-100' : ''
            }`}
          >
            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-xl flex-shrink-0">
                {activity.icon}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-800">{activity.message}</p>
                <p className="text-xs text-slate-500 mt-1">{activity.time}</p>
              </div>
            </div>
          </button>
        ))}
      </div>
    </section>
  );
}
import EmployerDashboard from './roles/EmployerDashboard';
import CandidateDashboard from './roles/CandidateDashboard';
import PanelistDashboard from './roles/PanelistDashboard';
import AdminDashboard from './roles/AdminDashboard';

export default function RoleDashboard({ currentRole }) {
  const dashboards = {
    employer: <EmployerDashboard />,
    candidate: <CandidateDashboard />,
    panelist: <PanelistDashboard />,
    admin: <AdminDashboard />
  };

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {dashboards[currentRole]}
    </section>
  );
}
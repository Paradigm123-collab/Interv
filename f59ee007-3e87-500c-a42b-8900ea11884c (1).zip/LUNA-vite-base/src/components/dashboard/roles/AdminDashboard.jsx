export default function AdminDashboard() {
  const systemMetrics = [
    { label: 'Total Users', value: '2,456', change: '+12%', trend: 'up', color: 'from-blue-500 to-cyan-500' },
    { label: 'Active Interviews', value: '342', change: '+8%', trend: 'up', color: 'from-green-500 to-emerald-500' },
    { label: 'System Uptime', value: '99.8%', change: '+0.2%', trend: 'up', color: 'from-purple-500 to-pink-500' },
    { label: 'Revenue', value: '$45.2K', change: '+15%', trend: 'up', color: 'from-orange-500 to-red-500' }
  ];

  const recentActivity = [
    { id: 1, type: 'user', action: 'New employer registered', user: 'TechCorp Solutions', time: '5 minutes ago', icon: '👤' },
    { id: 2, type: 'interview', action: 'Interview completed', user: 'Sarah Mitchell', time: '15 minutes ago', icon: '🎥' },
    { id: 3, type: 'payment', action: 'Payment processed', user: 'John Anderson', time: '1 hour ago', icon: '💳' },
    { id: 4, type: 'alert', action: 'Integrity alert triggered', user: 'Michael Chen', time: '2 hours ago', icon: '⚠️' },
    { id: 5, type: 'user', action: 'New candidate registered', user: 'Emily Rodriguez', time: '3 hours ago', icon: '👤' },
    { id: 6, type: 'interview', action: 'Interview scheduled', user: 'David Park', time: '4 hours ago', icon: '📅' },
    { id: 7, type: 'system', action: 'System backup completed', user: 'Automated', time: '5 hours ago', icon: '💾' },
    { id: 8, type: 'payment', action: 'Panelist payment sent', user: 'Lisa Anderson', time: '6 hours ago', icon: '💰' }
  ];

  const platformStats = [
    { category: 'Employers', count: 156, percentage: 25, color: 'bg-blue-500' },
    { category: 'Candidates', count: 1842, percentage: 60, color: 'bg-green-500' },
    { category: 'Panelists', count: 458, percentage: 15, color: 'bg-purple-500' }
  ];

  return (
    <div className="space-y-8">
      {/* System Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {systemMetrics.map((metric, index) => (
          <div
            key={index}
            className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-slate-100"
          >
            <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${metric.color} flex items-center justify-center mb-4`}>
              <span className="text-white text-xl font-bold">📊</span>
            </div>
            <p className="text-sm text-slate-600 mb-1">{metric.label}</p>
            <div className="flex items-end justify-between">
              <p className="text-3xl font-bold text-slate-800">{metric.value}</p>
              <span className={`text-sm font-medium ${
                metric.trend === 'up' ? 'text-green-600' : 'text-red-600'
              }`}>
                {metric.change}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Platform Statistics */}
      <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Platform Distribution</h2>
        <div className="space-y-6">
          {platformStats.map((stat, index) => (
            <div key={index}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-slate-700">{stat.category}</span>
                <span className="text-sm font-semibold text-slate-800">{stat.count} users</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
                <div
                  className={`h-full ${stat.color} rounded-full transition-all duration-500`}
                  style={{ width: `${stat.percentage}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-slate-800">Recent Activity</h2>
          <button className="text-indigo-600 hover:text-indigo-700 font-medium text-sm">
            View All →
          </button>
        </div>
        <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
          {recentActivity.map((activity, index) => (
            <div
              key={activity.id}
              className={`p-6 hover:bg-slate-50 transition-colors ${
                index !== recentActivity.length - 1 ? 'border-b border-slate-100' : ''
              }`}
            >
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-xl">
                  {activity.icon}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-800">{activity.action}</p>
                  <p className="text-sm text-slate-600">{activity.user}</p>
                </div>
                <span className="text-xs text-slate-500">{activity.time}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
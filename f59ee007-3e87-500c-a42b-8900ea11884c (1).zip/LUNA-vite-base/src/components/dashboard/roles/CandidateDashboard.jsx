export default function CandidateDashboard() {
  const upcomingInterviews = [
    {
      id: 1,
      company: 'TechCorp Solutions',
      position: 'Senior React Developer',
      date: 'Dec 28, 2024',
      time: '2:00 PM',
      duration: '45 min',
      status: 'Scheduled',
      type: 'AI',
      logo: 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=100&h=100&fit=crop'
    },
    {
      id: 2,
      company: 'Innovation Labs',
      position: 'Full Stack Engineer',
      date: 'Dec 30, 2024',
      time: '10:00 AM',
      duration: '60 min',
      status: 'Scheduled',
      type: 'Human',
      interviewer: 'Dr. Sarah Johnson',
      logo: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=100&h=100&fit=crop'
    },
    {
      id: 3,
      company: 'Digital Dynamics',
      position: 'Frontend Developer',
      date: 'Jan 2, 2025',
      time: '3:30 PM',
      duration: '30 min',
      status: 'Pending',
      type: 'AI',
      logo: 'https://images.unsplash.com/photo-1572044162444-ad60f128bdea?w=100&h=100&fit=crop'
    }
  ];

  const recentFeedback = [
    {
      id: 1,
      company: 'StartupHub Inc',
      position: 'React Developer',
      date: 'Dec 20, 2024',
      rating: 4.5,
      feedback: 'Excellent technical skills and communication. Strong problem-solving abilities demonstrated.',
      status: 'Positive'
    },
    {
      id: 2,
      company: 'CloudTech Systems',
      position: 'Software Engineer',
      date: 'Dec 18, 2024',
      rating: 4.0,
      feedback: 'Good understanding of core concepts. Would benefit from more experience with cloud technologies.',
      status: 'Positive'
    },
    {
      id: 3,
      company: 'WebFlow Agency',
      position: 'Frontend Developer',
      date: 'Dec 15, 2024',
      rating: 3.5,
      feedback: 'Solid foundation in frontend development. Recommended to practice more complex state management scenarios.',
      status: 'Neutral'
    },
    {
      id: 4,
      company: 'DataViz Corp',
      position: 'UI Developer',
      date: 'Dec 12, 2024',
      rating: 4.8,
      feedback: 'Outstanding presentation and design thinking. Impressive portfolio showcasing modern UI/UX principles.',
      status: 'Positive'
    },
    {
      id: 5,
      company: 'MobileTech Solutions',
      position: 'React Native Developer',
      date: 'Dec 10, 2024',
      rating: 4.2,
      feedback: 'Strong mobile development skills. Great understanding of cross-platform development challenges.',
      status: 'Positive'
    }
  ];

  return (
    <div className="space-y-8">
      {/* Upcoming Interviews */}
      <div>
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Upcoming Interviews</h2>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {upcomingInterviews.map((interview) => (
            <div
              key={interview.id}
              className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-slate-100 group"
            >
              <div className="flex items-start space-x-4 mb-4">
                <img
                  src={interview.logo}
                  alt={interview.company}
                  className="w-16 h-16 rounded-xl object-cover border-2 border-slate-100"
                />
                <div className="flex-1">
                  <h3 className="font-semibold text-slate-800 mb-1">{interview.company}</h3>
                  <p className="text-sm text-slate-600 line-clamp-2">{interview.position}</p>
                </div>
              </div>
              
<div className="space-y-3 mb-4">
                <div className="flex items-center text-sm text-slate-600">
                  <span className="mr-2">📅</span>
                  <span>{interview.date}</span>
                </div>
                <div className="flex items-center text-sm text-slate-600">
                  <span className="mr-2">🕐</span>
                  <span>{interview.time} ({interview.duration})</span>
                </div>
                <div className="flex items-center text-sm">
                  <span className="mr-2">{interview.type === 'AI' ? '🤖' : '👨‍💼'}</span>
                  <span className={`font-medium ${
                    interview.type === 'AI' ? 'text-purple-600' : 'text-blue-600'
                  }`}>
                    {interview.type === 'AI' ? 'AI Interview' : `Human Interview${interview.interviewer ? ` - ${interview.interviewer}` : ''}`}
                  </span>
                </div>
              </div>

<div className="flex items-center justify-between pt-4 border-t border-slate-100">
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                  interview.status === 'Scheduled' 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {interview.status}
                </span>
<button 
                  onClick={() => {
                    window.location.href = '/#/interview-prep';
                  }}
                  className="text-indigo-600 hover:text-indigo-700 font-medium text-sm group-hover:translate-x-1 transition-transform hover:scale-110 active:scale-95"
                >
                  Prepare →
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Feedback */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-slate-800">Recent Feedback</h2>
          <button className="text-indigo-600 hover:text-indigo-700 font-medium text-sm">
            View All →
          </button>
        </div>
        <div className="space-y-4">
          {recentFeedback.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-slate-100"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="font-semibold text-slate-800">{item.company}</h3>
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      item.status === 'Positive' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {item.status}
                    </span>
                  </div>
                  <p className="text-sm text-slate-600 mb-1">{item.position}</p>
                  <p className="text-xs text-slate-500">{item.date}</p>
                </div>
                <div className="flex items-center space-x-1">
                  <span className="text-yellow-500 text-xl">⭐</span>
                  <span className="font-bold text-slate-800">{item.rating}</span>
                </div>
              </div>
              <p className="text-sm text-slate-700 leading-relaxed">{item.feedback}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
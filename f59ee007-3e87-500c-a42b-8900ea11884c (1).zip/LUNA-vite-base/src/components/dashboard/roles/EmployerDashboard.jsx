import { useNavigate } from 'react-router-dom';

export default function EmployerDashboard() {
  const navigate = useNavigate();

const jobStats = [
    { id: 1, title: 'Senior React Developer', applicants: 45, interviews: 12, status: 'Active', color: 'from-green-500 to-emerald-500', interviewType: 'AI' },
    { id: 2, title: 'Product Manager', applicants: 67, interviews: 18, status: 'Active', color: 'from-blue-500 to-cyan-500', interviewType: 'Human' },
    { id: 3, title: 'UX Designer', applicants: 34, interviews: 8, status: 'Active', color: 'from-purple-500 to-pink-500', interviewType: 'Both' },
    { id: 4, title: 'DevOps Engineer', applicants: 28, interviews: 6, status: 'Active', color: 'from-orange-500 to-red-500', interviewType: 'AI' },
    { id: 5, title: 'Data Scientist', applicants: 52, interviews: 15, status: 'Active', color: 'from-indigo-500 to-purple-500', interviewType: 'Human' },
    { id: 6, title: 'Marketing Manager', applicants: 41, interviews: 10, status: 'Active', color: 'from-pink-500 to-rose-500', interviewType: 'Both' },
    { id: 7, title: 'Sales Executive', applicants: 38, interviews: 9, status: 'Active', color: 'from-teal-500 to-cyan-500', interviewType: 'AI' },
    { id: 8, title: 'Content Writer', applicants: 29, interviews: 7, status: 'Active', color: 'from-amber-500 to-yellow-500', interviewType: 'Human' }
  ];

  const interviewStats = {
    ai: { total: 156, completed: 142, pending: 14, successRate: '94%' },
    human: { total: 89, completed: 78, pending: 11, successRate: '88%' }
  };

  const integrityAlerts = [
    { id: 1, candidate: 'Sarah Mitchell', job: 'Senior React Developer', issue: 'Multiple face detection', severity: 'high', time: '2 hours ago', type: 'AI' },
    { id: 2, candidate: 'Michael Chen', job: 'Product Manager', issue: 'Background noise detected', severity: 'medium', time: '5 hours ago', type: 'Human' },
    { id: 3, candidate: 'Emily Rodriguez', job: 'UX Designer', issue: 'Eye tracking anomaly', severity: 'low', time: '1 day ago', type: 'AI' }
  ];

  return (
    <div className="space-y-8">
      {/* Interview Type Statistics */}
      <div>
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Interview Performance Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* AI Interviews Card */}
          <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl p-6 text-white shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <span className="text-2xl">🤖</span>
                </div>
                <div>
                  <h3 className="text-lg font-bold">AI Interviews</h3>
                  <p className="text-sm opacity-90">Automated & Consistent</p>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 mt-6">
              <div>
                <p className="text-sm opacity-90">Total</p>
                <p className="text-3xl font-bold">{interviewStats.ai.total}</p>
              </div>
              <div>
                <p className="text-sm opacity-90">Success Rate</p>
                <p className="text-3xl font-bold">{interviewStats.ai.successRate}</p>
              </div>
              <div>
                <p className="text-sm opacity-90">Completed</p>
                <p className="text-xl font-semibold">{interviewStats.ai.completed}</p>
              </div>
              <div>
                <p className="text-sm opacity-90">Pending</p>
                <p className="text-xl font-semibold">{interviewStats.ai.pending}</p>
              </div>
            </div>
          </div>

          {/* Human Interviews Card */}
          <div className="bg-gradient-to-br from-blue-500 to-cyan-600 rounded-2xl p-6 text-white shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <span className="text-2xl">👨‍💼</span>
                </div>
                <div>
                  <h3 className="text-lg font-bold">Human Interviews</h3>
                  <p className="text-sm opacity-90">Personal & Nuanced</p>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 mt-6">
              <div>
                <p className="text-sm opacity-90">Total</p>
                <p className="text-3xl font-bold">{interviewStats.human.total}</p>
              </div>
              <div>
                <p className="text-sm opacity-90">Success Rate</p>
                <p className="text-3xl font-bold">{interviewStats.human.successRate}</p>
              </div>
              <div>
                <p className="text-sm opacity-90">Completed</p>
                <p className="text-xl font-semibold">{interviewStats.human.completed}</p>
              </div>
              <div>
                <p className="text-sm opacity-90">Pending</p>
                <p className="text-xl font-semibold">{interviewStats.human.pending}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Job Statistics Grid */}
      <div>
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Active Job Positions</h2>
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {jobStats.map((job) => (
          <div
            key={job.id}
            onClick={() => navigate('/jobs')}
            className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-slate-100 group cursor-pointer hover:scale-105 active:scale-95"
          >
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${job.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <span className="text-white text-xl font-bold">💼</span>
              </div>
              <h3 className="font-semibold text-slate-800 mb-2 line-clamp-2">{job.title}</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Applicants</span>
                  <span className="font-semibold text-slate-800">{job.applicants}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Interviews</span>
                  <span className="font-semibold text-indigo-600">{job.interviews}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Interview Type</span>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                    job.interviewType === 'AI' 
                      ? 'bg-purple-100 text-purple-800'
                      : job.interviewType === 'Human'
                      ? 'bg-blue-100 text-blue-800'
                      : 'bg-green-100 text-green-800'
                  }`}>
                    {job.interviewType === 'Both' ? '🤖 + 👨‍💼' : job.interviewType === 'AI' ? '🤖 AI' : '👨‍💼 Human'}
                  </span>
                </div>
                <div className="pt-2 border-t border-slate-100">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    {job.status}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

{/* Integrity Alerts */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-slate-800">Integrity Alerts</h2>
          <button 
            onClick={() => navigate('/evaluations')}
            className="text-indigo-600 hover:text-indigo-700 font-medium text-sm hover:scale-105 active:scale-95 transition-transform"
          >
            View All Evaluations →
          </button>
        </div>
        <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
          {integrityAlerts.map((alert, index) => (
            <div
              key={alert.id}
              className={`p-6 hover:bg-slate-50 transition-colors ${
                index !== integrityAlerts.length - 1 ? 'border-b border-slate-100' : ''
              }`}
            >
<div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <span
                      className={`w-2 h-2 rounded-full ${
                        alert.severity === 'high'
                          ? 'bg-red-500'
                          : alert.severity === 'medium'
                          ? 'bg-yellow-500'
                          : 'bg-blue-500'
                      }`}
                    ></span>
                    <h3 className="font-semibold text-slate-800">{alert.candidate}</h3>
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        alert.severity === 'high'
                          ? 'bg-red-100 text-red-800'
                          : alert.severity === 'medium'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}
                    >
                      {alert.severity.toUpperCase()}
                    </span>
                    <span className="text-xs text-slate-500">
                      {alert.type === 'AI' ? '🤖 AI Interview' : '👨‍💼 Human Interview'}
                    </span>
                  </div>
                  <p className="text-sm text-slate-600 mb-1">{alert.job}</p>
                  <p className="text-sm text-slate-800 font-medium">{alert.issue}</p>
                  <p className="text-xs text-slate-500 mt-2">{alert.time}</p>
                </div>
<div className="flex flex-col space-y-2 ml-4">
                  <button
                    onClick={() => navigate('/recordings')}
                    className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-sm font-medium hover:scale-105 active:scale-95 whitespace-nowrap"
                  >
                    View Recording
                  </button>
                  <button 
                    onClick={() => {
                      alert(`Reviewing integrity alert for ${alert.candidate}\n\nIssue: ${alert.issue}\nSeverity: ${alert.severity}\nInterview Type: ${alert.type}\n\nDetailed review interface will be available with backend integration!`);
                    }}
                    className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm font-medium hover:scale-105 active:scale-95 whitespace-nowrap"
                  >
                    Review Alert
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
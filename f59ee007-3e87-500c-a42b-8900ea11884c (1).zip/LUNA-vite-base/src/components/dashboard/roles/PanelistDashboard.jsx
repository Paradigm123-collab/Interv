export default function PanelistDashboard() {
const assignedInterviews = [
    {
      id: 1,
      candidate: 'Sarah Mitchell',
      position: 'Senior React Developer',
      company: 'TechCorp Solutions',
      scheduledDate: 'Dec 28, 2024',
      scheduledTime: '2:00 PM',
      status: 'Pending Review',
      duration: '45 min',
      payment: '$150',
      type: 'Human'
    },
{
      id: 2,
      candidate: 'Michael Chen',
      position: 'Full Stack Engineer',
      company: 'Innovation Labs',
      scheduledDate: 'Dec 29, 2024',
      scheduledTime: '10:00 AM',
      status: 'Scheduled',
      duration: '60 min',
      payment: '$200',
      type: 'Human'
    },
    {
      id: 3,
      candidate: 'Emily Rodriguez',
      position: 'Frontend Developer',
      company: 'Digital Dynamics',
      scheduledDate: 'Dec 30, 2024',
      scheduledTime: '3:30 PM',
      status: 'Scheduled',
      duration: '30 min',
      payment: '$100',
      type: 'Human'
    },
    {
      id: 4,
      candidate: 'David Park',
      position: 'UI/UX Designer',
      company: 'Creative Studios',
      scheduledDate: 'Jan 2, 2025',
      scheduledTime: '11:00 AM',
      status: 'Scheduled',
      duration: '45 min',
      payment: '$150',
      type: 'Human'
    },
    {
      id: 5,
      candidate: 'Lisa Anderson',
      position: 'Product Manager',
      company: 'StartupHub Inc',
      scheduledDate: 'Jan 3, 2025',
      scheduledTime: '1:00 PM',
      status: 'Scheduled',
      duration: '60 min',
      payment: '$200',
      type: 'Human'
    },
    {
      id: 6,
      candidate: 'James Wilson',
      position: 'DevOps Engineer',
      company: 'CloudTech Systems',
      scheduledDate: 'Jan 4, 2025',
      scheduledTime: '9:00 AM',
      status: 'Scheduled',
      duration: '45 min',
      payment: '$150',
      type: 'Human'
    },
    {
      id: 7,
      candidate: 'Maria Garcia',
      position: 'Data Scientist',
      company: 'Analytics Pro',
      scheduledDate: 'Jan 5, 2025',
      scheduledTime: '2:30 PM',
      status: 'Scheduled',
      duration: '60 min',
      payment: '$200',
      type: 'Human'
    },
    {
      id: 8,
      candidate: 'Robert Taylor',
      position: 'Backend Developer',
      company: 'ServerTech Inc',
      scheduledDate: 'Jan 6, 2025',
      scheduledTime: '4:00 PM',
      status: 'Scheduled',
      duration: '45 min',
      payment: '$150',
      type: 'Human'
    }
  ];

  const paymentSummary = {
    thisMonth: '$2,450',
    pending: '$650',
    completed: '$1,800',
    totalInterviews: 18
  };

  return (
    <div className="space-y-8">
      {/* Payment Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl p-6 text-white shadow-lg">
          <p className="text-sm opacity-90 mb-2">This Month</p>
          <p className="text-3xl font-bold">{paymentSummary.thisMonth}</p>
        </div>
        <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
          <p className="text-sm text-slate-600 mb-2">Pending</p>
          <p className="text-3xl font-bold text-yellow-600">{paymentSummary.pending}</p>
        </div>
        <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
          <p className="text-sm text-slate-600 mb-2">Completed</p>
          <p className="text-3xl font-bold text-green-600">{paymentSummary.completed}</p>
        </div>
        <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
          <p className="text-sm text-slate-600 mb-2">Total Reviews</p>
          <p className="text-3xl font-bold text-indigo-600">{paymentSummary.totalInterviews}</p>
        </div>
      </div>

      {/* Assigned Interviews */}
      <div>
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Assigned Interviews</h2>
        <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                    Candidate
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                    Position
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                    Schedule
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                    Duration
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                    Payment
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                    Status
                  </th>
<th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                    Type
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {assignedInterviews.map((interview) => (
                  <tr key={interview.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                      <div>
                        <p className="font-semibold text-slate-800">{interview.candidate}</p>
                        <p className="text-sm text-slate-500">{interview.company}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-sm text-slate-700">{interview.position}</p>
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <p className="text-sm text-slate-700">{interview.scheduledDate}</p>
                        <p className="text-xs text-slate-500">{interview.scheduledTime}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-sm text-slate-700">{interview.duration}</p>
                    </td>
                    <td className="px-6 py-4">
                      <p className="font-semibold text-green-600">{interview.payment}</p>
                    </td>
<td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                        interview.status === 'Pending Review'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {interview.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        👨‍💼 {interview.type}
                      </span>
                    </td>
<td className="px-6 py-4">
                      <div className="flex items-center space-x-2">
                        <button 
                          onClick={() => window.location.href = '/#/recordings'}
                          className="text-purple-600 hover:text-purple-700 font-medium text-sm"
                        >
                          Recording
                        </button>
                        <span className="text-slate-300">|</span>
                        <button className="text-indigo-600 hover:text-indigo-700 font-medium text-sm">
                          {interview.status === 'Pending Review' ? 'Review' : 'View'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
export default function EvaluationCard({ evaluation, onViewEvaluation }) {
  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'under review':
        return 'bg-amber-100 text-amber-800';
      case 'flagged':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  const getRecommendationColor = (recommendation) => {
    switch (recommendation.toLowerCase()) {
      case 'highly recommended':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'recommended':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'not recommended':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 80) return 'text-blue-600';
    if (score >= 70) return 'text-amber-600';
    return 'text-red-600';
  };

  return (
    <div
      onClick={() => onViewEvaluation(evaluation)}
      className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-slate-100 cursor-pointer group hover:scale-105 active:scale-95"
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <img
            src={evaluation.candidateAvatar}
            alt={evaluation.candidateName}
            className="w-14 h-14 rounded-full border-2 border-indigo-200 group-hover:scale-110 transition-transform"
          />
          <div>
            <h3 className="font-bold text-slate-800 group-hover:text-indigo-600 transition-colors">
              {evaluation.candidateName}
            </h3>
            <p className="text-sm text-slate-600">{evaluation.position}</p>
          </div>
        </div>
        <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(evaluation.status)}`}>
          {evaluation.status}
        </span>
      </div>

      {/* Company & Interview Type */}
      <div className="space-y-2 mb-4">
        <div className="flex items-center text-sm text-slate-600">
          <span className="mr-2">🏢</span>
          <span>{evaluation.company}</span>
        </div>
        <div className="flex items-center text-sm text-slate-600">
          <span className="mr-2">{evaluation.interviewType === 'AI' ? '🤖' : '👨‍💼'}</span>
          <span>{evaluation.interviewType} Interview</span>
        </div>
        <div className="flex items-center text-sm text-slate-600">
          <span className="mr-2">⏱️</span>
          <span>{evaluation.duration}</span>
        </div>
      </div>

      {/* Scores */}
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-lg p-3 border border-indigo-100">
          <p className="text-xs text-slate-600 mb-1">Integrity Score</p>
          <p className={`text-2xl font-bold ${getScoreColor(evaluation.integrityScore)}`}>
            {evaluation.integrityScore}
          </p>
        </div>
        <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-lg p-3 border border-blue-100">
          <p className="text-xs text-slate-600 mb-1">Overall Score</p>
          <p className={`text-2xl font-bold ${getScoreColor(evaluation.overallScore)}`}>
            {evaluation.overallScore}
          </p>
        </div>
      </div>

      {/* Recommendation */}
      <div className={`px-3 py-2 rounded-lg text-sm font-medium text-center border ${getRecommendationColor(evaluation.recommendation)}`}>
        {evaluation.recommendation}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between pt-4 mt-4 border-t border-slate-100">
        <span className="text-xs text-slate-500">{evaluation.evaluatedAt}</span>
        <span className="text-indigo-600 text-sm font-medium group-hover:translate-x-1 transition-transform">
          View Details →
        </span>
      </div>
    </div>
  );
}
import { useState } from 'react';
import EvaluationCard from './EvaluationCard';
import EvaluationFilters from './EvaluationFilters';

export default function EvaluationDashboard({ onViewEvaluation }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortBy, setSortBy] = useState('recent');

  const allEvaluations = [
    {
      id: 1,
      candidateName: 'Sarah Mitchell',
      candidateAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      position: 'Senior React Developer',
      company: 'TechCorp Solutions',
      interviewDate: '2024-12-28',
      interviewType: 'AI',
      status: 'Completed',
      integrityScore: 92,
      overallScore: 88,
      technicalScore: 90,
      communicationScore: 85,
      problemSolvingScore: 87,
      cultureFitScore: 89,
      recommendation: 'Highly Recommended',
      evaluatedAt: '2 hours ago',
      duration: '45 min',
      color: 'from-green-500 to-emerald-500'
    },
    {
      id: 2,
      candidateName: 'Michael Chen',
      candidateAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      position: 'Full Stack Engineer',
      company: 'Innovation Labs',
      interviewDate: '2024-12-27',
      interviewType: 'Human',
      status: 'Completed',
      integrityScore: 78,
      overallScore: 82,
      technicalScore: 85,
      communicationScore: 80,
      problemSolvingScore: 83,
      cultureFitScore: 79,
      recommendation: 'Recommended',
      evaluatedAt: '5 hours ago',
      duration: '60 min',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      id: 3,
      candidateName: 'Emily Rodriguez',
      candidateAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
      position: 'Frontend Developer',
      company: 'Digital Dynamics',
      interviewDate: '2024-12-26',
      interviewType: 'AI',
      status: 'Under Review',
      integrityScore: 85,
      overallScore: 86,
      technicalScore: 88,
      communicationScore: 84,
      problemSolvingScore: 85,
      cultureFitScore: 87,
      recommendation: 'Recommended',
      evaluatedAt: '1 day ago',
      duration: '30 min',
      color: 'from-purple-500 to-pink-500'
    },
    {
      id: 4,
      candidateName: 'David Park',
      candidateAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
      position: 'UI/UX Designer',
      company: 'Creative Studios',
      interviewDate: '2024-12-25',
      interviewType: 'Human',
      status: 'Completed',
      integrityScore: 95,
      overallScore: 91,
      technicalScore: 92,
      communicationScore: 90,
      problemSolvingScore: 89,
      cultureFitScore: 93,
      recommendation: 'Highly Recommended',
      evaluatedAt: '2 days ago',
      duration: '45 min',
      color: 'from-orange-500 to-red-500'
    },
    {
      id: 5,
      candidateName: 'Lisa Anderson',
      candidateAvatar: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop',
      position: 'Product Manager',
      company: 'StartupHub Inc',
      interviewDate: '2024-12-24',
      interviewType: 'AI',
      status: 'Completed',
      integrityScore: 88,
      overallScore: 87,
      technicalScore: 86,
      communicationScore: 89,
      problemSolvingScore: 88,
      cultureFitScore: 85,
      recommendation: 'Recommended',
      evaluatedAt: '3 days ago',
      duration: '60 min',
      color: 'from-indigo-500 to-purple-500'
    },
    {
      id: 6,
      candidateName: 'James Wilson',
      candidateAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop',
      position: 'DevOps Engineer',
      company: 'CloudTech Systems',
      interviewDate: '2024-12-23',
      interviewType: 'Human',
      status: 'Flagged',
      integrityScore: 65,
      overallScore: 72,
      technicalScore: 78,
      communicationScore: 70,
      problemSolvingScore: 75,
      cultureFitScore: 65,
      recommendation: 'Not Recommended',
      evaluatedAt: '4 days ago',
      duration: '45 min',
      color: 'from-red-500 to-pink-500'
    },
    {
      id: 7,
      candidateName: 'Maria Garcia',
      candidateAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop',
      position: 'Data Scientist',
      company: 'Analytics Pro',
      interviewDate: '2024-12-22',
      interviewType: 'AI',
      status: 'Completed',
      integrityScore: 90,
      overallScore: 89,
      technicalScore: 91,
      communicationScore: 87,
      problemSolvingScore: 90,
      cultureFitScore: 88,
      recommendation: 'Highly Recommended',
      evaluatedAt: '5 days ago',
      duration: '60 min',
      color: 'from-teal-500 to-cyan-500'
    },
    {
      id: 8,
      candidateName: 'Robert Taylor',
      candidateAvatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop',
      position: 'Backend Developer',
      company: 'ServerTech Inc',
      interviewDate: '2024-12-21',
      interviewType: 'Human',
      status: 'Under Review',
      integrityScore: 82,
      overallScore: 84,
      technicalScore: 86,
      communicationScore: 82,
      problemSolvingScore: 85,
      cultureFitScore: 83,
      recommendation: 'Recommended',
      evaluatedAt: '6 days ago',
      duration: '45 min',
      color: 'from-amber-500 to-yellow-500'
    }
  ];

  const filteredEvaluations = allEvaluations.filter(evaluation => {
    const matchesSearch = 
      evaluation.candidateName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      evaluation.position.toLowerCase().includes(searchQuery.toLowerCase()) ||
      evaluation.company.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || evaluation.status.toLowerCase() === statusFilter.toLowerCase();
    
    return matchesSearch && matchesStatus;
  });

  const sortedEvaluations = [...filteredEvaluations].sort((a, b) => {
    switch (sortBy) {
      case 'recent':
        return b.id - a.id;
      case 'score':
        return b.overallScore - a.overallScore;
      case 'integrity':
        return b.integrityScore - a.integrityScore;
      case 'name':
        return a.candidateName.localeCompare(b.candidateName);
      default:
        return 0;
    }
  });

  const stats = {
    total: allEvaluations.length,
    completed: allEvaluations.filter(e => e.status === 'Completed').length,
    underReview: allEvaluations.filter(e => e.status === 'Under Review').length,
    flagged: allEvaluations.filter(e => e.status === 'Flagged').length,
    avgIntegrity: Math.round(allEvaluations.reduce((sum, e) => sum + e.integrityScore, 0) / allEvaluations.length),
    avgOverall: Math.round(allEvaluations.reduce((sum, e) => sum + e.overallScore, 0) / allEvaluations.length)
  };

  return (
    <div className="space-y-6">
      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Total Evaluations</p>
              <p className="text-3xl font-bold text-slate-800">{stats.total}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">📊</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Completed</p>
              <p className="text-3xl font-bold text-green-600">{stats.completed}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">✅</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Under Review</p>
              <p className="text-3xl font-bold text-amber-600">{stats.underReview}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-yellow-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">⏳</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Flagged</p>
              <p className="text-3xl font-bold text-red-600">{stats.flagged}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-pink-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">⚠️</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Avg Integrity</p>
              <p className="text-3xl font-bold text-indigo-600">{stats.avgIntegrity}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">🎯</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Avg Score</p>
              <p className="text-3xl font-bold text-purple-600">{stats.avgOverall}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">⭐</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <EvaluationFilters
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        statusFilter={statusFilter}
        onStatusChange={setStatusFilter}
        sortBy={sortBy}
        onSortChange={setSortBy}
      />

      {/* Evaluations Grid */}
      {sortedEvaluations.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sortedEvaluations.map(evaluation => (
            <EvaluationCard 
              key={evaluation.id} 
              evaluation={evaluation} 
              onViewEvaluation={onViewEvaluation} 
            />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl p-12 text-center shadow-lg border border-slate-100">
          <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-4xl">🔍</span>
          </div>
          <h3 className="text-xl font-semibold text-slate-800 mb-2">No evaluations found</h3>
          <p className="text-slate-600">Try adjusting your search or filters</p>
        </div>
      )}
    </div>
  );
}
import { useState } from 'react';

export default function EvaluationDetailView({ evaluation, onBack }) {
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', label: 'Overview', icon: '📊' },
    { id: 'technical', label: 'Technical', icon: '💻' },
    { id: 'behavioral', label: 'Behavioral', icon: '🧠' },
    { id: 'integrity', label: 'Integrity', icon: '🎯' },
    { id: 'feedback', label: 'AI Feedback', icon: '🤖' }
  ];

  const getScoreColor = (score) => {
    if (score >= 90) return 'from-green-500 to-emerald-500';
    if (score >= 80) return 'from-blue-500 to-cyan-500';
    if (score >= 70) return 'from-amber-500 to-yellow-500';
    return 'from-red-500 to-pink-500';
  };

  const getScoreTextColor = (score) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 80) return 'text-blue-600';
    if (score >= 70) return 'text-amber-600';
    return 'text-red-600';
  };

  const technicalMetrics = [
    { label: 'Code Quality', score: 92, details: 'Clean, well-structured code with proper naming conventions' },
    { label: 'Problem Solving', score: 88, details: 'Strong analytical approach to complex problems' },
    { label: 'Best Practices', score: 90, details: 'Demonstrates knowledge of industry standards' },
    { label: 'Testing Knowledge', score: 85, details: 'Good understanding of testing methodologies' }
  ];

  const behavioralMetrics = [
    { label: 'Communication', score: 85, details: 'Clear and articulate in explaining concepts' },
    { label: 'Teamwork', score: 87, details: 'Shows collaborative mindset and team orientation' },
    { label: 'Adaptability', score: 89, details: 'Flexible and open to new approaches' },
    { label: 'Leadership', score: 83, details: 'Demonstrates potential for leadership roles' }
  ];

  const integrityMetrics = [
    { label: 'Face Detection', score: 98, status: 'Excellent', details: 'Consistent face presence throughout' },
    { label: 'Gaze Tracking', score: 95, status: 'Excellent', details: 'Maintained strong eye contact' },
    { label: 'Voice Analysis', score: 92, status: 'Good', details: 'Natural speech patterns detected' },
    { label: 'Plagiarism Check', score: 88, status: 'Good', details: 'Original responses verified' }
  ];

  const aiFeedback = {
    strengths: [
      'Exceptional technical knowledge in React and modern JavaScript',
      'Strong problem-solving abilities with systematic approach',
      'Excellent communication skills and ability to explain complex concepts',
      'Demonstrated passion for continuous learning and improvement'
    ],
    improvements: [
      'Could benefit from more experience with testing frameworks',
      'Consider deepening knowledge in system design patterns',
      'Practice explaining technical concepts to non-technical audiences'
    ],
    summary: 'Sarah is an outstanding candidate who demonstrates both technical excellence and strong soft skills. Her systematic approach to problem-solving, combined with clear communication abilities, makes her an ideal fit for senior-level positions. The integrity analysis shows consistent professional behavior throughout the interview process.',
    recommendation: 'Highly Recommended for immediate hire',
    nextSteps: [
      'Schedule final round with technical leadership',
      'Prepare offer package within competitive range',
      'Discuss start date and onboarding timeline'
    ]
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100">
        <button
          onClick={onBack}
          className="text-indigo-600 hover:text-indigo-700 font-medium mb-6 flex items-center space-x-2"
        >
          <span>←</span>
          <span>Back to Evaluations</span>
        </button>

        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-6">
            <img
              src={evaluation.candidateAvatar}
              alt={evaluation.candidateName}
              className="w-24 h-24 rounded-full border-4 border-indigo-200"
            />
            <div>
              <h1 className="text-3xl font-bold text-slate-800 mb-2">{evaluation.candidateName}</h1>
              <p className="text-lg text-slate-600 mb-2">{evaluation.position}</p>
              <div className="flex items-center space-x-4 text-sm text-slate-600">
                <span className="flex items-center">
                  <span className="mr-1">🏢</span>
                  {evaluation.company}
                </span>
                <span className="flex items-center">
                  <span className="mr-1">{evaluation.interviewType === 'AI' ? '🤖' : '👨‍💼'}</span>
                  {evaluation.interviewType} Interview
                </span>
                <span className="flex items-center">
                  <span className="mr-1">📅</span>
                  {evaluation.interviewDate}
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-col space-y-3">
            <button className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium">
              Download Report
            </button>
            <button className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium">
              Share Evaluation
            </button>
          </div>
        </div>

        {/* Score Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
          <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl p-4 border border-indigo-100">
            <p className="text-sm text-slate-600 mb-2">Integrity Score</p>
            <p className={`text-4xl font-bold ${getScoreTextColor(evaluation.integrityScore)}`}>
              {evaluation.integrityScore}
            </p>
          </div>
          <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl p-4 border border-blue-100">
            <p className="text-sm text-slate-600 mb-2">Overall Score</p>
            <p className={`text-4xl font-bold ${getScoreTextColor(evaluation.overallScore)}`}>
              {evaluation.overallScore}
            </p>
          </div>
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-4 border border-green-100">
            <p className="text-sm text-slate-600 mb-2">Technical</p>
            <p className={`text-4xl font-bold ${getScoreTextColor(evaluation.technicalScore)}`}>
              {evaluation.technicalScore}
            </p>
          </div>
          <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-4 border border-purple-100">
            <p className="text-sm text-slate-600 mb-2">Communication</p>
            <p className={`text-4xl font-bold ${getScoreTextColor(evaluation.communicationScore)}`}>
              {evaluation.communicationScore}
            </p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
        <div className="flex border-b border-slate-200 overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 px-6 py-4 font-medium transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <span className="mr-2">{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </div>

        <div className="p-8">
          {/* Overview Tab */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-slate-50 rounded-xl p-6">
                  <h3 className="text-lg font-bold text-slate-800 mb-4">Performance Breakdown</h3>
                  <div className="space-y-4">
                    {[
                      { label: 'Technical Skills', score: evaluation.technicalScore },
                      { label: 'Communication', score: evaluation.communicationScore },
                      { label: 'Problem Solving', score: evaluation.problemSolvingScore },
                      { label: 'Culture Fit', score: evaluation.cultureFitScore }
                    ].map((metric, index) => (
                      <div key={index}>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium text-slate-700">{metric.label}</span>
                          <span className={`text-sm font-bold ${getScoreTextColor(metric.score)}`}>
                            {metric.score}
                          </span>
                        </div>
                        <div className="w-full bg-slate-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full bg-gradient-to-r ${getScoreColor(metric.score)} transition-all duration-500`}
                            style={{ width: `${metric.score}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl p-6 border border-indigo-100">
                  <h3 className="text-lg font-bold text-slate-800 mb-4">Recommendation</h3>
                  <div className="space-y-4">
                    <div className={`px-4 py-3 rounded-lg text-center font-bold text-lg ${
                      evaluation.recommendation === 'Highly Recommended'
                        ? 'bg-green-100 text-green-800 border-2 border-green-200'
                        : evaluation.recommendation === 'Recommended'
                        ? 'bg-blue-100 text-blue-800 border-2 border-blue-200'
                        : 'bg-red-100 text-red-800 border-2 border-red-200'
                    }`}>
                      {evaluation.recommendation}
                    </div>
                    <p className="text-sm text-slate-700">
                      Based on comprehensive AI analysis of technical skills, behavioral traits, and integrity metrics.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Technical Tab */}
          {activeTab === 'technical' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-slate-800 mb-4">Technical Assessment</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {technicalMetrics.map((metric, index) => (
                  <div key={index} className="bg-slate-50 rounded-xl p-6">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-semibold text-slate-800">{metric.label}</h4>
                      <span className={`text-2xl font-bold ${getScoreTextColor(metric.score)}`}>
                        {metric.score}
                      </span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2 mb-3">
                      <div
                        className={`h-2 rounded-full bg-gradient-to-r ${getScoreColor(metric.score)}`}
                        style={{ width: `${metric.score}%` }}
                      ></div>
                    </div>
                    <p className="text-sm text-slate-600">{metric.details}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Behavioral Tab */}
          {activeTab === 'behavioral' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-slate-800 mb-4">Behavioral Analysis</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {behavioralMetrics.map((metric, index) => (
                  <div key={index} className="bg-slate-50 rounded-xl p-6">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-semibold text-slate-800">{metric.label}</h4>
                      <span className={`text-2xl font-bold ${getScoreTextColor(metric.score)}`}>
                        {metric.score}
                      </span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2 mb-3">
                      <div
                        className={`h-2 rounded-full bg-gradient-to-r ${getScoreColor(metric.score)}`}
                        style={{ width: `${metric.score}%` }}
                      ></div>
                    </div>
                    <p className="text-sm text-slate-600">{metric.details}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Integrity Tab */}
          {activeTab === 'integrity' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-slate-800 mb-4">Integrity Analysis</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {integrityMetrics.map((metric, index) => (
                  <div key={index} className="bg-slate-50 rounded-xl p-6">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-semibold text-slate-800">{metric.label}</h4>
                      <div className="text-right">
                        <span className={`text-2xl font-bold ${getScoreTextColor(metric.score)}`}>
                          {metric.score}
                        </span>
                        <p className={`text-xs font-medium mt-1 ${
                          metric.status === 'Excellent' ? 'text-green-600' : 'text-blue-600'
                        }`}>
                          {metric.status}
                        </p>
                      </div>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2 mb-3">
                      <div
                        className={`h-2 rounded-full bg-gradient-to-r ${getScoreColor(metric.score)}`}
                        style={{ width: `${metric.score}%` }}
                      ></div>
                    </div>
                    <p className="text-sm text-slate-600">{metric.details}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* AI Feedback Tab */}
          {activeTab === 'feedback' && (
            <div className="space-y-6">
              <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6 border border-purple-100">
                <h3 className="text-xl font-bold text-slate-800 mb-4 flex items-center">
                  <span className="mr-2">🤖</span>
                  AI-Generated Summary
                </h3>
                <p className="text-slate-700 leading-relaxed">{aiFeedback.summary}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-green-50 rounded-xl p-6 border border-green-100">
                  <h4 className="font-bold text-green-900 mb-4 flex items-center">
                    <span className="mr-2">✅</span>
                    Key Strengths
                  </h4>
                  <ul className="space-y-2">
                    {aiFeedback.strengths.map((strength, index) => (
                      <li key={index} className="text-sm text-green-800 flex items-start">
                        <span className="mr-2 mt-1">•</span>
                        <span>{strength}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-amber-50 rounded-xl p-6 border border-amber-100">
                  <h4 className="font-bold text-amber-900 mb-4 flex items-center">
                    <span className="mr-2">💡</span>
                    Areas for Improvement
                  </h4>
                  <ul className="space-y-2">
                    {aiFeedback.improvements.map((improvement, index) => (
                      <li key={index} className="text-sm text-amber-800 flex items-start">
                        <span className="mr-2 mt-1">•</span>
                        <span>{improvement}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="bg-blue-50 rounded-xl p-6 border border-blue-100">
                <h4 className="font-bold text-blue-900 mb-4 flex items-center">
                  <span className="mr-2">🎯</span>
                  Recommended Next Steps
                </h4>
                <ul className="space-y-2">
                  {aiFeedback.nextSteps.map((step, index) => (
                    <li key={index} className="text-sm text-blue-800 flex items-start">
                      <span className="mr-2 mt-1">{index + 1}.</span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl p-6 text-white">
                <h4 className="font-bold mb-2 text-lg">Final Recommendation</h4>
                <p className="text-lg">{aiFeedback.recommendation}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
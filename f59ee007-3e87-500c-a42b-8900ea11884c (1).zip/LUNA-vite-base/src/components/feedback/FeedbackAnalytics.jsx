export default function FeedbackAnalytics() {
  const platformMetrics = {
    totalFeedback: 1247,
    avgRating: 4.3,
    satisfactionRate: 87,
    responseRate: 94,
    improvementTrend: '+12%'
  };

  const categoryRatings = [
    { category: 'Platform Usability', rating: 4.5, trend: '+8%', color: 'from-blue-500 to-cyan-500' },
    { category: 'Interview Quality', rating: 4.4, trend: '+5%', color: 'from-green-500 to-emerald-500' },
    { category: 'Technical Setup', rating: 4.2, trend: '+15%', color: 'from-purple-500 to-pink-500' },
    { category: 'Communication', rating: 4.6, trend: '+3%', color: 'from-indigo-500 to-purple-500' },
    { category: 'Overall Experience', rating: 4.3, trend: '+10%', color: 'from-amber-500 to-orange-500' }
  ];

  const commonFeedback = [
    {
      theme: 'AI Interview Quality',
      positive: 342,
      negative: 45,
      sentiment: 'positive',
      topComment: 'AI questions are relevant and challenging'
    },
    {
      theme: 'Platform Interface',
      positive: 298,
      negative: 67,
      sentiment: 'positive',
      topComment: 'Easy to navigate and user-friendly'
    },
    {
      theme: 'Video Quality',
      positive: 234,
      negative: 89,
      sentiment: 'positive',
      topComment: 'Clear video and audio throughout'
    },
    {
      theme: 'Response Time',
      positive: 187,
      negative: 112,
      sentiment: 'mixed',
      topComment: 'Would appreciate faster feedback delivery'
    },
    {
      theme: 'Technical Issues',
      positive: 156,
      negative: 134,
      sentiment: 'mixed',
      topComment: 'Occasional connectivity problems'
    }
  ];

  const recentImprovements = [
    {
      id: 1,
      title: 'Enhanced Video Quality',
      description: 'Upgraded video streaming infrastructure for better quality',
      implementedDate: '2024-12-15',
      impact: '+15% satisfaction',
      icon: '🎥'
    },
    {
      id: 2,
      title: 'Faster Feedback Delivery',
      description: 'Reduced feedback turnaround time from 48h to 24h',
      implementedDate: '2024-12-10',
      impact: '+20% satisfaction',
      icon: '⚡'
    },
    {
      id: 3,
      title: 'Improved AI Questions',
      description: 'Updated question bank with more diverse scenarios',
      implementedDate: '2024-12-05',
      impact: '+12% satisfaction',
      icon: '🤖'
    },
    {
      id: 4,
      title: 'Better Mobile Experience',
      description: 'Optimized platform for mobile devices',
      implementedDate: '2024-11-28',
      impact: '+18% satisfaction',
      icon: '📱'
    }
  ];

  const getSentimentColor = (sentiment) => {
    switch (sentiment) {
      case 'positive':
        return 'text-green-600';
      case 'negative':
        return 'text-red-600';
      case 'mixed':
        return 'text-amber-600';
      default:
        return 'text-slate-600';
    }
  };

  const getSentimentIcon = (sentiment) => {
    switch (sentiment) {
      case 'positive':
        return '😊';
      case 'negative':
        return '😞';
      case 'mixed':
        return '😐';
      default:
        return '❓';
    }
  };

  return (
    <div className="space-y-6">
      {/* Platform Overview */}
      <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100">
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Platform Performance Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-100">
            <p className="text-sm text-slate-600 mb-2">Total Feedback</p>
            <p className="text-3xl font-bold text-blue-600">{platformMetrics.totalFeedback}</p>
          </div>
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-6 border border-green-100">
            <p className="text-sm text-slate-600 mb-2">Avg Rating</p>
            <p className="text-3xl font-bold text-green-600">{platformMetrics.avgRating}</p>
          </div>
          <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6 border border-purple-100">
            <p className="text-sm text-slate-600 mb-2">Satisfaction</p>
            <p className="text-3xl font-bold text-purple-600">{platformMetrics.satisfactionRate}%</p>
          </div>
          <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-xl p-6 border border-amber-100">
            <p className="text-sm text-slate-600 mb-2">Response Rate</p>
            <p className="text-3xl font-bold text-amber-600">{platformMetrics.responseRate}%</p>
          </div>
          <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl p-6 border border-indigo-100">
            <p className="text-sm text-slate-600 mb-2">Improvement</p>
            <p className="text-3xl font-bold text-indigo-600">{platformMetrics.improvementTrend}</p>
          </div>
        </div>
      </div>

      {/* Category Ratings */}
      <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100">
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Category Performance</h2>
        <div className="space-y-6">
          {categoryRatings.map((category, index) => (
            <div key={index}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <span className="font-semibold text-slate-800">{category.category}</span>
                  <span className="text-sm text-green-600 font-medium">{category.trend}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-yellow-500">⭐</span>
                  <span className="font-bold text-slate-800">{category.rating}</span>
                </div>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-3">
                <div
                  className={`h-3 rounded-full bg-gradient-to-r ${category.color} transition-all duration-500`}
                  style={{ width: `${(category.rating / 5) * 100}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Common Feedback Themes */}
      <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100">
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Common Feedback Themes</h2>
        <div className="space-y-4">
          {commonFeedback.map((item, index) => (
            <div key={index} className="bg-slate-50 rounded-xl p-6 border border-slate-200">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="font-bold text-slate-800">{item.theme}</h3>
                    <span className={`text-2xl ${getSentimentColor(item.sentiment)}`}>
                      {getSentimentIcon(item.sentiment)}
                    </span>
                  </div>
                  <p className="text-sm text-slate-600 italic">"{item.topComment}"</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-green-50 rounded-lg p-3 border border-green-100">
                  <p className="text-xs text-green-700 mb-1">Positive Mentions</p>
                  <p className="text-2xl font-bold text-green-600">{item.positive}</p>
                </div>
                <div className="bg-red-50 rounded-lg p-3 border border-red-100">
                  <p className="text-xs text-red-700 mb-1">Negative Mentions</p>
                  <p className="text-2xl font-bold text-red-600">{item.negative}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Improvements */}
      <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100">
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Recent Platform Improvements</h2>
        <div className="space-y-4">
          {recentImprovements.map((improvement) => (
            <div key={improvement.id} className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-6 border border-indigo-100">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center flex-shrink-0">
                  <span className="text-2xl">{improvement.icon}</span>
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-bold text-slate-800">{improvement.title}</h3>
                    <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">
                      {improvement.impact}
                    </span>
                  </div>
                  <p className="text-sm text-slate-700 mb-2">{improvement.description}</p>
                  <p className="text-xs text-slate-500">Implemented: {improvement.implementedDate}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Call to Action */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl p-8 text-white shadow-lg">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-3">Your Voice Matters!</h2>
          <p className="text-lg mb-6 opacity-90">
            Every piece of feedback helps us create a better experience for all candidates
          </p>
          <div className="flex items-center justify-center space-x-4">
            <div className="bg-white/20 rounded-lg px-6 py-3">
              <p className="text-sm opacity-90">Average Response Time</p>
              <p className="text-2xl font-bold">24 hours</p>
            </div>
            <div className="bg-white/20 rounded-lg px-6 py-3">
              <p className="text-sm opacity-90">Feedback Implemented</p>
              <p className="text-2xl font-bold">156+</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
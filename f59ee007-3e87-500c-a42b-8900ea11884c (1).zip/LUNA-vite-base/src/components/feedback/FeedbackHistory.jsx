import { useState } from 'react';

export default function FeedbackHistory() {
  const [filterStatus, setFilterStatus] = useState('all');

  const feedbackHistory = [
    {
      id: 1,
      company: 'TechCorp Solutions',
      position: 'Senior React Developer',
      submittedDate: '2024-12-28',
      interviewDate: '2024-12-28',
      type: 'AI',
      status: 'Reviewed',
      overallRating: 5,
      platformRating: 5,
      interviewerRating: 4,
      technicalRating: 5,
      communicationRating: 4,
      positive: 'The AI interview was incredibly smooth and professional. Questions were relevant and challenging.',
      improvements: 'Would love to see more real-time feedback during the interview.',
      wouldRecommend: 'yes',
      adminResponse: 'Thank you for your valuable feedback! We\'re working on implementing real-time feedback features.',
      responseDate: '2024-12-29'
    },
    {
      id: 2,
      company: 'Innovation Labs',
      position: 'Full Stack Engineer',
      submittedDate: '2024-12-27',
      interviewDate: '2024-12-27',
      type: 'Human',
      interviewer: 'Dr. Sarah Johnson',
      status: 'Pending Review',
      overallRating: 4,
      platformRating: 4,
      interviewerRating: 5,
      technicalRating: 4,
      communicationRating: 5,
      positive: 'Dr. Johnson was extremely professional and made me feel comfortable throughout the interview.',
      improvements: 'The video quality could be better, experienced some lag.',
      wouldRecommend: 'yes'
    },
    {
      id: 3,
      company: 'Digital Dynamics',
      position: 'Frontend Developer',
      submittedDate: '2024-12-26',
      interviewDate: '2024-12-26',
      type: 'AI',
      status: 'Reviewed',
      overallRating: 4,
      platformRating: 5,
      interviewerRating: 4,
      technicalRating: 4,
      communicationRating: 4,
      positive: 'Great platform with intuitive interface. AI questions were well-structured.',
      improvements: 'More time for complex coding questions would be helpful.',
      wouldRecommend: 'yes',
      adminResponse: 'We appreciate your feedback! We\'re adjusting time allocations for technical questions.',
      responseDate: '2024-12-27'
    },
    {
      id: 4,
      company: 'StartupHub Inc',
      position: 'React Developer',
      submittedDate: '2024-12-20',
      interviewDate: '2024-12-20',
      type: 'AI',
      status: 'Reviewed',
      overallRating: 3,
      platformRating: 3,
      interviewerRating: 3,
      technicalRating: 4,
      communicationRating: 3,
      positive: 'Technical questions were appropriate for the role.',
      improvements: 'Some questions felt repetitive. Platform could use better navigation.',
      wouldRecommend: 'maybe',
      adminResponse: 'Thank you for pointing this out. We\'re working on improving question variety and navigation.',
      responseDate: '2024-12-21'
    },
    {
      id: 5,
      company: 'CloudTech Systems',
      position: 'Software Engineer',
      submittedDate: '2024-12-18',
      interviewDate: '2024-12-18',
      type: 'Human',
      interviewer: 'Mark Wilson',
      status: 'Reviewed',
      overallRating: 5,
      platformRating: 5,
      interviewerRating: 5,
      technicalRating: 5,
      communicationRating: 5,
      positive: 'Exceptional experience! Mark was knowledgeable and the platform worked flawlessly.',
      improvements: 'Everything was perfect!',
      wouldRecommend: 'yes',
      adminResponse: 'We\'re thrilled to hear about your positive experience! Thank you for the feedback.',
      responseDate: '2024-12-19'
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'Reviewed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Pending Review':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getRecommendationIcon = (recommendation) => {
    switch (recommendation) {
      case 'yes':
        return '👍';
      case 'maybe':
        return '🤔';
      case 'no':
        return '👎';
      default:
        return '❓';
    }
  };

  const filteredFeedback = filterStatus === 'all'
    ? feedbackHistory
    : feedbackHistory.filter(f => f.status === filterStatus);

  const stats = {
    total: feedbackHistory.length,
    reviewed: feedbackHistory.filter(f => f.status === 'Reviewed').length,
    pending: feedbackHistory.filter(f => f.status === 'Pending Review').length,
    avgRating: (feedbackHistory.reduce((sum, f) => sum + f.overallRating, 0) / feedbackHistory.length).toFixed(1)
  };

  return (
    <div className="space-y-6">
      {/* Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Total Feedback</p>
              <p className="text-3xl font-bold text-slate-800">{stats.total}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">📝</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Reviewed</p>
              <p className="text-3xl font-bold text-green-600">{stats.reviewed}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">✅</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Pending</p>
              <p className="text-3xl font-bold text-amber-600">{stats.pending}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-yellow-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">⏳</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Avg Rating</p>
              <p className="text-3xl font-bold text-purple-600">{stats.avgRating}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">⭐</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filter */}
      <div className="bg-white rounded-xl p-4 shadow-lg border border-slate-100">
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
        >
          <option value="all">All Feedback</option>
          <option value="Reviewed">Reviewed</option>
          <option value="Pending Review">Pending Review</option>
        </select>
      </div>

      {/* Feedback List */}
      <div className="space-y-4">
        {filteredFeedback.map((feedback) => (
          <div
            key={feedback.id}
            className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100 hover:shadow-xl transition-all duration-300"
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h3 className="text-lg font-bold text-slate-800 mb-1">{feedback.position}</h3>
                <p className="text-indigo-600 font-semibold mb-2">{feedback.company}</p>
                <div className="flex flex-wrap gap-3 text-sm text-slate-600">
                  <span className="flex items-center">
                    <span className="mr-1">{feedback.type === 'AI' ? '🤖' : '👨‍💼'}</span>
                    {feedback.type} Interview
                  </span>
                  <span className="flex items-center">
                    <span className="mr-1">📅</span>
                    {feedback.interviewDate}
                  </span>
                  <span className="flex items-center">
                    <span className="mr-1">✍️</span>
                    Submitted: {feedback.submittedDate}
                  </span>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-lg text-sm font-medium border ${getStatusColor(feedback.status)}`}>
                {feedback.status}
              </span>
            </div>

            {/* Ratings */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
              {[
                { label: 'Overall', value: feedback.overallRating },
                { label: 'Platform', value: feedback.platformRating },
                { label: 'Interviewer', value: feedback.interviewerRating },
                { label: 'Technical', value: feedback.technicalRating },
                { label: 'Communication', value: feedback.communicationRating }
              ].map((rating, index) => (
                <div key={index} className="bg-slate-50 rounded-lg p-3 text-center">
                  <p className="text-xs text-slate-600 mb-1">{rating.label}</p>
                  <div className="flex items-center justify-center space-x-1">
                    <span className="text-yellow-500">⭐</span>
                    <span className="font-bold text-slate-800">{rating.value}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Feedback Content */}
            <div className="space-y-3 mb-4">
              <div className="bg-green-50 rounded-lg p-4 border border-green-100">
                <p className="text-sm font-semibold text-green-900 mb-2">✨ What went well:</p>
                <p className="text-sm text-green-800">{feedback.positive}</p>
              </div>
              <div className="bg-amber-50 rounded-lg p-4 border border-amber-100">
                <p className="text-sm font-semibold text-amber-900 mb-2">💡 Improvements:</p>
                <p className="text-sm text-amber-800">{feedback.improvements}</p>
              </div>
            </div>

            {/* Recommendation */}
            <div className="flex items-center space-x-2 mb-4">
              <span className="text-2xl">{getRecommendationIcon(feedback.wouldRecommend)}</span>
              <span className="text-sm font-medium text-slate-700">
                Would recommend: {feedback.wouldRecommend === 'yes' ? 'Yes' : feedback.wouldRecommend === 'maybe' ? 'Maybe' : 'No'}
              </span>
            </div>

            {/* Admin Response */}
            {feedback.adminResponse && (
              <div className="bg-indigo-50 rounded-lg p-4 border border-indigo-100">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-white text-sm">👨‍💼</span>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-indigo-900 mb-1">Admin Response</p>
                    <p className="text-sm text-indigo-800 mb-2">{feedback.adminResponse}</p>
                    <p className="text-xs text-indigo-600">Responded on: {feedback.responseDate}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
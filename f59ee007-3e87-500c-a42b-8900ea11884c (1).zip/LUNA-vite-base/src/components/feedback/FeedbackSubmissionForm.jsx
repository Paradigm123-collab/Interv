import { useState } from 'react';

export default function FeedbackSubmissionForm() {
  const [selectedInterview, setSelectedInterview] = useState('');
  const [ratings, setRatings] = useState({
    overall: 0,
    platform: 0,
    interviewer: 0,
    technical: 0,
    communication: 0
  });
  const [feedback, setFeedback] = useState({
    positive: '',
    improvements: '',
    suggestions: '',
    wouldRecommend: null
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const recentInterviews = [
    {
      id: 1,
      company: 'TechCorp Solutions',
      position: 'Senior React Developer',
      date: '2024-12-28',
      type: 'AI'
    },
    {
      id: 2,
      company: 'Innovation Labs',
      position: 'Full Stack Engineer',
      date: '2024-12-27',
      type: 'Human',
      interviewer: 'Dr. Sarah Johnson'
    },
    {
      id: 3,
      company: 'Digital Dynamics',
      position: 'Frontend Developer',
      date: '2024-12-26',
      type: 'AI'
    }
  ];

  const ratingCategories = [
    { key: 'overall', label: 'Overall Experience', icon: '⭐' },
    { key: 'platform', label: 'Platform Usability', icon: '💻' },
    { key: 'interviewer', label: 'Interviewer Quality', icon: '👨‍💼' },
    { key: 'technical', label: 'Technical Setup', icon: '🔧' },
    { key: 'communication', label: 'Communication Clarity', icon: '💬' }
  ];

  const handleRatingChange = (category, value) => {
    setRatings(prev => ({ ...prev, [category]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);
      
      const message = document.createElement('div');
      message.className = 'fixed top-20 right-4 bg-green-500 text-white px-6 py-4 rounded-lg shadow-lg z-50 animate-fade-in';
      message.innerHTML = `
        <div class="flex items-center space-x-3">
          <span class="text-2xl">✅</span>
          <div>
            <p class="font-bold">Feedback Submitted Successfully!</p>
            <p class="text-sm">Thank you for helping us improve</p>
          </div>
        </div>
      `;
      document.body.appendChild(message);
      
      setTimeout(() => message.remove(), 3000);

      setSelectedInterview('');
      setRatings({
        overall: 0,
        platform: 0,
        interviewer: 0,
        technical: 0,
        communication: 0
      });
      setFeedback({
        positive: '',
        improvements: '',
        suggestions: '',
        wouldRecommend: null
      });
    }, 1500);
  };

  const StarRating = ({ value, onChange, category }) => {
    return (
      <div className="flex items-center space-x-2">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onChange(category, star)}
            className={`text-3xl transition-all duration-200 hover:scale-110 ${
              star <= value ? 'text-yellow-500' : 'text-slate-300'
            }`}
          >
            ⭐
          </button>
        ))}
        <span className="text-sm font-medium text-slate-600 ml-2">
          {value > 0 ? `${value}/5` : 'Not rated'}
        </span>
      </div>
    );
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-slate-100 p-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Share Your Interview Experience</h2>
        <p className="text-slate-600">Your feedback helps us create a better experience for everyone</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Interview Selection */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-3">
            Select Interview to Review *
          </label>
          <div className="space-y-3">
            {recentInterviews.map((interview) => (
              <button
                key={interview.id}
                type="button"
                onClick={() => setSelectedInterview(interview.id)}
                className={`w-full text-left p-4 rounded-xl border-2 transition-all duration-200 ${
                  selectedInterview === interview.id
                    ? 'border-indigo-500 bg-indigo-50'
                    : 'border-slate-200 hover:border-indigo-300 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-slate-800">{interview.position}</h3>
                    <p className="text-sm text-slate-600">{interview.company}</p>
                    <div className="flex items-center space-x-3 mt-2 text-xs text-slate-500">
                      <span>📅 {interview.date}</span>
                      <span>{interview.type === 'AI' ? '🤖 AI Interview' : `👨‍💼 ${interview.interviewer}`}</span>
                    </div>
                  </div>
                  {selectedInterview === interview.id && (
                    <span className="text-indigo-600 text-2xl">✓</span>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>

        {selectedInterview && (
          <>
            {/* Rating Categories */}
            <div>
              <h3 className="text-lg font-bold text-slate-800 mb-4">Rate Your Experience</h3>
              <div className="space-y-6">
                {ratingCategories.map((category) => (
                  <div key={category.key} className="bg-slate-50 rounded-xl p-6">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <span className="text-2xl">{category.icon}</span>
                        <span className="font-semibold text-slate-800">{category.label}</span>
                      </div>
                    </div>
                    <StarRating
                      value={ratings[category.key]}
                      onChange={handleRatingChange}
                      category={category.key}
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Detailed Feedback */}
            <div>
              <h3 className="text-lg font-bold text-slate-800 mb-4">Share Your Thoughts</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">
                    What did you like most? ✨
                  </label>
                  <textarea
                    value={feedback.positive}
                    onChange={(e) => setFeedback(prev => ({ ...prev, positive: e.target.value }))}
                    rows={4}
                    className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
                    placeholder="Tell us what went well during your interview..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">
                    What could be improved? 💡
                  </label>
                  <textarea
                    value={feedback.improvements}
                    onChange={(e) => setFeedback(prev => ({ ...prev, improvements: e.target.value }))}
                    rows={4}
                    className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
                    placeholder="Share any challenges or areas for improvement..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">
                    Additional Suggestions 🚀
                  </label>
                  <textarea
                    value={feedback.suggestions}
                    onChange={(e) => setFeedback(prev => ({ ...prev, suggestions: e.target.value }))}
                    rows={4}
                    className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
                    placeholder="Any other feedback or suggestions for us..."
                  />
                </div>
              </div>
            </div>

            {/* Recommendation */}
            <div>
              <h3 className="text-lg font-bold text-slate-800 mb-4">Would you recommend our platform?</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { value: 'yes', label: 'Yes, definitely!', icon: '👍', color: 'green' },
                  { value: 'maybe', label: 'Maybe', icon: '🤔', color: 'amber' },
                  { value: 'no', label: 'Not really', icon: '👎', color: 'red' }
                ].map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => setFeedback(prev => ({ ...prev, wouldRecommend: option.value }))}
                    className={`p-6 rounded-xl border-2 transition-all duration-200 ${
                      feedback.wouldRecommend === option.value
                        ? `border-${option.color}-500 bg-${option.color}-50`
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <span className="text-4xl mb-2 block">{option.icon}</span>
                    <span className="font-semibold text-slate-800">{option.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Submit Button */}
            <div className="flex items-center justify-end space-x-4 pt-6 border-t border-slate-200">
              <button
                type="button"
                onClick={() => {
                  setSelectedInterview('');
                  setRatings({
                    overall: 0,
                    platform: 0,
                    interviewer: 0,
                    technical: 0,
                    communication: 0
                  });
                  setFeedback({
                    positive: '',
                    improvements: '',
                    suggestions: '',
                    wouldRecommend: null
                  });
                }}
                className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-slate-300 hover:bg-slate-50 transition-all duration-200 font-medium"
              >
                Clear Form
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-8 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium flex items-center space-x-2 hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Submitting...</span>
                  </>
                ) : (
                  <>
                    <span>✓</span>
                    <span>Submit Feedback</span>
                  </>
                )}
              </button>
            </div>
          </>
        )}
      </form>
    </div>
  );
}
import { useNavigate } from 'react-router-dom';
import Button from '../common/Button';

export default function CTASection() {
  const navigate = useNavigate();

  const handleStartTrial = () => {
    navigate('/dashboard');
  };

  const handleTalkToSales = () => {
    alert('Sales contact form will be available soon! This will connect to your CRM.');
  };

  return (
    <section className="py-20 bg-gradient-to-br from-slate-900 via-indigo-900 to-purple-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
            Ready to Transform Your Hiring?
          </h2>
          <p className="text-xl text-white/90 max-w-3xl mx-auto mb-12 leading-relaxed">
            Join 10,000+ companies using our platform to hire better, faster, and smarter. 
            Start your free trial today - no credit card required.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-12">
            <Button 
              size="lg" 
              className="bg-white text-indigo-600 hover:bg-slate-100"
              onClick={handleStartTrial}
            >
              Start Free Enterprise Trial
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="border-white text-white hover:bg-white/10"
              onClick={handleTalkToSales}
            >
              Talk to Sales
            </Button>
          </div>

          <div className="flex flex-wrap justify-center items-center gap-8 text-white/80">
            <div className="flex items-center space-x-2">
              <span className="text-xl">✓</span>
              <span>14-day free trial</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-xl">✓</span>
              <span>No credit card required</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-xl">✓</span>
              <span>Cancel anytime</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-xl">✓</span>
              <span>24/7 support included</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
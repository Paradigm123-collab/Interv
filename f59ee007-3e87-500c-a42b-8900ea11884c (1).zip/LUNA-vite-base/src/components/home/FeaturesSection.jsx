export default function FeaturesSection() {
  const features = [
    {
      icon: '🤖',
      title: 'AI-Powered Interviews',
      description: 'Advanced AI conducts consistent, unbiased interviews 24/7, evaluating candidates with precision and fairness.',
      color: 'from-indigo-500 to-purple-600'
    },
    {
      icon: '👨‍💼',
      title: 'Human Expert Panel',
      description: 'Combine AI efficiency with human insight. Expert panelists provide nuanced evaluation and personal touch.',
      color: 'from-blue-500 to-cyan-600'
    },
    {
      icon: '🔒',
      title: 'Enterprise Security',
      description: 'Bank-level encryption, SOC 2 compliance, and advanced integrity monitoring protect your data.',
      color: 'from-purple-500 to-pink-600'
    },
    {
      icon: '📊',
      title: 'Real-Time Analytics',
      description: 'Comprehensive dashboards with actionable insights, performance metrics, and hiring trends.',
      color: 'from-green-500 to-emerald-600'
    },
    {
      icon: '🌐',
      title: 'Multi-Platform Support',
      description: 'Seamless experience across iOS, Android, and web. Your candidates can interview anywhere.',
      color: 'from-orange-500 to-red-600'
    },
    {
      icon: '⚡',
      title: 'Lightning Fast',
      description: 'Optimized for 200K+ daily users with sub-second response times and 99.9% uptime guarantee.',
      color: 'from-teal-500 to-cyan-600'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-slate-800 mb-4">
            Everything You Need to Hire Better
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Powerful features designed for enterprise-scale recruitment with the flexibility to adapt to your unique needs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border border-slate-100 hover:scale-105"
            >
              <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                <span className="text-3xl">{feature.icon}</span>
              </div>
              <h3 className="text-2xl font-bold text-slate-800 mb-3">{feature.title}</h3>
              <p className="text-slate-600 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
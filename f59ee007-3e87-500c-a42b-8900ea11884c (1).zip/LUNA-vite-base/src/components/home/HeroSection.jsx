import { useNavigate } from 'react-router-dom';
import Button from '../common/Button';

export default function HeroSection() {
  const navigate = useNavigate();

  const handleGetStarted = () => {
    navigate('/dashboard');
  };

  const handleScheduleDemo = () => {
    alert('Demo scheduling will be available soon! This will connect to your calendar system.');
  };

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 py-20 lg:py-32">
      {/* Animated Background */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-0 left-0 w-96 h-96 bg-indigo-300 rounded-full mix-blend-multiply filter blur-3xl animate-blob"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-300 rounded-full mix-blend-multiply filter blur-3xl animate-blob animation-delay-2000"></div>
        <div className="absolute bottom-0 left-1/2 w-96 h-96 bg-pink-300 rounded-full mix-blend-multiply filter blur-3xl animate-blob animation-delay-4000"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
<h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold mb-6 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent animate-fade-in">
            Your Trusted Assessment Partner
          </h1>
          <p className="text-xl sm:text-2xl text-slate-600 max-w-4xl mx-auto mb-8 animate-fade-in-delay leading-relaxed">
            Paradigm delivers enterprise-grade AI-powered assessments and video interviews. 
            Transform your hiring process with intelligent evaluation, unbiased insights, and seamless candidate experiences.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12 animate-fade-in-delay">
            <Button size="lg" onClick={handleGetStarted}>
              Get Started Now
            </Button>
            <Button variant="secondary" size="lg" onClick={handleScheduleDemo}>
              Schedule Demo
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="flex flex-wrap justify-center items-center gap-8 text-sm text-slate-600">
            <div className="flex items-center space-x-2">
              <span className="text-2xl">✓</span>
              <span>200K+ Daily Users</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-2xl">✓</span>
              <span>Enterprise Security</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-2xl">✓</span>
              <span>99.9% Uptime</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-2xl">✓</span>
              <span>24/7 Support</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
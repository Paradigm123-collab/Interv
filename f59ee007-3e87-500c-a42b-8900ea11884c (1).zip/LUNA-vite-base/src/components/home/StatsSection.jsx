export default function StatsSection() {
  const stats = [
    { value: '200K+', label: 'Daily Active Users', icon: '👥' },
    { value: '99.9%', label: 'Platform Uptime', icon: '⚡' },
    { value: '50M+', label: 'Interviews Conducted', icon: '🎥' },
    { value: '10K+', label: 'Enterprise Clients', icon: '🏢' }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-4">
            Trusted by Industry Leaders
          </h2>
          <p className="text-xl text-white/90 max-w-3xl mx-auto">
            Join thousands of companies transforming their hiring process with our platform
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 text-center hover:bg-white/20 transition-all duration-300 border border-white/20"
            >
              <div className="text-5xl mb-4">{stat.icon}</div>
              <div className="text-5xl font-bold text-white mb-2">{stat.value}</div>
              <div className="text-lg text-white/90">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
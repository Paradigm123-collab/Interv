import { useState, useEffect } from 'react';

export default function AIMonitoringPanel({ isActive }) {
  const [metrics, setMetrics] = useState({
    faceDetection: { status: 'normal', confidence: 98, alerts: 0 },
    gazeTracking: { status: 'normal', focusScore: 95, alerts: 0 },
    voiceAnalysis: { status: 'normal', clarity: 92, alerts: 0 },
    plagiarismCheck: { status: 'normal', similarity: 5, alerts: 0 }
  });

  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    if (isActive) {
      const interval = setInterval(() => {
        setMetrics(prev => ({
          faceDetection: {
            ...prev.faceDetection,
            confidence: Math.max(85, Math.min(100, prev.faceDetection.confidence + (Math.random() - 0.5) * 5))
          },
          gazeTracking: {
            ...prev.gazeTracking,
            focusScore: Math.max(80, Math.min(100, prev.gazeTracking.focusScore + (Math.random() - 0.5) * 8))
          },
          voiceAnalysis: {
            ...prev.voiceAnalysis,
            clarity: Math.max(75, Math.min(100, prev.voiceAnalysis.clarity + (Math.random() - 0.5) * 6))
          },
          plagiarismCheck: {
            ...prev.plagiarismCheck,
            similarity: Math.max(0, Math.min(15, prev.plagiarismCheck.similarity + (Math.random() - 0.5) * 2))
          }
        }));

        if (Math.random() > 0.9) {
          const alertTypes = [
            { type: 'warning', message: 'Gaze shifted away from screen', icon: '👀' },
            { type: 'info', message: 'Background noise detected', icon: '🔊' },
            { type: 'success', message: 'Strong eye contact maintained', icon: '✅' }
          ];
          const randomAlert = alertTypes[Math.floor(Math.random() * alertTypes.length)];
          setAlerts(prev => [...prev.slice(-4), { ...randomAlert, time: new Date().toLocaleTimeString() }]);
        }
      }, 2000);

      return () => clearInterval(interval);
    }
  }, [isActive]);

  const getStatusColor = (status) => {
    switch (status) {
      case 'normal': return 'text-green-600';
      case 'warning': return 'text-amber-600';
      case 'alert': return 'text-red-600';
      default: return 'text-slate-600';
    }
  };

  const getAlertColor = (type) => {
    switch (type) {
      case 'success': return 'bg-green-50 border-green-200 text-green-800';
      case 'warning': return 'bg-amber-50 border-amber-200 text-amber-800';
      case 'info': return 'bg-blue-50 border-blue-200 text-blue-800';
      default: return 'bg-slate-50 border-slate-200 text-slate-800';
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-4">
        <div className="flex items-center space-x-3">
          <span className="text-2xl">🤖</span>
          <div>
            <h3 className="font-bold">AI Monitoring</h3>
            <p className="text-xs opacity-90">Real-time integrity analysis</p>
          </div>
        </div>
      </div>

      {/* Metrics */}
      <div className="p-4 space-y-4">
        {/* Face Detection */}
        <div className="bg-slate-50 rounded-lg p-3">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <span className="text-xl">👤</span>
              <span className="font-semibold text-slate-800 text-sm">Face Detection</span>
            </div>
            <span className={`text-xs font-medium ${getStatusColor(metrics.faceDetection.status)}`}>
              {metrics.faceDetection.status.toUpperCase()}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex-1 bg-slate-200 rounded-full h-2 mr-3">
              <div
                className="bg-gradient-to-r from-green-500 to-emerald-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${metrics.faceDetection.confidence}%` }}
              ></div>
            </div>
            <span className="text-sm font-semibold text-slate-700">{Math.round(metrics.faceDetection.confidence)}%</span>
          </div>
        </div>

        {/* Gaze Tracking */}
        <div className="bg-slate-50 rounded-lg p-3">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <span className="text-xl">👀</span>
              <span className="font-semibold text-slate-800 text-sm">Gaze Tracking</span>
            </div>
            <span className={`text-xs font-medium ${getStatusColor(metrics.gazeTracking.status)}`}>
              {metrics.gazeTracking.status.toUpperCase()}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex-1 bg-slate-200 rounded-full h-2 mr-3">
              <div
                className="bg-gradient-to-r from-blue-500 to-cyan-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${metrics.gazeTracking.focusScore}%` }}
              ></div>
            </div>
            <span className="text-sm font-semibold text-slate-700">{Math.round(metrics.gazeTracking.focusScore)}%</span>
          </div>
        </div>

        {/* Voice Analysis */}
        <div className="bg-slate-50 rounded-lg p-3">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <span className="text-xl">🎤</span>
              <span className="font-semibold text-slate-800 text-sm">Voice Analysis</span>
            </div>
            <span className={`text-xs font-medium ${getStatusColor(metrics.voiceAnalysis.status)}`}>
              {metrics.voiceAnalysis.status.toUpperCase()}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex-1 bg-slate-200 rounded-full h-2 mr-3">
              <div
                className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${metrics.voiceAnalysis.clarity}%` }}
              ></div>
            </div>
            <span className="text-sm font-semibold text-slate-700">{Math.round(metrics.voiceAnalysis.clarity)}%</span>
          </div>
        </div>

        {/* Plagiarism Check */}
        <div className="bg-slate-50 rounded-lg p-3">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <span className="text-xl">📋</span>
              <span className="font-semibold text-slate-800 text-sm">Plagiarism Check</span>
            </div>
            <span className={`text-xs font-medium ${getStatusColor(metrics.plagiarismCheck.status)}`}>
              {metrics.plagiarismCheck.status.toUpperCase()}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex-1 bg-slate-200 rounded-full h-2 mr-3">
              <div
                className="bg-gradient-to-r from-orange-500 to-red-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${metrics.plagiarismCheck.similarity}%` }}
              ></div>
            </div>
            <span className="text-sm font-semibold text-slate-700">{Math.round(metrics.plagiarismCheck.similarity)}%</span>
          </div>
        </div>
      </div>

      {/* Alerts */}
      <div className="border-t border-slate-200 p-4">
        <h4 className="font-semibold text-slate-800 text-sm mb-3">Recent Alerts</h4>
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {alerts.length > 0 ? (
            alerts.map((alert, index) => (
              <div
                key={index}
                className={`p-2 rounded-lg border text-xs ${getAlertColor(alert.type)}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span>{alert.icon}</span>
                    <span>{alert.message}</span>
                  </div>
                  <span className="opacity-70">{alert.time}</span>
                </div>
              </div>
            ))
          ) : (
            <p className="text-slate-500 text-xs text-center py-4">No alerts yet</p>
          )}
        </div>
      </div>
    </div>
  );
}
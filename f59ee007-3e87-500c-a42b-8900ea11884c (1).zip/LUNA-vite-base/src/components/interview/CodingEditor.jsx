import { useState } from 'react';

export default function CodingEditor() {
  const [code, setCode] = useState(`// Write your solution here
function twoSum(nums, target) {
  // Your code here
}

// Test cases
console.log(twoSum([2, 7, 11, 15], 9)); // Expected: [0, 1]
console.log(twoSum([3, 2, 4], 6)); // Expected: [1, 2]`);

  const [language, setLanguage] = useState('javascript');
  const [output, setOutput] = useState('');
  const [isRunning, setIsRunning] = useState(false);

  const languages = [
    { id: 'javascript', name: 'JavaScript', icon: '🟨' },
    { id: 'python', name: 'Python', icon: '🐍' },
    { id: 'java', name: 'Java', icon: '☕' },
    { id: 'cpp', name: 'C++', icon: '⚡' }
  ];

  const handleRunCode = () => {
    setIsRunning(true);
    setOutput('Running code...\n');

    setTimeout(() => {
      try {
        const result = eval(code);
        setOutput(`✅ Code executed successfully!\n\nOutput:\n${result || 'No output'}`);
      } catch (error) {
        setOutput(`❌ Error:\n${error.message}`);
      }
      setIsRunning(false);
    }, 1500);
  };

  const handleSubmit = () => {
    const message = document.createElement('div');
    message.className = 'fixed top-20 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
    message.innerHTML = `
      <div class="flex items-center space-x-3">
        <span class="text-xl">✅</span>
        <div>
          <p class="font-semibold">Code Submitted!</p>
          <p class="text-sm opacity-90">Running automated tests...</p>
        </div>
      </div>
    `;
    document.body.appendChild(message);
    setTimeout(() => message.remove(), 3000);
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden h-full flex flex-col">
      {/* Editor Header */}
      <div className="bg-slate-50 border-b border-slate-200 p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-slate-800">💻 Coding Challenge</h3>
          <div className="flex items-center space-x-2">
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
            >
              {languages.map(lang => (
                <option key={lang.id} value={lang.id}>
                  {lang.icon} {lang.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
          <h4 className="font-semibold text-blue-900 text-sm mb-2">Problem: Two Sum</h4>
          <p className="text-sm text-blue-800">
            Given an array of integers nums and an integer target, return indices of the two numbers 
            such that they add up to target. You may assume that each input would have exactly one solution.
          </p>
        </div>
      </div>

      {/* Code Editor */}
      <div className="flex-1 flex flex-col min-h-0">
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          className="flex-1 p-4 font-mono text-sm bg-slate-900 text-green-400 focus:outline-none resize-none"
          spellCheck="false"
          placeholder="Write your code here..."
        />

        {/* Output Panel */}
        <div className="h-48 bg-slate-800 border-t border-slate-700 p-4 overflow-y-auto">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-300 text-sm font-semibold">Output:</span>
            <button
              onClick={() => setOutput('')}
              className="text-slate-400 hover:text-white text-xs"
            >
              Clear
            </button>
          </div>
          <pre className="text-slate-300 text-sm font-mono whitespace-pre-wrap">
            {output || 'No output yet. Run your code to see results.'}
          </pre>
        </div>
      </div>

      {/* Editor Controls */}
      <div className="bg-slate-50 border-t border-slate-200 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button
              onClick={handleRunCode}
              disabled={isRunning}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-all font-medium disabled:opacity-50 flex items-center space-x-2"
            >
              {isRunning ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Running...</span>
                </>
              ) : (
                <>
                  <span>▶️</span>
                  <span>Run Code</span>
                </>
              )}
            </button>

            <button
              onClick={handleSubmit}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-all font-medium"
            >
              ✅ Submit
            </button>
          </div>

          <div className="flex items-center space-x-2 text-sm text-slate-600">
            <span>⏱️ Time: 15:30</span>
            <span className="text-slate-300">|</span>
            <span>📊 Test Cases: 0/5</span>
          </div>
        </div>
      </div>
    </div>
  );
}
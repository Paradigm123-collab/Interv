export default function InterviewControls({ 
  interviewStatus, 
  isRecording, 
  onStart, 
  onEnd, 
  onToggleRecording 
}) {
  return (
    <div className="fixed bottom-8 left-1/2 transform -translate-x-1/2 z-50">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 p-4">
        <div className="flex items-center space-x-4">
          {interviewStatus === 'waiting' && (
            <button
              onClick={onStart}
              className="px-8 py-4 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-xl hover:from-green-700 hover:to-emerald-700 transition-all duration-200 shadow-lg font-bold text-lg flex items-center space-x-3 hover:scale-105 active:scale-95"
            >
              <span className="text-2xl">▶️</span>
              <span>Start Interview</span>
            </button>
          )}

          {interviewStatus === 'active' && (
            <>
              <button
                onClick={onToggleRecording}
                className={`px-6 py-3 rounded-xl transition-all font-medium flex items-center space-x-2 ${
                  isRecording
                    ? 'bg-red-500 hover:bg-red-600 text-white'
                    : 'bg-slate-200 hover:bg-slate-300 text-slate-700'
                }`}
              >
                <span className="text-xl">{isRecording ? '⏸️' : '⏺️'}</span>
                <span>{isRecording ? 'Pause Recording' : 'Resume Recording'}</span>
              </button>

              <button
                onClick={() => alert('Notes feature will be available with backend integration!')}
                className="px-6 py-3 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl transition-all font-medium flex items-center space-x-2"
              >
                <span className="text-xl">📝</span>
                <span>Take Notes</span>
              </button>

              <button
                onClick={onEnd}
                className="px-8 py-4 bg-gradient-to-r from-red-600 to-pink-600 text-white rounded-xl hover:from-red-700 hover:to-pink-700 transition-all duration-200 shadow-lg font-bold text-lg flex items-center space-x-3 hover:scale-105 active:scale-95"
              >
                <span className="text-2xl">⏹️</span>
                <span>End Interview</span>
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
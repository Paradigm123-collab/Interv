import { useState, useEffect } from 'react';

export default function TranscriptionPanel({ isActive }) {
  const [transcripts, setTranscripts] = useState([]);
  const [isListening, setIsListening] = useState(false);

  useEffect(() => {
    if (isActive && isListening) {
      const interval = setInterval(() => {
        const mockTranscripts = [
          { speaker: 'Interviewer', text: 'Can you explain your approach to state management in React?', time: '00:15' },
          { speaker: 'Candidate', text: 'I typically use Redux for complex applications and Context API for simpler state needs.', time: '00:32' },
          { speaker: 'Interviewer', text: 'What about performance optimization techniques?', time: '01:05' },
          { speaker: 'Candidate', text: 'I focus on memoization, code splitting, and lazy loading components.', time: '01:22' }
        ];
        
        if (transcripts.length < mockTranscripts.length) {
          setTranscripts(prev => [...prev, mockTranscripts[prev.length]]);
        }
      }, 3000);

      return () => clearInterval(interval);
    }
  }, [isActive, isListening, transcripts.length]);

  const toggleListening = () => {
    setIsListening(!isListening);
  };

  const downloadTranscript = () => {
    const text = transcripts.map(t => `[${t.time}] ${t.speaker}: ${t.text}`).join('\n\n');
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'interview-transcript.txt';
    a.click();
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <span className="text-2xl">📝</span>
            <div>
              <h3 className="font-bold">Live Transcription</h3>
              <p className="text-xs opacity-90">Real-time speech-to-text</p>
            </div>
          </div>
          <button
            onClick={toggleListening}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
              isListening 
                ? 'bg-white/20 hover:bg-white/30' 
                : 'bg-white/10 hover:bg-white/20'
            }`}
          >
            {isListening ? '🎤 Listening' : '⏸️ Paused'}
          </button>
        </div>
      </div>

      {/* Transcripts */}
      <div className="h-96 overflow-y-auto p-4 space-y-4">
        {transcripts.length > 0 ? (
          transcripts.map((transcript, index) => (
            <div
              key={index}
              className={`p-3 rounded-lg ${
                transcript.speaker === 'Interviewer'
                  ? 'bg-blue-50 border border-blue-200'
                  : 'bg-green-50 border border-green-200'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className={`text-xs font-semibold ${
                  transcript.speaker === 'Interviewer' ? 'text-blue-800' : 'text-green-800'
                }`}>
                  {transcript.speaker}
                </span>
                <span className="text-xs text-slate-500">{transcript.time}</span>
              </div>
              <p className="text-sm text-slate-700">{transcript.text}</p>
            </div>
          ))
        ) : (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-3xl">🎤</span>
            </div>
            <p className="text-slate-600 text-sm">
              {isListening ? 'Listening for speech...' : 'Click "Listening" to start transcription'}
            </p>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="bg-slate-50 border-t border-slate-200 p-4">
        <div className="flex items-center justify-between">
          <span className="text-sm text-slate-600">
            {transcripts.length} messages transcribed
          </span>
          <button
            onClick={downloadTranscript}
            disabled={transcripts.length === 0}
            className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-all text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
          >
            📥 Download
          </button>
        </div>
      </div>
    </div>
  );
}
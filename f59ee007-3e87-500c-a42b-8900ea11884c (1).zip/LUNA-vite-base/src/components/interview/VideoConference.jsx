import { useState, useEffect, useRef } from 'react';

export default function VideoConference({ interviewData, isRecording, interviewStatus }) {
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const localVideoRef = useRef(null);
  const remoteVideoRef = useRef(null);

  useEffect(() => {
    if (interviewStatus === 'active') {
      initializeVideo();
    }
    return () => {
      stopVideo();
    };
  }, [interviewStatus]);

  const initializeVideo = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: true, 
        audio: true 
      });
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }
    } catch (error) {
      console.error('Error accessing media devices:', error);
      alert('Unable to access camera/microphone. Please check permissions.');
    }
  };

  const stopVideo = () => {
    if (localVideoRef.current && localVideoRef.current.srcObject) {
      const tracks = localVideoRef.current.srcObject.getTracks();
      tracks.forEach(track => track.stop());
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    if (localVideoRef.current && localVideoRef.current.srcObject) {
      const audioTrack = localVideoRef.current.srcObject.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = isMuted;
      }
    }
  };

  const toggleVideo = () => {
    setIsVideoOff(!isVideoOff);
    if (localVideoRef.current && localVideoRef.current.srcObject) {
      const videoTrack = localVideoRef.current.srcObject.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = isVideoOff;
      }
    }
  };

  const toggleScreenShare = async () => {
    if (!isScreenSharing) {
      try {
        const screenStream = await navigator.mediaDevices.getDisplayMedia({ 
          video: true 
        });
        setIsScreenSharing(true);
        
        screenStream.getVideoTracks()[0].onended = () => {
          setIsScreenSharing(false);
        };
      } catch (error) {
        console.error('Error sharing screen:', error);
      }
    } else {
      setIsScreenSharing(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
      {/* Video Grid */}
      <div className="relative aspect-video bg-slate-900">
        {/* Remote Video (Candidate) */}
        <div className="absolute inset-0">
          <video
            ref={remoteVideoRef}
            autoPlay
            playsInline
            className="w-full h-full object-cover"
          />
          {interviewStatus === 'waiting' && (
            <div className="absolute inset-0 flex items-center justify-center bg-slate-800">
              <div className="text-center">
                <img
                  src={interviewData.candidate.avatar}
                  alt={interviewData.candidate.name}
                  className="w-32 h-32 rounded-full border-4 border-white mx-auto mb-4"
                />
                <p className="text-white text-xl font-semibold">{interviewData.candidate.name}</p>
                <p className="text-slate-300 text-sm mt-2">Waiting to join...</p>
              </div>
            </div>
          )}
          <div className="absolute bottom-4 left-4 bg-black/70 backdrop-blur-sm px-4 py-2 rounded-lg">
            <p className="text-white font-medium">{interviewData.candidate.name}</p>
            <p className="text-slate-300 text-sm">{interviewData.candidate.position}</p>
          </div>
        </div>

        {/* Local Video (Interviewer) - Picture in Picture */}
        <div className="absolute bottom-4 right-4 w-64 aspect-video bg-slate-800 rounded-xl overflow-hidden border-2 border-white shadow-2xl">
          <video
            ref={localVideoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />
          {isVideoOff && (
            <div className="absolute inset-0 flex items-center justify-center bg-slate-800">
              <div className="text-center">
                <div className="w-16 h-16 bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-2">
                  <span className="text-2xl">👤</span>
                </div>
                <p className="text-white text-sm">Camera Off</p>
              </div>
            </div>
          )}
          <div className="absolute bottom-2 left-2 bg-black/70 backdrop-blur-sm px-2 py-1 rounded">
            <p className="text-white text-xs font-medium">You</p>
          </div>
          {isMuted && (
            <div className="absolute top-2 right-2 bg-red-500 rounded-full p-2">
              <span className="text-white text-xs">🔇</span>
            </div>
          )}
        </div>

        {/* Recording Indicator */}
        {isRecording && (
          <div className="absolute top-4 left-4 bg-red-500 px-4 py-2 rounded-lg flex items-center space-x-2 animate-pulse">
            <span className="w-3 h-3 bg-white rounded-full"></span>
            <span className="text-white font-semibold text-sm">REC</span>
          </div>
        )}

        {/* Screen Sharing Indicator */}
        {isScreenSharing && (
          <div className="absolute top-4 right-4 bg-blue-500 px-4 py-2 rounded-lg">
            <span className="text-white font-semibold text-sm">🖥️ Sharing Screen</span>
          </div>
        )}
      </div>

      {/* Video Controls */}
      <div className="bg-slate-50 p-4 border-t border-slate-200">
        <div className="flex items-center justify-center space-x-4">
          <button
            onClick={toggleMute}
            className={`p-4 rounded-full transition-all ${
              isMuted 
                ? 'bg-red-500 hover:bg-red-600' 
                : 'bg-slate-200 hover:bg-slate-300'
            }`}
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            <span className="text-xl">{isMuted ? '🔇' : '🎤'}</span>
          </button>

          <button
            onClick={toggleVideo}
            className={`p-4 rounded-full transition-all ${
              isVideoOff 
                ? 'bg-red-500 hover:bg-red-600' 
                : 'bg-slate-200 hover:bg-slate-300'
            }`}
            title={isVideoOff ? 'Turn On Camera' : 'Turn Off Camera'}
          >
            <span className="text-xl">{isVideoOff ? '📹' : '🎥'}</span>
          </button>

          <button
            onClick={toggleScreenShare}
            className={`p-4 rounded-full transition-all ${
              isScreenSharing 
                ? 'bg-blue-500 hover:bg-blue-600' 
                : 'bg-slate-200 hover:bg-slate-300'
            }`}
            title={isScreenSharing ? 'Stop Sharing' : 'Share Screen'}
          >
            <span className="text-xl">🖥️</span>
          </button>

          <button
            onClick={() => alert('Chat feature will be available with backend integration!')}
            className="p-4 rounded-full bg-slate-200 hover:bg-slate-300 transition-all"
            title="Open Chat"
          >
            <span className="text-xl">💬</span>
          </button>

          <button
            onClick={() => alert('Settings panel will be available with backend integration!')}
            className="p-4 rounded-full bg-slate-200 hover:bg-slate-300 transition-all"
            title="Settings"
          >
            <span className="text-xl">⚙️</span>
          </button>
        </div>
      </div>
    </div>
  );
}
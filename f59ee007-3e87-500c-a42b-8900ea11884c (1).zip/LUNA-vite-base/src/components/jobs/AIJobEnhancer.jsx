import { useState } from 'react';

export default function AIJobEnhancer({ originalText, onEnhance, onClose }) {
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [enhancedText, setEnhancedText] = useState('');

  const handleEnhance = () => {
    setIsEnhancing(true);
    
    // Simulate AI enhancement
    setTimeout(() => {
      const enhanced = `${originalText}\n\n✨ AI Enhanced Version:\n\nWe're seeking a talented professional to join our innovative team. This role offers exciting opportunities to work on cutting-edge projects while collaborating with industry experts.\n\nKey Responsibilities:\n• Lead development of scalable solutions\n• Collaborate with cross-functional teams\n• Drive technical excellence and innovation\n• Mentor junior team members\n\nWhat We Offer:\n• Competitive compensation package\n• Flexible work arrangements\n• Professional development opportunities\n• Collaborative and inclusive culture`;
      
      setEnhancedText(enhanced);
      setIsEnhancing(false);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <span className="text-3xl">🤖</span>
              <div>
                <h3 className="text-xl font-bold">AI Job Description Enhancer</h3>
                <p className="text-sm opacity-90">Make your job posting more attractive and effective</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:bg-white/20 rounded-lg p-2 transition-colors"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Original */}
            <div>
              <h4 className="font-semibold text-slate-800 mb-3">Original Description</h4>
              <div className="bg-slate-50 rounded-lg p-4 h-64 overflow-y-auto">
                <p className="text-sm text-slate-700 whitespace-pre-wrap">
                  {originalText || 'No description provided yet...'}
                </p>
              </div>
            </div>

            {/* Enhanced */}
            <div>
              <h4 className="font-semibold text-slate-800 mb-3">AI Enhanced Version</h4>
              <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg p-4 h-64 overflow-y-auto">
                {isEnhancing ? (
                  <div className="flex flex-col items-center justify-center h-full">
                    <div className="w-12 h-12 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin mb-4"></div>
                    <p className="text-sm text-slate-600">Analyzing and enhancing...</p>
                  </div>
                ) : enhancedText ? (
                  <p className="text-sm text-slate-700 whitespace-pre-wrap">{enhancedText}</p>
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <p className="text-sm text-slate-500">Click "Enhance" to see AI suggestions</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* AI Suggestions */}
          {enhancedText && !isEnhancing && (
            <div className="mt-6 bg-blue-50 rounded-lg p-4">
              <h4 className="font-semibold text-blue-900 mb-2 flex items-center">
                <span className="mr-2">💡</span>
                AI Suggestions
              </h4>
              <ul className="space-y-2 text-sm text-blue-800">
                <li>• Added clear structure with key responsibilities</li>
                <li>• Highlighted company benefits and culture</li>
                <li>• Used action-oriented language</li>
                <li>• Improved readability and formatting</li>
              </ul>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-slate-200 p-6 bg-slate-50">
          <div className="flex items-center justify-between">
            <button
              onClick={onClose}
              className="px-6 py-3 text-slate-700 hover:bg-slate-200 rounded-lg transition-colors font-medium"
            >
              Cancel
            </button>
            <div className="flex items-center space-x-4">
              {!enhancedText && (
                <button
                  onClick={handleEnhance}
                  disabled={isEnhancing || !originalText}
                  className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all duration-200 shadow-lg font-medium disabled:opacity-50"
                >
                  {isEnhancing ? 'Enhancing...' : 'Enhance with AI'}
                </button>
              )}
              {enhancedText && (
                <button
                  onClick={() => onEnhance(enhancedText)}
                  className="px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all duration-200 shadow-lg font-medium"
                >
                  Use Enhanced Version
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
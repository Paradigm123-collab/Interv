export default function JobCard({ job, onViewJob }) {
  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'draft':
        return 'bg-amber-100 text-amber-800';
      case 'closed':
        return 'bg-slate-100 text-slate-800';
      default:
        return 'bg-blue-100 text-blue-800';
    }
  };

  return (
    <div
      onClick={() => onViewJob(job)}
      className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-slate-100 cursor-pointer group hover:scale-105 active:scale-95"
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${job.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
          <span className="text-white text-2xl">💼</span>
        </div>
        <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(job.status)}`}>
          {job.status}
        </span>
      </div>

      {/* Title & Department */}
      <h3 className="text-lg font-bold text-slate-800 mb-2 line-clamp-2 group-hover:text-indigo-600 transition-colors">
        {job.title}
      </h3>
      <p className="text-sm text-slate-600 mb-4">{job.department}</p>

      {/* Details */}
      <div className="space-y-2 mb-4">
        <div className="flex items-center text-sm text-slate-600">
          <span className="mr-2">📍</span>
          <span>{job.location}</span>
        </div>
        <div className="flex items-center text-sm text-slate-600">
          <span className="mr-2">💰</span>
          <span>{job.salary}</span>
        </div>
        <div className="flex items-center text-sm text-slate-600">
          <span className="mr-2">⏰</span>
          <span>{job.type}</span>
        </div>
      </div>

      {/* Stats */}
      <div className="flex items-center justify-between pt-4 border-t border-slate-100">
        <div className="flex items-center space-x-4">
          <div className="text-center">
            <p className="text-lg font-bold text-indigo-600">{job.applicants}</p>
            <p className="text-xs text-slate-500">Applicants</p>
          </div>
          <div className="text-center">
            <p className="text-lg font-bold text-purple-600">{job.interviews}</p>
            <p className="text-xs text-slate-500">Interviews</p>
          </div>
        </div>
        <span className="text-xs text-slate-500">{job.posted}</span>
      </div>

      {/* Skills Preview */}
      <div className="flex flex-wrap gap-2 mt-4">
        {job.skills.slice(0, 3).map((skill, index) => (
          <span
            key={index}
            className="px-2 py-1 bg-slate-100 text-slate-700 rounded-md text-xs font-medium"
          >
            {skill}
          </span>
        ))}
        {job.skills.length > 3 && (
          <span className="px-2 py-1 bg-slate-100 text-slate-700 rounded-md text-xs font-medium">
            +{job.skills.length - 3} more
          </span>
        )}
      </div>
    </div>
  );
}
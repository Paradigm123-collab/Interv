import { useState } from 'react';

export default function JobDetailView({ job, onBack }) {
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', label: 'Overview', icon: '📋' },
    { id: 'applicants', label: 'Applicants', icon: '👥' },
    { id: 'analytics', label: 'Analytics', icon: '📊' },
    { id: 'settings', label: 'Settings', icon: '⚙️' }
  ];

  const applicants = [
    {
      id: 1,
      name: 'Sarah Mitchell',
      email: 'sarah.mitchell@email.com',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      status: 'Interview Scheduled',
      score: 92,
      appliedDate: '2 days ago',
      experience: '6 years',
      location: 'San Francisco, CA'
    },
    {
      id: 2,
      name: 'Michael Chen',
      email: 'michael.chen@email.com',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      status: 'Under Review',
      score: 88,
      appliedDate: '3 days ago',
      experience: '5 years',
      location: 'Remote'
    },
    {
      id: 3,
      name: 'Emily Rodriguez',
      email: 'emily.rodriguez@email.com',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
      status: 'New Application',
      score: 85,
      appliedDate: '1 day ago',
      experience: '4 years',
      location: 'New York, NY'
    },
    {
      id: 4,
      name: 'David Park',
      email: 'david.park@email.com',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
      status: 'Interview Completed',
      score: 95,
      appliedDate: '5 days ago',
      experience: '7 years',
      location: 'Austin, TX'
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'Interview Scheduled':
        return 'bg-blue-100 text-blue-800';
      case 'Under Review':
        return 'bg-amber-100 text-amber-800';
      case 'New Application':
        return 'bg-green-100 text-green-800';
      case 'Interview Completed':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100">
        <button
          onClick={onBack}
          className="text-indigo-600 hover:text-indigo-700 font-medium mb-6 flex items-center space-x-2"
        >
          <span>←</span>
          <span>Back to Jobs</span>
        </button>

        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-4 mb-4">
              <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${job.color} flex items-center justify-center`}>
                <span className="text-white text-3xl">💼</span>
              </div>
              <div>
                <h1 className="text-3xl font-bold text-slate-800 mb-2">{job.title}</h1>
                <div className="flex items-center space-x-4 text-sm text-slate-600">
                  <span className="flex items-center">
                    <span className="mr-1">🏢</span>
                    {job.department}
                  </span>
                  <span className="flex items-center">
                    <span className="mr-1">📍</span>
                    {job.location}
                  </span>
                  <span className="flex items-center">
                    <span className="mr-1">⏰</span>
                    {job.type}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-6 mt-6">
              <div className="text-center">
                <p className="text-3xl font-bold text-indigo-600">{job.applicants}</p>
                <p className="text-sm text-slate-600">Applicants</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-purple-600">{job.interviews}</p>
                <p className="text-sm text-slate-600">Interviews</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-green-600">{job.status}</p>
                <p className="text-sm text-slate-600">Status</p>
              </div>
            </div>
          </div>

          <div className="flex flex-col space-y-3">
            <button className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium">
              Edit Job
            </button>
            <button className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium">
              Share Job
            </button>
            <button className="px-6 py-3 bg-white text-red-600 border-2 border-red-200 rounded-lg hover:border-red-300 hover:bg-red-50 transition-all duration-200 font-medium">
              Close Job
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
        <div className="flex border-b border-slate-200">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 px-6 py-4 font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <span className="mr-2">{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </div>

        <div className="p-8">
          {/* Overview Tab */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-bold text-slate-800 mb-4">Job Description</h3>
                <p className="text-slate-700 leading-relaxed">{job.description}</p>
              </div>

              <div>
                <h3 className="text-xl font-bold text-slate-800 mb-4">Required Skills</h3>
                <div className="flex flex-wrap gap-2">
                  {job.skills.map((skill, index) => (
                    <span
                      key={index}
                      className="px-4 py-2 bg-indigo-100 text-indigo-800 rounded-lg text-sm font-medium"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-xl font-bold text-slate-800 mb-4">Compensation</h3>
                  <p className="text-2xl font-bold text-green-600">{job.salary}</p>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-800 mb-4">Experience Required</h3>
                  <p className="text-2xl font-bold text-indigo-600">{job.experience}</p>
                </div>
              </div>
            </div>
          )}

          {/* Applicants Tab */}
          {activeTab === 'applicants' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">
                  All Applicants ({applicants.length})
                </h3>
                <div className="flex items-center space-x-4">
                  <input
                    type="text"
                    placeholder="Search applicants..."
                    className="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <select className="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <option>All Status</option>
                    <option>New Application</option>
                    <option>Under Review</option>
                    <option>Interview Scheduled</option>
                    <option>Interview Completed</option>
                  </select>
                </div>
              </div>

              {applicants.map((applicant) => (
                <div
                  key={applicant.id}
                  className="bg-slate-50 rounded-xl p-6 hover:bg-slate-100 transition-colors cursor-pointer"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <img
                        src={applicant.avatar}
                        alt={applicant.name}
                        className="w-16 h-16 rounded-full border-2 border-indigo-200"
                      />
                      <div>
                        <h4 className="font-semibold text-slate-800 text-lg">{applicant.name}</h4>
                        <p className="text-sm text-slate-600">{applicant.email}</p>
                        <div className="flex items-center space-x-4 mt-2 text-sm text-slate-600">
                          <span>📍 {applicant.location}</span>
                          <span>💼 {applicant.experience}</span>
                          <span>📅 Applied {applicant.appliedDate}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-center">
                        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center mb-2">
                          <span className="text-white text-xl font-bold">{applicant.score}</span>
                        </div>
                        <p className="text-xs text-slate-600">Match Score</p>
                      </div>
                      <span className={`px-4 py-2 rounded-lg text-sm font-medium ${getStatusColor(applicant.status)}`}>
                        {applicant.status}
                      </span>
                      <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-medium">
                        View Profile
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Analytics Tab */}
          {activeTab === 'analytics' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-slate-800 mb-6">Job Performance Analytics</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl p-6 border border-blue-100">
                  <h4 className="font-semibold text-slate-800 mb-2">Views</h4>
                  <p className="text-4xl font-bold text-blue-600">1,234</p>
                  <p className="text-sm text-slate-600 mt-2">+15% from last week</p>
                </div>
                
                <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-6 border border-green-100">
                  <h4 className="font-semibold text-slate-800 mb-2">Application Rate</h4>
                  <p className="text-4xl font-bold text-green-600">3.6%</p>
                  <p className="text-sm text-slate-600 mt-2">Above average</p>
                </div>
                
                <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6 border border-purple-100">
                  <h4 className="font-semibold text-slate-800 mb-2">Time to Fill</h4>
                  <p className="text-4xl font-bold text-purple-600">12 days</p>
                  <p className="text-sm text-slate-600 mt-2">Estimated</p>
                </div>
              </div>

              <div className="bg-slate-50 rounded-xl p-6">
                <h4 className="font-semibold text-slate-800 mb-4">Application Sources</h4>
                <div className="space-y-4">
                  {[
                    { source: 'Direct Application', count: 25, percentage: 55 },
                    { source: 'LinkedIn', count: 12, percentage: 27 },
                    { source: 'Indeed', count: 5, percentage: 11 },
                    { source: 'Referral', count: 3, percentage: 7 }
                  ].map((item, index) => (
                    <div key={index}>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-slate-700">{item.source}</span>
                        <span className="text-sm font-semibold text-slate-800">{item.count} applicants</span>
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-2">
                        <div
                          className="bg-gradient-to-r from-indigo-600 to-purple-600 h-2 rounded-full transition-all duration-500"
                          style={{ width: `${item.percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Settings Tab */}
          {activeTab === 'settings' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-slate-800 mb-6">Job Settings</h3>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div>
                    <h4 className="font-semibold text-slate-800">Job Status</h4>
                    <p className="text-sm text-slate-600">Control job visibility</p>
                  </div>
                  <select className="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <option>Active</option>
                    <option>Draft</option>
                    <option>Closed</option>
                  </select>
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div>
                    <h4 className="font-semibold text-slate-800">Auto-close Date</h4>
                    <p className="text-sm text-slate-600">Automatically close after date</p>
                  </div>
                  <input
                    type="date"
                    className="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div>
                    <h4 className="font-semibold text-slate-800">Email Notifications</h4>
                    <p className="text-sm text-slate-600">Receive updates about applications</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div>
                    <h4 className="font-semibold text-slate-800">AI Screening</h4>
                    <p className="text-sm text-slate-600">Automatically screen applicants</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                  </label>
                </div>
              </div>

              <div className="pt-6 border-t border-slate-200">
                <button className="px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium">
                  Delete Job Posting
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
import { useState } from 'react';
import JobCard from './JobCard';
import JobFilters from './JobFilters';

export default function JobListView({ onViewJob, onCreateJob }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortBy, setSortBy] = useState('recent');

  // Dummy job data
  const allJobs = [
    {
      id: 1,
      title: 'Senior React Developer',
      department: 'Engineering',
      location: 'San Francisco, CA',
      type: 'Full-time',
      salary: '$120,000 - $160,000',
      status: 'Active',
      applicants: 45,
      interviews: 12,
      posted: '2 days ago',
      description: 'We are seeking an experienced React developer to join our growing team...',
      skills: ['React', 'TypeScript', 'Node.js', 'GraphQL', 'AWS'],
      experience: '5+ years',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      id: 2,
      title: 'Product Manager',
      department: 'Product',
      location: 'Remote',
      type: 'Full-time',
      salary: '$130,000 - $170,000',
      status: 'Active',
      applicants: 67,
      interviews: 18,
      posted: '5 days ago',
      description: 'Looking for a strategic product manager to drive our product vision...',
      skills: ['Product Strategy', 'Agile', 'Data Analysis', 'User Research'],
      experience: '7+ years',
      color: 'from-purple-500 to-pink-500'
    },
    {
      id: 3,
      title: 'UX Designer',
      department: 'Design',
      location: 'New York, NY',
      type: 'Full-time',
      salary: '$100,000 - $140,000',
      status: 'Active',
      applicants: 34,
      interviews: 8,
      posted: '1 week ago',
      description: 'Join our design team to create beautiful and intuitive user experiences...',
      skills: ['Figma', 'User Research', 'Prototyping', 'Design Systems'],
      experience: '4+ years',
      color: 'from-green-500 to-emerald-500'
    },
    {
      id: 4,
      title: 'DevOps Engineer',
      department: 'Engineering',
      location: 'Austin, TX',
      type: 'Full-time',
      salary: '$110,000 - $150,000',
      status: 'Active',
      applicants: 28,
      interviews: 6,
      posted: '3 days ago',
      description: 'Seeking a DevOps engineer to optimize our infrastructure and deployment...',
      skills: ['AWS', 'Docker', 'Kubernetes', 'CI/CD', 'Terraform'],
      experience: '5+ years',
      color: 'from-orange-500 to-red-500'
    },
    {
      id: 5,
      title: 'Data Scientist',
      department: 'Data',
      location: 'Boston, MA',
      type: 'Full-time',
      salary: '$125,000 - $165,000',
      status: 'Draft',
      applicants: 0,
      interviews: 0,
      posted: '1 hour ago',
      description: 'Looking for a data scientist to build ML models and drive insights...',
      skills: ['Python', 'Machine Learning', 'SQL', 'TensorFlow', 'Statistics'],
      experience: '6+ years',
      color: 'from-indigo-500 to-purple-500'
    },
    {
      id: 6,
      title: 'Marketing Manager',
      department: 'Marketing',
      location: 'Los Angeles, CA',
      type: 'Full-time',
      salary: '$95,000 - $130,000',
      status: 'Active',
      applicants: 41,
      interviews: 10,
      posted: '4 days ago',
      description: 'Drive our marketing strategy and lead campaigns to grow our brand...',
      skills: ['Digital Marketing', 'SEO', 'Content Strategy', 'Analytics'],
      experience: '5+ years',
      color: 'from-pink-500 to-rose-500'
    },
    {
      id: 7,
      title: 'Sales Executive',
      department: 'Sales',
      location: 'Chicago, IL',
      type: 'Full-time',
      salary: '$80,000 - $120,000 + Commission',
      status: 'Active',
      applicants: 38,
      interviews: 9,
      posted: '6 days ago',
      description: 'Join our sales team to drive revenue and build client relationships...',
      skills: ['B2B Sales', 'CRM', 'Negotiation', 'Account Management'],
      experience: '3+ years',
      color: 'from-teal-500 to-cyan-500'
    },
    {
      id: 8,
      title: 'Content Writer',
      department: 'Marketing',
      location: 'Remote',
      type: 'Contract',
      salary: '$60,000 - $80,000',
      status: 'Closed',
      applicants: 29,
      interviews: 7,
      posted: '2 weeks ago',
      description: 'Create engaging content for our blog, social media, and marketing materials...',
      skills: ['Content Writing', 'SEO', 'Copywriting', 'Social Media'],
      experience: '2+ years',
      color: 'from-amber-500 to-yellow-500'
    }
  ];

  // Filter jobs based on search and status
  const filteredJobs = allJobs.filter(job => {
    const matchesSearch = job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         job.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         job.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || job.status.toLowerCase() === statusFilter.toLowerCase();
    return matchesSearch && matchesStatus;
  });

  // Sort jobs
  const sortedJobs = [...filteredJobs].sort((a, b) => {
    switch (sortBy) {
      case 'recent':
        return a.id - b.id;
      case 'applicants':
        return b.applicants - a.applicants;
      case 'title':
        return a.title.localeCompare(b.title);
      default:
        return 0;
    }
  });

  const stats = {
    total: allJobs.length,
    active: allJobs.filter(j => j.status === 'Active').length,
    draft: allJobs.filter(j => j.status === 'Draft').length,
    closed: allJobs.filter(j => j.status === 'Closed').length,
    totalApplicants: allJobs.reduce((sum, j) => sum + j.applicants, 0)
  };

  return (
    <div className="space-y-6">
      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Total Jobs</p>
              <p className="text-3xl font-bold text-slate-800">{stats.total}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">💼</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Active</p>
              <p className="text-3xl font-bold text-green-600">{stats.active}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">✅</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Draft</p>
              <p className="text-3xl font-bold text-amber-600">{stats.draft}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-yellow-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">📝</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Closed</p>
              <p className="text-3xl font-bold text-slate-600">{stats.closed}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-slate-500 to-slate-600 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">🔒</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Applicants</p>
              <p className="text-3xl font-bold text-indigo-600">{stats.totalApplicants}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">👥</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <JobFilters
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        statusFilter={statusFilter}
        onStatusChange={setStatusFilter}
        sortBy={sortBy}
        onSortChange={setSortBy}
      />

      {/* Job Grid */}
      {sortedJobs.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sortedJobs.map(job => (
            <JobCard key={job.id} job={job} onViewJob={onViewJob} />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl p-12 text-center shadow-lg border border-slate-100">
          <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-4xl">🔍</span>
          </div>
          <h3 className="text-xl font-semibold text-slate-800 mb-2">No jobs found</h3>
          <p className="text-slate-600 mb-6">Try adjusting your search or filters</p>
          <button
            onClick={onCreateJob}
            className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium"
          >
            Create Your First Job
          </button>
        </div>
      )}
    </div>
  );
}
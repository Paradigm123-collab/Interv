import { useState } from 'react';

export default function SkillExtractor({ description, onSkillsExtracted, currentSkills }) {
  const [isExtracting, setIsExtracting] = useState(false);
  const [suggestedSkills, setSuggestedSkills] = useState([]);

  const handleExtract = () => {
    setIsExtracting(true);

    // Simulate AI skill extraction
    setTimeout(() => {
      const skills = [
        'React', 'TypeScript', 'Node.js', 'GraphQL', 'AWS',
        'Docker', 'Kubernetes', 'CI/CD', 'Agile', 'REST APIs',
        'MongoDB', 'PostgreSQL', 'Redis', 'Git', 'Testing'
      ];
      
      // Filter out already selected skills
      const newSkills = skills.filter(skill => !currentSkills.includes(skill));
      setSuggestedSkills(newSkills);
      setIsExtracting(false);
    }, 1500);
  };

  const handleAddSkill = (skill) => {
    const updatedSkills = [...currentSkills, skill];
    onSkillsExtracted(updatedSkills);
    setSuggestedSkills(suggestedSkills.filter(s => s !== skill));
  };

  const handleAddAllSkills = () => {
    const updatedSkills = [...currentSkills, ...suggestedSkills];
    onSkillsExtracted(updatedSkills);
    setSuggestedSkills([]);
  };

  return (
    <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-lg p-6 border border-indigo-100">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <span className="text-2xl">🎯</span>
          <div>
            <h4 className="font-semibold text-slate-800">Automatic Skill Extraction</h4>
            <p className="text-sm text-slate-600">AI will identify required skills from your description</p>
          </div>
        </div>
        <button
          onClick={handleExtract}
          disabled={isExtracting || !description}
          className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium disabled:opacity-50 flex items-center space-x-2"
        >
          {isExtracting ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              <span>Extracting...</span>
            </>
          ) : (
            <>
              <span>🤖</span>
              <span>Extract Skills</span>
            </>
          )}
        </button>
      </div>

      {suggestedSkills.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-medium text-slate-700">
              Suggested Skills ({suggestedSkills.length})
            </p>
            <button
              onClick={handleAddAllSkills}
              className="text-sm text-indigo-600 hover:text-indigo-700 font-medium"
            >
              Add All →
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {suggestedSkills.map((skill, index) => (
              <button
                key={index}
                onClick={() => handleAddSkill(skill)}
                className="px-3 py-2 bg-white text-slate-700 rounded-lg text-sm font-medium hover:bg-indigo-100 hover:text-indigo-700 transition-colors border border-slate-200 hover:border-indigo-300"
              >
                + {skill}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
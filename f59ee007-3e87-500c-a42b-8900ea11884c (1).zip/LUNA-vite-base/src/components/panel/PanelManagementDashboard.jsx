import { useState } from 'react';

export default function PanelManagementDashboard({ onViewPanelist, onAddPanelist }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterSpecialty, setFilterSpecialty] = useState('all');

  const panelists = [
    {
      id: 1,
      name: 'Dr. Sarah Johnson',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      role: 'Senior Technical Lead',
      specialty: 'React & Frontend',
      status: 'Active',
      rating: 4.9,
      totalInterviews: 156,
      completedThisMonth: 12,
      averageScore: 92,
      availability: 'Available',
      nextInterview: '2024-12-29 14:00',
      earnings: '$4,680',
      color: 'from-green-500 to-emerald-500'
    },
    {
      id: 2,
      name: 'Mark Wilson',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      role: 'Engineering Manager',
      specialty: 'Full Stack & Architecture',
      status: 'Active',
      rating: 4.8,
      totalInterviews: 203,
      completedThisMonth: 15,
      averageScore: 88,
      availability: 'Busy',
      nextInterview: '2024-12-28 16:00',
      earnings: '$6,090',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      id: 3,
      name: 'Emily Chen',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
      role: 'Product Manager',
      specialty: 'Product & UX',
      status: 'Active',
      rating: 4.7,
      totalInterviews: 134,
      completedThisMonth: 10,
      averageScore: 90,
      availability: 'Available',
      nextInterview: '2024-12-30 10:00',
      earnings: '$4,020',
      color: 'from-purple-500 to-pink-500'
    },
    {
      id: 4,
      name: 'John Anderson',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
      role: 'Tech Lead',
      specialty: 'Backend & DevOps',
      status: 'On Leave',
      rating: 4.6,
      totalInterviews: 178,
      completedThisMonth: 0,
      averageScore: 87,
      availability: 'Unavailable',
      nextInterview: 'N/A',
      earnings: '$5,340',
      color: 'from-slate-500 to-slate-600'
    },
    {
      id: 5,
      name: 'Lisa Anderson',
      avatar: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop',
      role: 'Senior Developer',
      specialty: 'Mobile Development',
      status: 'Active',
      rating: 4.9,
      totalInterviews: 145,
      completedThisMonth: 14,
      averageScore: 91,
      availability: 'Available',
      nextInterview: '2024-12-29 11:00',
      earnings: '$4,350',
      color: 'from-indigo-500 to-purple-500'
    },
    {
      id: 6,
      name: 'James Wilson',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop',
      role: 'Data Scientist',
      specialty: 'AI & Machine Learning',
      status: 'Active',
      rating: 4.8,
      totalInterviews: 98,
      completedThisMonth: 8,
      averageScore: 89,
      availability: 'Busy',
      nextInterview: '2024-12-28 15:30',
      earnings: '$2,940',
      color: 'from-orange-500 to-red-500'
    },
    {
      id: 7,
      name: 'Maria Garcia',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop',
      role: 'UX Designer',
      specialty: 'Design & User Research',
      status: 'Active',
      rating: 4.7,
      totalInterviews: 112,
      completedThisMonth: 9,
      averageScore: 88,
      availability: 'Available',
      nextInterview: '2024-12-30 14:00',
      earnings: '$3,360',
      color: 'from-pink-500 to-rose-500'
    },
    {
      id: 8,
      name: 'Robert Taylor',
      avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop',
      role: 'Security Expert',
      specialty: 'Cybersecurity',
      status: 'Active',
      rating: 4.9,
      totalInterviews: 87,
      completedThisMonth: 7,
      averageScore: 93,
      availability: 'Available',
      nextInterview: '2024-12-31 09:00',
      earnings: '$2,610',
      color: 'from-teal-500 to-cyan-500'
    }
  ];

  const filteredPanelists = panelists.filter(panelist => {
    const matchesSearch = 
      panelist.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      panelist.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
      panelist.specialty.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = filterStatus === 'all' || panelist.status === filterStatus;
    const matchesSpecialty = filterSpecialty === 'all' || panelist.specialty.includes(filterSpecialty);
    
    return matchesSearch && matchesStatus && matchesSpecialty;
  });

  const stats = {
    total: panelists.length,
    active: panelists.filter(p => p.status === 'Active').length,
    available: panelists.filter(p => p.availability === 'Available').length,
    totalInterviews: panelists.reduce((sum, p) => sum + p.completedThisMonth, 0),
    averageRating: (panelists.reduce((sum, p) => sum + p.rating, 0) / panelists.length).toFixed(1),
    totalEarnings: panelists.reduce((sum, p) => sum + parseFloat(p.earnings.replace(/[$,]/g, '')), 0).toFixed(0)
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Active':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'On Leave':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Inactive':
        return 'bg-slate-100 text-slate-800 border-slate-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getAvailabilityColor = (availability) => {
    switch (availability) {
      case 'Available':
        return 'bg-green-100 text-green-800';
      case 'Busy':
        return 'bg-amber-100 text-amber-800';
      case 'Unavailable':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Total Panelists</p>
              <p className="text-3xl font-bold text-slate-800">{stats.total}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">👥</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Active</p>
              <p className="text-3xl font-bold text-green-600">{stats.active}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">✅</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Available Now</p>
              <p className="text-3xl font-bold text-indigo-600">{stats.available}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">📅</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">This Month</p>
              <p className="text-3xl font-bold text-purple-600">{stats.totalInterviews}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">🎯</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Avg Rating</p>
              <p className="text-3xl font-bold text-amber-600">{stats.averageRating}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-yellow-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">⭐</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Total Earnings</p>
              <p className="text-2xl font-bold text-green-600">${stats.totalEarnings}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">💰</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Search Panelists
            </label>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by name, role, or specialty..."
              className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Status
            </label>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Status</option>
              <option value="Active">Active</option>
              <option value="On Leave">On Leave</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Specialty
            </label>
            <select
              value={filterSpecialty}
              onChange={(e) => setFilterSpecialty(e.target.value)}
              className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Specialties</option>
              <option value="React">React & Frontend</option>
              <option value="Full Stack">Full Stack</option>
              <option value="Backend">Backend</option>
              <option value="Mobile">Mobile</option>
              <option value="AI">AI & ML</option>
              <option value="Design">Design</option>
            </select>
          </div>
        </div>
      </div>

      {/* Add Panelist Button */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-800">Panel Members</h2>
        <button
          onClick={onAddPanelist}
          className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium flex items-center space-x-2"
        >
          <span>➕</span>
          <span>Add Panelist</span>
        </button>
      </div>

      {/* Panelists Grid */}
      {filteredPanelists.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPanelists.map(panelist => (
            <div
              key={panelist.id}
              onClick={() => onViewPanelist(panelist)}
              className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-slate-100 cursor-pointer group hover:scale-105 active:scale-95"
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <img
                    src={panelist.avatar}
                    alt={panelist.name}
                    className="w-14 h-14 rounded-full border-2 border-indigo-200 group-hover:scale-110 transition-transform"
                  />
                  <div>
                    <h3 className="font-bold text-slate-800 group-hover:text-indigo-600 transition-colors">
                      {panelist.name}
                    </h3>
                    <p className="text-sm text-slate-600">{panelist.role}</p>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(panelist.status)}`}>
                  {panelist.status}
                </span>
              </div>

              {/* Specialty */}
              <div className="mb-4">
                <span className="px-3 py-1 bg-indigo-50 text-indigo-700 rounded-lg text-xs font-medium">
                  {panelist.specialty}
                </span>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="bg-slate-50 rounded-lg p-3">
                  <p className="text-xs text-slate-600 mb-1">Rating</p>
                  <p className="text-xl font-bold text-amber-600">⭐ {panelist.rating}</p>
                </div>
                <div className="bg-slate-50 rounded-lg p-3">
                  <p className="text-xs text-slate-600 mb-1">This Month</p>
                  <p className="text-xl font-bold text-indigo-600">{panelist.completedThisMonth}</p>
                </div>
              </div>

              {/* Availability */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-slate-600">Availability</span>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getAvailabilityColor(panelist.availability)}`}>
                    {panelist.availability}
                  </span>
                </div>
                {panelist.nextInterview !== 'N/A' && (
                  <p className="text-xs text-slate-600">Next: {panelist.nextInterview}</p>
                )}
              </div>

              {/* Earnings */}
              <div className="pt-4 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">Total Earnings</span>
                  <span className="text-lg font-bold text-green-600">{panelist.earnings}</span>
                </div>
              </div>

              {/* View Details */}
              <div className="mt-4 text-center">
                <span className="text-indigo-600 text-sm font-medium group-hover:translate-x-1 transition-transform inline-block">
                  View Profile →
                </span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl p-12 text-center shadow-lg border border-slate-100">
          <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-4xl">🔍</span>
          </div>
          <h3 className="text-xl font-semibold text-slate-800 mb-2">No panelists found</h3>
          <p className="text-slate-600">Try adjusting your search or filters</p>
        </div>
      )}
    </div>
  );
}
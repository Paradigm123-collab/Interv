import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function PrepMockInterview() {
  const navigate = useNavigate();
  const [selectedInterview, setSelectedInterview] = useState(null);

  const mockInterviews = [
    {
      id: 1,
      title: 'React Developer Technical Interview',
      type: 'AI',
      difficulty: 'Intermediate',
      duration: '45 min',
      questions: 15,
      topics: ['React Hooks', 'State Management', 'Performance', 'Testing'],
      description: 'Comprehensive React interview covering hooks, state management, and best practices.',
      thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400&h=225&fit=crop',
      completedSessions: 3,
      avgScore: 85,
      lastAttempt: '2 days ago'
    },
    {
      id: 2,
      title: 'Behavioral Interview Practice',
      type: 'AI',
      difficulty: 'Easy',
      duration: '30 min',
      questions: 10,
      topics: ['STAR Method', 'Leadership', 'Teamwork', 'Conflict Resolution'],
      description: 'Practice common behavioral questions using the STAR method with AI feedback.',
      thumbnail: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=225&fit=crop',
      completedSessions: 5,
      avgScore: 88,
      lastAttempt: '1 week ago'
    },
    {
      id: 3,
      title: 'System Design Mock Interview',
      type: 'AI',
      difficulty: 'Advanced',
      duration: '60 min',
      questions: 8,
      topics: ['Scalability', 'Database Design', 'Microservices', 'Caching'],
      description: 'Practice designing scalable systems with real-world scenarios and constraints.',
      thumbnail: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=400&h=225&fit=crop',
      completedSessions: 1,
      avgScore: 75,
      lastAttempt: '3 days ago'
    },
    {
      id: 4,
      title: 'JavaScript Coding Interview',
      type: 'AI',
      difficulty: 'Intermediate',
      duration: '45 min',
      questions: 12,
      topics: ['Algorithms', 'Data Structures', 'Problem Solving', 'Optimization'],
      description: 'Solve coding problems with live code execution and AI-powered hints.',
      thumbnail: 'https://images.unsplash.com/photo-1587620962725-abab7fe55159?w=400&h=225&fit=crop',
      completedSessions: 0,
      avgScore: 0,
      lastAttempt: 'Never'
    },
    {
      id: 5,
      title: 'Product Manager Case Study',
      type: 'AI',
      difficulty: 'Intermediate',
      duration: '50 min',
      questions: 10,
      topics: ['Product Strategy', 'Metrics', 'User Research', 'Prioritization'],
      description: 'Work through product case studies and demonstrate strategic thinking.',
      thumbnail: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=225&fit=crop',
      completedSessions: 2,
      avgScore: 82,
      lastAttempt: '5 days ago'
    },
    {
      id: 6,
      title: 'Full Stack Developer Interview',
      type: 'AI',
      difficulty: 'Advanced',
      duration: '75 min',
      questions: 20,
      topics: ['Frontend', 'Backend', 'Database', 'DevOps', 'Security'],
      description: 'Comprehensive full-stack interview covering all aspects of web development.',
      thumbnail: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=400&h=225&fit=crop',
      completedSessions: 0,
      avgScore: 0,
      lastAttempt: 'Never'
    }
  ];

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Easy':
        return 'bg-green-100 text-green-800';
      case 'Intermediate':
        return 'bg-amber-100 text-amber-800';
      case 'Advanced':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  const handleStartInterview = (interview) => {
    alert(`Starting Mock Interview: ${interview.title}\n\nThis will launch an interactive AI interview session with:\n- Real-time question delivery\n- Voice/video recording\n- Live feedback and hints\n- Performance scoring\n\nYou'll be redirected to the interview interface!\n\nFull functionality will be available with backend integration.`);
    navigate('/interview');
  };

  const stats = {
    total: mockInterviews.length,
    completed: mockInterviews.filter(m => m.completedSessions > 0).length,
    avgScore: Math.round(
      mockInterviews.filter(m => m.avgScore > 0).reduce((sum, m) => sum + m.avgScore, 0) /
      mockInterviews.filter(m => m.avgScore > 0).length
    ) || 0,
    totalSessions: mockInterviews.reduce((sum, m) => sum + m.completedSessions, 0)
  };

  return (
    <div className="space-y-6">
      {/* Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Available</p>
              <p className="text-3xl font-bold text-blue-600">{stats.total}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">🎯</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Completed</p>
              <p className="text-3xl font-bold text-green-600">{stats.completed}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">✅</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Avg Score</p>
              <p className="text-3xl font-bold text-purple-600">{stats.avgScore}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">⭐</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Total Sessions</p>
              <p className="text-3xl font-bold text-indigo-600">{stats.totalSessions}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">🎥</span>
            </div>
          </div>
        </div>
      </div>

      {/* Mock Interviews Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {mockInterviews.map((interview) => (
          <div
            key={interview.id}
            className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden hover:shadow-xl transition-all duration-300 group"
          >
            {/* Thumbnail */}
            <div className="relative aspect-video overflow-hidden">
              <img
                src={interview.thumbnail}
                alt={interview.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute top-3 left-3 flex items-center space-x-2">
                <span className={`px-3 py-1 rounded-lg text-xs font-medium ${getDifficultyColor(interview.difficulty)}`}>
                  {interview.difficulty}
                </span>
                <span className="px-3 py-1 bg-black/70 backdrop-blur-sm text-white rounded-lg text-xs font-medium">
                  🤖 AI Interview
                </span>
              </div>
            </div>

            {/* Content */}
            <div className="p-6">
              <h3 className="text-lg font-bold text-slate-800 mb-2 line-clamp-2 group-hover:text-indigo-600 transition-colors">
                {interview.title}
              </h3>

              <p className="text-sm text-slate-600 mb-4 line-clamp-2">
                {interview.description}
              </p>

              {/* Topics */}
              <div className="flex flex-wrap gap-2 mb-4">
                {interview.topics.slice(0, 3).map((topic, index) => (
                  <span
                    key={index}
                    className="px-2 py-1 bg-indigo-100 text-indigo-800 rounded text-xs font-medium"
                  >
                    {topic}
                  </span>
                ))}
                {interview.topics.length > 3 && (
                  <span className="px-2 py-1 bg-slate-100 text-slate-700 rounded text-xs">
                    +{interview.topics.length - 3}
                  </span>
                )}
              </div>

              {/* Meta Info */}
              <div className="grid grid-cols-2 gap-3 mb-4 text-sm text-slate-600">
                <div className="flex items-center">
                  <span className="mr-1">⏱️</span>
                  <span>{interview.duration}</span>
                </div>
                <div className="flex items-center">
                  <span className="mr-1">❓</span>
                  <span>{interview.questions} questions</span>
                </div>
              </div>

              {/* Stats */}
              {interview.completedSessions > 0 && (
                <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg p-3 mb-4 border border-indigo-100">
                  <div className="flex items-center justify-between text-sm">
                    <div>
                      <p className="text-slate-600">Sessions: {interview.completedSessions}</p>
                      <p className="text-slate-600">Last: {interview.lastAttempt}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-indigo-600">{interview.avgScore}</p>
                      <p className="text-xs text-slate-600">Avg Score</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Action Button */}
              <button
                onClick={() => handleStartInterview(interview)}
                className="w-full px-4 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 font-medium flex items-center justify-center space-x-2"
              >
                <span>🚀</span>
                <span>{interview.completedSessions > 0 ? 'Practice Again' : 'Start Interview'}</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
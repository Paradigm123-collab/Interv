export default function PrepProgressTracker() {
  const progressData = {
    overall: {
      completedResources: 12,
      totalResources: 45,
      completedMocks: 8,
      totalMocks: 15,
      studyHours: 24,
      avgScore: 85,
      streak: 7
    },
    categories: [
      { name: 'Technical', progress: 75, resources: 8, score: 88 },
      { name: 'Behavioral', progress: 90, resources: 5, score: 92 },
      { name: 'Coding', progress: 60, resources: 6, score: 82 },
      { name: 'System Design', progress: 40, resources: 3, score: 78 },
      { name: 'Product', progress: 50, resources: 4, score: 85 }
    ],
    recentActivity: [
      {
        id: 1,
        type: 'resource',
        title: 'React Interview Questions',
        action: 'Completed',
        score: 92,
        date: '2 hours ago',
        icon: '📚'
      },
      {
        id: 2,
        type: 'mock',
        title: 'Behavioral Interview Practice',
        action: 'Completed',
        score: 88,
        date: '1 day ago',
        icon: '🎯'
      },
      {
        id: 3,
        type: 'resource',
        title: 'JavaScript Coding Challenges',
        action: 'In Progress',
        score: 0,
        date: '2 days ago',
        icon: '📚'
      },
      {
        id: 4,
        type: 'mock',
        title: 'System Design Mock Interview',
        action: 'Completed',
        score: 75,
        date: '3 days ago',
        icon: '🎯'
      },
      {
        id: 5,
        type: 'resource',
        title: 'Product Manager Interview Guide',
        action: 'Started',
        score: 0,
        date: '5 days ago',
        icon: '📚'
      }
    ],
    weeklyProgress: [
      { day: 'Mon', hours: 2, score: 85 },
      { day: 'Tue', hours: 3, score: 88 },
      { day: 'Wed', hours: 4, score: 90 },
      { day: 'Thu', hours: 2, score: 82 },
      { day: 'Fri', hours: 5, score: 92 },
      { day: 'Sat', hours: 4, score: 87 },
      { day: 'Sun', hours: 4, score: 89 }
    ],
    achievements: [
      { id: 1, title: '7-Day Streak', icon: '🔥', unlocked: true },
      { id: 2, title: '10 Resources Completed', icon: '📚', unlocked: true },
      { id: 3, title: 'Perfect Score', icon: '💯', unlocked: true },
      { id: 4, title: '5 Mock Interviews', icon: '🎯', unlocked: true },
      { id: 5, title: '20 Hours Study Time', icon: '⏰', unlocked: true },
      { id: 6, title: 'Master Learner', icon: '🏆', unlocked: false }
    ]
  };

  const getProgressColor = (progress) => {
    if (progress >= 80) return 'from-green-500 to-emerald-500';
    if (progress >= 60) return 'from-blue-500 to-cyan-500';
    if (progress >= 40) return 'from-amber-500 to-yellow-500';
    return 'from-red-500 to-pink-500';
  };

  return (
    <div className="space-y-6">
      {/* Overall Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center mx-auto mb-3">
              <span className="text-white text-2xl">📚</span>
            </div>
            <p className="text-2xl font-bold text-blue-600">{progressData.overall.completedResources}/{progressData.overall.totalResources}</p>
            <p className="text-xs text-slate-600 mt-1">Resources</p>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center mx-auto mb-3">
              <span className="text-white text-2xl">🎯</span>
            </div>
            <p className="text-2xl font-bold text-purple-600">{progressData.overall.completedMocks}/{progressData.overall.totalMocks}</p>
            <p className="text-xs text-slate-600 mt-1">Mock Interviews</p>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center mx-auto mb-3">
              <span className="text-white text-2xl">⏰</span>
            </div>
            <p className="text-2xl font-bold text-indigo-600">{progressData.overall.studyHours}h</p>
            <p className="text-xs text-slate-600 mt-1">Study Time</p>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center mx-auto mb-3">
              <span className="text-white text-2xl">⭐</span>
            </div>
            <p className="text-2xl font-bold text-green-600">{progressData.overall.avgScore}</p>
            <p className="text-xs text-slate-600 mt-1">Avg Score</p>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-500 rounded-xl flex items-center justify-center mx-auto mb-3">
              <span className="text-white text-2xl">🔥</span>
            </div>
            <p className="text-2xl font-bold text-orange-600">{progressData.overall.streak}</p>
            <p className="text-xs text-slate-600 mt-1">Day Streak</p>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-yellow-500 rounded-xl flex items-center justify-center mx-auto mb-3">
              <span className="text-white text-2xl">🏆</span>
            </div>
            <p className="text-2xl font-bold text-amber-600">{progressData.achievements.filter(a => a.unlocked).length}</p>
            <p className="text-xs text-slate-600 mt-1">Achievements</p>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-teal-500 to-cyan-500 rounded-xl flex items-center justify-center mx-auto mb-3">
              <span className="text-white text-2xl">📈</span>
            </div>
            <p className="text-2xl font-bold text-teal-600">+12%</p>
            <p className="text-xs text-slate-600 mt-1">This Week</p>
          </div>
        </div>
      </div>

      {/* Category Progress */}
      <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100">
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Progress by Category</h2>
        <div className="space-y-6">
          {progressData.categories.map((category, index) => (
            <div key={index}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <h3 className="font-semibold text-slate-800">{category.name}</h3>
                  <span className="text-sm text-slate-600">
                    {category.resources} resources completed
                  </span>
                </div>
                <div className="flex items-center space-x-4">
                  <span className="text-sm font-semibold text-slate-600">
                    Score: {category.score}
                  </span>
                  <span className="text-lg font-bold text-indigo-600">
                    {category.progress}%
                  </span>
                </div>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-3">
                <div
                  className={`h-full rounded-full bg-gradient-to-r ${getProgressColor(category.progress)} transition-all duration-500`}
                  style={{ width: `${category.progress}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Weekly Progress Chart */}
      <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100">
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Weekly Activity</h2>
        <div className="grid grid-cols-7 gap-4">
          {progressData.weeklyProgress.map((day, index) => (
            <div key={index} className="text-center">
              <div className="mb-2">
                <div
                  className="w-full bg-gradient-to-t from-indigo-600 to-purple-600 rounded-lg mx-auto transition-all duration-300 hover:scale-105"
                  style={{ height: `${day.hours * 20}px`, minHeight: '40px' }}
                ></div>
              </div>
              <p className="text-xs font-semibold text-slate-800 mb-1">{day.day}</p>
              <p className="text-xs text-slate-600">{day.hours}h</p>
              <p className="text-xs text-indigo-600 font-semibold">{day.score}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100">
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Recent Activity</h2>
        <div className="space-y-4">
          {progressData.recentActivity.map((activity) => (
            <div
              key={activity.id}
              className="flex items-center justify-between p-4 bg-slate-50 rounded-xl hover:bg-slate-100 transition-colors"
            >
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
                  <span className="text-2xl">{activity.icon}</span>
                </div>
                <div>
                  <h3 className="font-semibold text-slate-800">{activity.title}</h3>
                  <p className="text-sm text-slate-600">{activity.action} • {activity.date}</p>
                </div>
              </div>
              {activity.score > 0 && (
                <div className="text-right">
                  <p className="text-2xl font-bold text-indigo-600">{activity.score}</p>
                  <p className="text-xs text-slate-600">Score</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Achievements */}
      <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100">
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Achievements</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {progressData.achievements.map((achievement) => (
            <div
              key={achievement.id}
              className={`text-center p-6 rounded-xl border-2 transition-all duration-300 ${
                achievement.unlocked
                  ? 'bg-gradient-to-br from-indigo-50 to-purple-50 border-indigo-200 hover:scale-105'
                  : 'bg-slate-50 border-slate-200 opacity-50'
              }`}
            >
              <div className="text-4xl mb-3">{achievement.icon}</div>
              <p className="text-sm font-semibold text-slate-800">{achievement.title}</p>
              {achievement.unlocked && (
                <p className="text-xs text-green-600 mt-2">✓ Unlocked</p>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
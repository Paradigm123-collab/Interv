export default function PrepRecommendations() {
  const recommendations = {
    personalized: [
      {
        id: 1,
        title: 'Advanced React Patterns',
        reason: 'Based on your upcoming interview with TechCorp Solutions',
        priority: 'High',
        type: 'Resource',
        estimatedTime: '2 hours',
        thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400&h=225&fit=crop',
        matchScore: 95
      },
      {
        id: 2,
        title: 'System Design Practice',
        reason: 'Improve your weakest category (40% completion)',
        priority: 'High',
        type: 'Mock Interview',
        estimatedTime: '1 hour',
        thumbnail: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=400&h=225&fit=crop',
        matchScore: 92
      },
      {
        id: 3,
        title: 'Leadership Scenarios',
        reason: 'Strengthen your behavioral interview skills',
        priority: 'Medium',
        type: 'Resource',
        estimatedTime: '45 min',
        thumbnail: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=225&fit=crop',
        matchScore: 88
      },
      {
        id: 4,
        title: 'JavaScript Performance Optimization',
        reason: 'Trending topic in your target companies',
        priority: 'Medium',
        type: 'Resource',
        estimatedTime: '1.5 hours',
        thumbnail: 'https://images.unsplash.com/photo-1587620962725-abab7fe55159?w=400&h=225&fit=crop',
        matchScore: 85
      }
    ],
    trending: [
      {
        id: 1,
        title: 'AI & Machine Learning Basics',
        popularity: 95,
        users: 1250,
        thumbnail: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=400&h=225&fit=crop'
      },
      {
        id: 2,
        title: 'Remote Work Best Practices',
        popularity: 88,
        users: 980,
        thumbnail: 'https://images.unsplash.com/photo-1588196749597-9ff075ee6b5b?w=400&h=225&fit=crop'
      },
      {
        id: 3,
        title: 'Cloud Architecture Fundamentals',
        popularity: 85,
        users: 875,
        thumbnail: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400&h=225&fit=crop'
      },
      {
        id: 4,
        title: 'Agile & Scrum Methodology',
        popularity: 82,
        users: 750,
        thumbnail: 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=400&h=225&fit=crop'
      }
    ],
    skillGaps: [
      {
        skill: 'System Design',
        currentLevel: 40,
        targetLevel: 80,
        recommendedResources: 3,
        estimatedTime: '8 hours'
      },
      {
        skill: 'Coding Challenges',
        currentLevel: 60,
        targetLevel: 85,
        recommendedResources: 4,
        estimatedTime: '6 hours'
      },
      {
        skill: 'Product Strategy',
        currentLevel: 50,
        targetLevel: 75,
        recommendedResources: 2,
        estimatedTime: '4 hours'
      }
    ]
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'High':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'Medium':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Low':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* AI Insights Banner */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl p-8 text-white shadow-lg">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-3 mb-4">
              <span className="text-4xl">🤖</span>
              <h2 className="text-2xl font-bold">AI-Powered Recommendations</h2>
            </div>
            <p className="text-white/90 mb-6 max-w-2xl">
              Based on your interview history, application status, and performance data, we've curated personalized learning paths to maximize your success rate.
            </p>
            <div className="flex items-center space-x-6">
              <div>
                <p className="text-3xl font-bold">95%</p>
                <p className="text-sm text-white/80">Match Score</p>
              </div>
              <div>
                <p className="text-3xl font-bold">12</p>
                <p className="text-sm text-white/80">Recommendations</p>
              </div>
              <div>
                <p className="text-3xl font-bold">8h</p>
                <p className="text-sm text-white/80">Est. Time</p>
              </div>
            </div>
          </div>
          <button className="px-6 py-3 bg-white text-indigo-600 rounded-lg hover:bg-white/90 transition-colors font-medium">
            Refresh Insights
          </button>
        </div>
      </div>

      {/* Personalized Recommendations */}
      <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100">
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Personalized for You</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {recommendations.personalized.map((rec) => (
            <div
              key={rec.id}
              className="bg-slate-50 rounded-xl p-6 border border-slate-200 hover:border-indigo-300 transition-all duration-300 hover:shadow-lg group"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <span className={`px-3 py-1 rounded-lg text-xs font-medium border ${getPriorityColor(rec.priority)}`}>
                      {rec.priority} Priority
                    </span>
                    <span className="px-3 py-1 bg-indigo-100 text-indigo-800 rounded-lg text-xs font-medium">
                      {rec.type}
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-slate-800 mb-2 group-hover:text-indigo-600 transition-colors">
                    {rec.title}
                  </h3>
                  <p className="text-sm text-slate-600 mb-3">{rec.reason}</p>
                  <div className="flex items-center space-x-4 text-sm text-slate-600">
                    <span className="flex items-center">
                      <span className="mr-1">⏱️</span>
                      {rec.estimatedTime}
                    </span>
                    <span className="flex items-center">
                      <span className="mr-1">🎯</span>
                      {rec.matchScore}% match
                    </span>
                  </div>
                </div>
                <img
                  src={rec.thumbnail}
                  alt={rec.title}
                  className="w-24 h-24 rounded-lg object-cover ml-4"
                />
              </div>
              <button className="w-full px-4 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 font-medium">
                Start Learning
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Skill Gap Analysis */}
      <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100">
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Skill Gap Analysis</h2>
        <div className="space-y-6">
          {recommendations.skillGaps.map((gap, index) => (
            <div key={index} className="bg-slate-50 rounded-xl p-6 border border-slate-200">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-bold text-slate-800 mb-1">{gap.skill}</h3>
                  <p className="text-sm text-slate-600">
                    {gap.recommendedResources} resources • {gap.estimatedTime} to target
                  </p>
                </div>
                <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-medium">
                  View Plan
                </button>
              </div>
              <div className="relative">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-slate-600">Current: {gap.currentLevel}%</span>
                  <span className="text-sm font-semibold text-indigo-600">Target: {gap.targetLevel}%</span>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-3">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-orange-500 rounded-full transition-all duration-500"
                    style={{ width: `${gap.currentLevel}%` }}
                  ></div>
                </div>
                <div
                  className="absolute top-8 h-3 w-1 bg-indigo-600"
                  style={{ left: `${gap.targetLevel}%` }}
                >
                  <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-3 h-3 bg-indigo-600 rounded-full"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Trending Resources */}
      <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100">
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Trending in Your Industry</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {recommendations.trending.map((trend) => (
            <div
              key={trend.id}
              className="bg-slate-50 rounded-xl overflow-hidden border border-slate-200 hover:border-indigo-300 transition-all duration-300 hover:shadow-lg group"
            >
              <div className="relative aspect-video overflow-hidden">
                <img
                  src={trend.thumbnail}
                  alt={trend.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-3 right-3 px-3 py-1 bg-red-500 text-white rounded-lg text-xs font-bold">
                  🔥 Trending
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-bold text-slate-800 mb-2 line-clamp-2 group-hover:text-indigo-600 transition-colors">
                  {trend.title}
                </h3>
                <div className="flex items-center justify-between text-sm text-slate-600">
                  <span>{trend.users} learners</span>
                  <span className="font-semibold text-indigo-600">{trend.popularity}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
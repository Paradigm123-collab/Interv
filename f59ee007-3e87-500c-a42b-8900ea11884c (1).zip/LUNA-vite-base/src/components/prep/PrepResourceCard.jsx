export default function PrepResourceCard({ resource }) {
  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Easy':
        return 'bg-green-100 text-green-800';
      case 'Intermediate':
        return 'bg-amber-100 text-amber-800';
      case 'Advanced':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'Guide':
        return '📖';
      case 'Video Course':
        return '🎥';
      case 'Interactive':
        return '🎮';
      case 'Practice':
        return '💪';
      default:
        return '📚';
    }
  };

  const handleStart = () => {
    alert(`Starting: ${resource.title}\n\nThis will open the interactive learning experience with:\n- ${resource.questions} practice questions\n- Real-time feedback\n- Progress tracking\n- Personalized tips\n\nFull functionality will be available with backend integration!`);
  };

  const handleBookmark = () => {
    alert(`${resource.bookmarked ? 'Removed from' : 'Added to'} bookmarks!\n\nBookmark management will be fully functional with backend integration.`);
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden hover:shadow-xl transition-all duration-300 group">
      {/* Thumbnail */}
      <div className="relative aspect-video overflow-hidden">
        <img
          src={resource.thumbnail}
          alt={resource.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-3 left-3 flex items-center space-x-2">
          <span className={`px-3 py-1 rounded-lg text-xs font-medium ${getDifficultyColor(resource.difficulty)}`}>
            {resource.difficulty}
          </span>
          <span className="px-3 py-1 bg-black/70 backdrop-blur-sm text-white rounded-lg text-xs font-medium">
            {getTypeIcon(resource.type)} {resource.type}
          </span>
        </div>
        <button
          onClick={handleBookmark}
          className="absolute top-3 right-3 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white transition-colors"
        >
          <span className="text-xl">{resource.bookmarked ? '⭐' : '☆'}</span>
        </button>
        {resource.completionRate > 0 && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-slate-200">
            <div
              className="h-full bg-gradient-to-r from-green-500 to-emerald-500"
              style={{ width: `${resource.completionRate}%` }}
            ></div>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-6">
        <div className="flex items-center space-x-2 mb-3">
          <span className="px-2 py-1 bg-indigo-100 text-indigo-800 rounded text-xs font-medium">
            {resource.category}
          </span>
          <span className="px-2 py-1 bg-purple-100 text-purple-800 rounded text-xs font-medium">
            {resource.role}
          </span>
        </div>

        <h3 className="text-lg font-bold text-slate-800 mb-2 line-clamp-2 group-hover:text-indigo-600 transition-colors">
          {resource.title}
        </h3>

        <p className="text-sm text-slate-600 mb-4 line-clamp-2">
          {resource.description}
        </p>

        {/* Topics */}
        <div className="flex flex-wrap gap-2 mb-4">
          {resource.topics.slice(0, 3).map((topic, index) => (
            <span
              key={index}
              className="px-2 py-1 bg-slate-100 text-slate-700 rounded text-xs"
            >
              {topic}
            </span>
          ))}
          {resource.topics.length > 3 && (
            <span className="px-2 py-1 bg-slate-100 text-slate-700 rounded text-xs">
              +{resource.topics.length - 3}
            </span>
          )}
        </div>

        {/* Meta Info */}
        <div className="flex items-center justify-between text-sm text-slate-600 mb-4">
          <span className="flex items-center">
            <span className="mr-1">⏱️</span>
            {resource.duration}
          </span>
          <span className="flex items-center">
            <span className="mr-1">❓</span>
            {resource.questions} questions
          </span>
        </div>

        {/* Progress */}
        {resource.completionRate > 0 && (
          <div className="mb-4">
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-slate-600">Progress</span>
              <span className="font-semibold text-indigo-600">{resource.completionRate}%</span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-2">
              <div
                className="h-full bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full transition-all duration-500"
                style={{ width: `${resource.completionRate}%` }}
              ></div>
            </div>
          </div>
        )}

        {/* Action Button */}
        <button
          onClick={handleStart}
          className="w-full px-4 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 font-medium flex items-center justify-center space-x-2"
        >
          <span>{resource.completionRate > 0 ? '▶️ Continue' : '🚀 Start Learning'}</span>
        </button>
      </div>
    </div>
  );
}
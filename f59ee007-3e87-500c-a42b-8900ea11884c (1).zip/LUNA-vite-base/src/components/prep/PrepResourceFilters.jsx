export default function PrepResourceFilters({ filters, onFilterChange }) {
  const categories = ['All Categories', 'Technical', 'Behavioral', 'Coding', 'System Design', 'Product', 'Design'];
  const industries = ['All Industries', 'Technology', 'Finance', 'Healthcare', 'Retail', 'Manufacturing'];
  const roles = ['All Roles', 'Frontend Developer', 'Backend Developer', 'Full Stack Developer', 'Software Engineer', 'Data Scientist', 'Product Manager', 'UI/UX Designer', 'Manager'];
  const levels = ['All Levels', 'Easy', 'Intermediate', 'Advanced'];

  const handleFilterChange = (key, value) => {
    const normalizedValue = value.startsWith('All ') ? 'all' : value;
    onFilterChange({ ...filters, [key]: normalizedValue });
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-slate-100 p-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="lg:col-span-2">
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Search Resources
          </label>
          <div className="relative">
            <input
              type="text"
              value={filters.search}
              onChange={(e) => handleFilterChange('search', e.target.value)}
              placeholder="Search by title, topic, or keyword..."
              className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400">
              🔍
            </span>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Category
          </label>
          <select
            value={filters.category === 'all' ? 'All Categories' : filters.category}
            onChange={(e) => handleFilterChange('category', e.target.value)}
            className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          >
            {categories.map((category) => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Role
          </label>
          <select
            value={filters.role === 'all' ? 'All Roles' : filters.role}
            onChange={(e) => handleFilterChange('role', e.target.value)}
            className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          >
            {roles.map((role) => (
              <option key={role} value={role}>
                {role}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Difficulty
          </label>
          <select
            value={filters.level === 'all' ? 'All Levels' : filters.level}
            onChange={(e) => handleFilterChange('level', e.target.value)}
            className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          >
            {levels.map((level) => (
              <option key={level} value={level}>
                {level}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="mt-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => onFilterChange({
              search: '',
              category: 'all',
              industry: 'all',
              role: 'all',
              level: 'all'
            })}
            className="px-4 py-2 text-slate-600 hover:text-slate-800 font-medium text-sm flex items-center space-x-2"
          >
            <span>🔄</span>
            <span>Reset Filters</span>
          </button>
        </div>
        <div className="flex items-center space-x-2">
          <button className="px-4 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors text-sm font-medium">
            📥 Import Resources
          </button>
          <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm font-medium">
            ⭐ View Bookmarks
          </button>
        </div>
      </div>
    </div>
  );
}
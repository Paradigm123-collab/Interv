import { useState } from 'react';
import PrepResourceCard from './PrepResourceCard';
import PrepResourceFilters from './PrepResourceFilters';

export default function PrepResourceLibrary() {
  const [filters, setFilters] = useState({
    search: '',
    category: 'all',
    industry: 'all',
    role: 'all',
    level: 'all'
  });

  const resources = [
    {
      id: 1,
      title: 'React Interview Questions & Answers',
      category: 'Technical',
      industry: 'Technology',
      role: 'Frontend Developer',
      level: 'Intermediate',
      type: 'Guide',
      duration: '45 min read',
      questions: 50,
      thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400&h=225&fit=crop',
      description: 'Comprehensive guide covering React fundamentals, hooks, state management, and advanced patterns.',
      topics: ['React Hooks', 'State Management', 'Component Lifecycle', 'Performance'],
      difficulty: 'Intermediate',
      completionRate: 0,
      bookmarked: false
    },
    {
      id: 2,
      title: 'Behavioral Interview Mastery',
      category: 'Behavioral',
      industry: 'All Industries',
      role: 'All Roles',
      level: 'All Levels',
      type: 'Video Course',
      duration: '2 hours',
      questions: 30,
      thumbnail: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=225&fit=crop',
      description: 'Learn the STAR method and master common behavioral interview questions with real examples.',
      topics: ['STAR Method', 'Leadership', 'Conflict Resolution', 'Teamwork'],
      difficulty: 'Easy',
      completionRate: 65,
      bookmarked: true
    },
    {
      id: 3,
      title: 'System Design Interview Prep',
      category: 'System Design',
      industry: 'Technology',
      role: 'Software Engineer',
      level: 'Advanced',
      type: 'Interactive',
      duration: '3 hours',
      questions: 20,
      thumbnail: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=400&h=225&fit=crop',
      description: 'Master system design interviews with real-world scenarios and scalability patterns.',
      topics: ['Scalability', 'Database Design', 'Microservices', 'Load Balancing'],
      difficulty: 'Advanced',
      completionRate: 30,
      bookmarked: true
    },
    {
      id: 4,
      title: 'JavaScript Coding Challenges',
      category: 'Coding',
      industry: 'Technology',
      role: 'Full Stack Developer',
      level: 'Intermediate',
      type: 'Practice',
      duration: '1 hour',
      questions: 75,
      thumbnail: 'https://images.unsplash.com/photo-1587620962725-abab7fe55159?w=400&h=225&fit=crop',
      description: 'Practice common JavaScript coding problems with detailed solutions and explanations.',
      topics: ['Algorithms', 'Data Structures', 'Problem Solving', 'ES6+'],
      difficulty: 'Intermediate',
      completionRate: 45,
      bookmarked: false
    },
    {
      id: 5,
      title: 'Product Manager Interview Guide',
      category: 'Product',
      industry: 'Technology',
      role: 'Product Manager',
      level: 'Intermediate',
      type: 'Guide',
      duration: '1.5 hours',
      questions: 40,
      thumbnail: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=225&fit=crop',
      description: 'Complete guide to PM interviews covering product sense, metrics, and strategy questions.',
      topics: ['Product Strategy', 'Metrics', 'User Research', 'Prioritization'],
      difficulty: 'Intermediate',
      completionRate: 0,
      bookmarked: false
    },
    {
      id: 6,
      title: 'Data Science Interview Prep',
      category: 'Technical',
      industry: 'Technology',
      role: 'Data Scientist',
      level: 'Advanced',
      type: 'Video Course',
      duration: '4 hours',
      questions: 60,
      thumbnail: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=225&fit=crop',
      description: 'Master statistics, machine learning, and SQL questions for data science roles.',
      topics: ['Statistics', 'Machine Learning', 'SQL', 'Python'],
      difficulty: 'Advanced',
      completionRate: 20,
      bookmarked: true
    },
    {
      id: 7,
      title: 'UI/UX Design Interview Tips',
      category: 'Design',
      industry: 'Technology',
      role: 'UI/UX Designer',
      level: 'Intermediate',
      type: 'Guide',
      duration: '1 hour',
      questions: 35,
      thumbnail: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=400&h=225&fit=crop',
      description: 'Portfolio presentation, design thinking, and common UX interview questions.',
      topics: ['Design Thinking', 'Portfolio', 'User Research', 'Prototyping'],
      difficulty: 'Intermediate',
      completionRate: 80,
      bookmarked: false
    },
    {
      id: 8,
      title: 'Leadership & Management Questions',
      category: 'Behavioral',
      industry: 'All Industries',
      role: 'Manager',
      level: 'Advanced',
      type: 'Interactive',
      duration: '2 hours',
      questions: 45,
      thumbnail: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=400&h=225&fit=crop',
      description: 'Prepare for leadership roles with management scenarios and team-building questions.',
      topics: ['Team Management', 'Decision Making', 'Conflict Resolution', 'Strategy'],
      difficulty: 'Advanced',
      completionRate: 0,
      bookmarked: false
    }
  ];

  const filteredResources = resources.filter(resource => {
    const matchesSearch = 
      resource.title.toLowerCase().includes(filters.search.toLowerCase()) ||
      resource.description.toLowerCase().includes(filters.search.toLowerCase()) ||
      resource.topics.some(topic => topic.toLowerCase().includes(filters.search.toLowerCase()));
    
    const matchesCategory = filters.category === 'all' || resource.category === filters.category;
    const matchesIndustry = filters.industry === 'all' || resource.industry === filters.industry;
    const matchesRole = filters.role === 'all' || resource.role === filters.role;
    const matchesLevel = filters.level === 'all' || resource.level === filters.level;
    
    return matchesSearch && matchesCategory && matchesIndustry && matchesRole && matchesLevel;
  });

  const stats = {
    total: resources.length,
    inProgress: resources.filter(r => r.completionRate > 0 && r.completionRate < 100).length,
    completed: resources.filter(r => r.completionRate === 100).length,
    bookmarked: resources.filter(r => r.bookmarked).length
  };

  return (
    <div className="space-y-6">
      {/* Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Total Resources</p>
              <p className="text-3xl font-bold text-blue-600">{stats.total}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">📚</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">In Progress</p>
              <p className="text-3xl font-bold text-amber-600">{stats.inProgress}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-yellow-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">⏳</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Completed</p>
              <p className="text-3xl font-bold text-green-600">{stats.completed}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">✅</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Bookmarked</p>
              <p className="text-3xl font-bold text-purple-600">{stats.bookmarked}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">⭐</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <PrepResourceFilters filters={filters} onFilterChange={setFilters} />

      {/* Resources Grid */}
      {filteredResources.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredResources.map(resource => (
            <PrepResourceCard key={resource.id} resource={resource} />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl p-12 text-center shadow-lg border border-slate-100">
          <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-4xl">🔍</span>
          </div>
          <h3 className="text-xl font-semibold text-slate-800 mb-2">No resources found</h3>
          <p className="text-slate-600">Try adjusting your filters to find what you're looking for</p>
        </div>
      )}
    </div>
  );
}
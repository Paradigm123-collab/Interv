import { useState, useEffect } from 'react';

export default function ProctoringDashboard({ onViewSession, onViewAlert }) {
  const [activeMonitoring, setActiveMonitoring] = useState(true);
  const [liveStats, setLiveStats] = useState({
    activeSessions: 12,
    flaggedBehaviors: 3,
    averageIntegrity: 94,
    totalMonitored: 156
  });

  useEffect(() => {
    if (activeMonitoring) {
      const interval = setInterval(() => {
        setLiveStats(prev => ({
          ...prev,
          activeSessions: Math.max(0, prev.activeSessions + Math.floor(Math.random() * 3) - 1),
          flaggedBehaviors: Math.max(0, prev.flaggedBehaviors + Math.floor(Math.random() * 2) - 1),
          averageIntegrity: Math.min(100, Math.max(85, prev.averageIntegrity + (Math.random() - 0.5) * 2))
        }));
      }, 5000);

      return () => clearInterval(interval);
    }
  }, [activeMonitoring]);

  const activeSessions = [
    {
      id: 1,
      candidateName: 'Sarah Mitchell',
      candidateAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      position: 'Senior React Developer',
      company: 'TechCorp Solutions',
      startTime: '14:00',
      duration: '23:45',
      integrityScore: 96,
      status: 'Active',
      alerts: [],
      metrics: {
        faceDetection: 98,
        gazeTracking: 95,
        voiceAnalysis: 94,
        environmentCheck: 97
      },
      color: 'from-green-500 to-emerald-500'
    },
    {
      id: 2,
      candidateName: 'Michael Chen',
      candidateAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      position: 'Full Stack Engineer',
      company: 'Innovation Labs',
      startTime: '14:30',
      duration: '15:20',
      integrityScore: 88,
      status: 'Warning',
      alerts: ['Multiple face detection', 'Background noise'],
      metrics: {
        faceDetection: 82,
        gazeTracking: 90,
        voiceAnalysis: 85,
        environmentCheck: 95
      },
      color: 'from-amber-500 to-orange-500'
    },
    {
      id: 3,
      candidateName: 'Emily Rodriguez',
      candidateAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
      position: 'Frontend Developer',
      company: 'Digital Dynamics',
      startTime: '15:00',
      duration: '08:12',
      integrityScore: 92,
      status: 'Active',
      alerts: [],
      metrics: {
        faceDetection: 94,
        gazeTracking: 91,
        voiceAnalysis: 90,
        environmentCheck: 93
      },
      color: 'from-blue-500 to-cyan-500'
    },
    {
      id: 4,
      candidateName: 'David Park',
      candidateAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
      position: 'UI/UX Designer',
      company: 'Creative Studios',
      startTime: '15:30',
      duration: '05:45',
      integrityScore: 78,
      status: 'Critical',
      alerts: ['Gaze shifted away', 'Unauthorized device detected', 'Multiple faces'],
      metrics: {
        faceDetection: 75,
        gazeTracking: 70,
        voiceAnalysis: 88,
        environmentCheck: 80
      },
      color: 'from-red-500 to-pink-500'
    }
  ];

  const recentAlerts = [
    {
      id: 1,
      type: 'Face Detection',
      severity: 'high',
      candidateName: 'David Park',
      message: 'Multiple faces detected in frame',
      timestamp: '2 minutes ago',
      sessionId: 4
    },
    {
      id: 2,
      type: 'Gaze Tracking',
      severity: 'medium',
      candidateName: 'Michael Chen',
      message: 'Candidate looking away from screen frequently',
      timestamp: '5 minutes ago',
      sessionId: 2
    },
    {
      id: 3,
      type: 'Environment',
      severity: 'low',
      candidateName: 'Sarah Mitchell',
      message: 'Background noise detected',
      timestamp: '8 minutes ago',
      sessionId: 1
    },
    {
      id: 4,
      type: 'Device',
      severity: 'high',
      candidateName: 'David Park',
      message: 'Unauthorized device detected in vicinity',
      timestamp: '10 minutes ago',
      sessionId: 4
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'Active':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Warning':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Critical':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'high':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'medium':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'low':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 80) return 'text-blue-600';
    if (score >= 70) return 'text-amber-600';
    return 'text-red-600';
  };

  return (
    <div className="space-y-6">
      {/* Live Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Active Sessions</p>
              <p className="text-3xl font-bold text-blue-600">{liveStats.activeSessions}</p>
              <div className="flex items-center mt-2">
                <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-2"></span>
                <span className="text-xs text-green-600 font-medium">Live Monitoring</span>
              </div>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">🎥</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Flagged Behaviors</p>
              <p className="text-3xl font-bold text-amber-600">{liveStats.flaggedBehaviors}</p>
              <p className="text-xs text-slate-500 mt-2">Requires attention</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-orange-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">⚠️</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div>
            <p className="text-sm text-slate-600 mb-1">Avg Integrity Score</p>
            <p className={`text-3xl font-bold ${getScoreColor(liveStats.averageIntegrity)}`}>
              {Math.round(liveStats.averageIntegrity)}%
            </p>
            <p className="text-xs text-green-600 font-medium mt-2">+2% from yesterday</p>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Total Monitored</p>
              <p className="text-3xl font-bold text-indigo-600">{liveStats.totalMonitored}</p>
              <p className="text-xs text-slate-500 mt-2">Today</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">📊</span>
            </div>
          </div>
        </div>
      </div>

      {/* Monitoring Controls */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-slate-800 mb-1">AI Proctoring System</h3>
            <p className="text-sm text-slate-600">Real-time monitoring and integrity analysis</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-slate-600">Auto-Monitor:</span>
              <button
                onClick={() => setActiveMonitoring(!activeMonitoring)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  activeMonitoring ? 'bg-green-600' : 'bg-slate-300'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    activeMonitoring ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
            <button
              onClick={() => alert('Proctoring settings will be available with backend integration!')}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-medium"
            >
              ⚙️ Settings
            </button>
          </div>
        </div>
      </div>

      {/* Active Sessions */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-slate-800">Active Monitoring Sessions</h2>
          <button
            onClick={() => alert('View all sessions history')}
            className="text-indigo-600 hover:text-indigo-700 font-medium text-sm hover:scale-105 active:scale-95 transition-transform"
          >
            View All →
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {activeSessions.map((session) => (
            <div
              key={session.id}
              onClick={() => onViewSession(session)}
              className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100 hover:shadow-xl transition-all duration-300 cursor-pointer group hover:scale-105 active:scale-95"
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <img
                    src={session.candidateAvatar}
                    alt={session.candidateName}
                    className="w-14 h-14 rounded-full border-2 border-indigo-200 group-hover:scale-110 transition-transform"
                  />
                  <div>
                    <h3 className="font-bold text-slate-800 group-hover:text-indigo-600 transition-colors">
                      {session.candidateName}
                    </h3>
                    <p className="text-sm text-slate-600">{session.position}</p>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(session.status)}`}>
                  {session.status}
                </span>
              </div>

              {/* Company & Time */}
              <div className="space-y-2 mb-4">
                <div className="flex items-center text-sm text-slate-600">
                  <span className="mr-2">🏢</span>
                  <span>{session.company}</span>
                </div>
                <div className="flex items-center text-sm text-slate-600">
                  <span className="mr-2">⏱️</span>
                  <span>Started at {session.startTime} • Duration: {session.duration}</span>
                </div>
              </div>

              {/* Integrity Score */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-slate-700">Integrity Score</span>
                  <span className={`text-lg font-bold ${getScoreColor(session.integrityScore)}`}>
                    {session.integrityScore}%
                  </span>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full bg-gradient-to-r ${session.color} transition-all duration-500`}
                    style={{ width: `${session.integrityScore}%` }}
                  ></div>
                </div>
              </div>

              {/* Metrics */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                {Object.entries(session.metrics).map(([key, value]) => (
                  <div key={key} className="bg-slate-50 rounded-lg p-2">
                    <p className="text-xs text-slate-600 mb-1 capitalize">
                      {key.replace(/([A-Z])/g, ' $1').trim()}
                    </p>
                    <p className={`text-sm font-bold ${getScoreColor(value)}`}>{value}%</p>
                  </div>
                ))}
              </div>

              {/* Alerts */}
              {session.alerts.length > 0 && (
                <div className="bg-red-50 rounded-lg p-3 border border-red-100">
                  <p className="text-xs font-semibold text-red-800 mb-2">⚠️ Active Alerts</p>
                  <ul className="space-y-1">
                    {session.alerts.map((alert, index) => (
                      <li key={index} className="text-xs text-red-700">• {alert}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* View Details */}
              <div className="mt-4 text-center">
                <span className="text-indigo-600 text-sm font-medium group-hover:translate-x-1 transition-transform inline-block">
                  View Live Session →
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Alerts */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-slate-800">Recent Alerts</h2>
          <button
            onClick={() => alert('View all alerts history')}
            className="text-indigo-600 hover:text-indigo-700 font-medium text-sm hover:scale-105 active:scale-95 transition-transform"
          >
            View All →
          </button>
        </div>
        <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
          {recentAlerts.map((alert, index) => (
            <div
              key={alert.id}
              onClick={() => onViewAlert(alert)}
              className={`p-6 hover:bg-slate-50 transition-colors cursor-pointer ${
                index !== recentAlerts.length - 1 ? 'border-b border-slate-100' : ''
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <span className={`px-3 py-1 rounded-lg text-xs font-medium border ${getSeverityColor(alert.severity)}`}>
                      {alert.severity.toUpperCase()}
                    </span>
                    <span className="text-xs text-slate-500">{alert.type}</span>
                  </div>
                  <h3 className="font-semibold text-slate-800 mb-1">{alert.candidateName}</h3>
                  <p className="text-sm text-slate-700 mb-2">{alert.message}</p>
                  <p className="text-xs text-slate-500">{alert.timestamp}</p>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onViewSession(activeSessions.find(s => s.id === alert.sessionId));
                  }}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm font-medium"
                >
                  View Session
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
import { useState, useEffect } from 'react';

export default function ProctoringSessionView({ session, onBack }) {
  const [liveMetrics, setLiveMetrics] = useState(session.metrics);
  const [timeline, setTimeline] = useState([]);

  useEffect(() => {
    const interval = setInterval(() => {
      setLiveMetrics(prev => ({
        faceDetection: Math.max(70, Math.min(100, prev.faceDetection + (Math.random() - 0.5) * 5)),
        gazeTracking: Math.max(70, Math.min(100, prev.gazeTracking + (Math.random() - 0.5) * 8)),
        voiceAnalysis: Math.max(70, Math.min(100, prev.voiceAnalysis + (Math.random() - 0.5) * 6)),
        environmentCheck: Math.max(70, Math.min(100, prev.environmentCheck + (Math.random() - 0.5) * 4))
      }));

      if (Math.random() > 0.7) {
        const events = [
          { type: 'info', message: 'Candidate maintained eye contact', icon: '✅' },
          { type: 'warning', message: 'Brief gaze shift detected', icon: '⚠️' },
          { type: 'success', message: 'Clear audio quality maintained', icon: '🎤' }
        ];
        const randomEvent = events[Math.floor(Math.random() * events.length)];
        setTimeline(prev => [...prev.slice(-9), {
          ...randomEvent,
          time: new Date().toLocaleTimeString()
        }]);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 80) return 'text-blue-600';
    if (score >= 70) return 'text-amber-600';
    return 'text-red-600';
  };

  const getEventColor = (type) => {
    switch (type) {
      case 'success':
        return 'bg-green-50 border-green-200 text-green-800';
      case 'warning':
        return 'bg-amber-50 border-amber-200 text-amber-800';
      case 'info':
        return 'bg-blue-50 border-blue-200 text-blue-800';
      default:
        return 'bg-slate-50 border-slate-200 text-slate-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
        <button
          onClick={onBack}
          className="text-indigo-600 hover:text-indigo-700 font-medium mb-4 flex items-center space-x-2"
        >
          <span>←</span>
          <span>Back to Dashboard</span>
        </button>

        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-4">
            <img
              src={session.candidateAvatar}
              alt={session.candidateName}
              className="w-20 h-20 rounded-full border-4 border-indigo-200"
            />
            <div>
              <h1 className="text-2xl font-bold text-slate-800 mb-1">{session.candidateName}</h1>
              <p className="text-lg text-slate-600 mb-2">{session.position}</p>
              <div className="flex items-center space-x-4 text-sm text-slate-600">
                <span className="flex items-center">
                  <span className="mr-1">🏢</span>
                  {session.company}
                </span>
                <span className="flex items-center">
                  <span className="mr-1">⏱️</span>
                  Duration: {session.duration}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <span className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></span>
            <span className="text-sm font-medium text-green-600">Live Monitoring</span>
          </div>
        </div>
      </div>

      {/* Live Video Feed */}
      <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
        <div className="relative aspect-video bg-slate-900">
          <img
            src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=1200&h=675&fit=crop"
            alt="Live feed"
            className="w-full h-full object-cover"
          />
          <div className="absolute top-4 left-4 bg-red-500 px-4 py-2 rounded-lg flex items-center space-x-2 animate-pulse">
            <span className="w-3 h-3 bg-white rounded-full"></span>
            <span className="text-white font-semibold text-sm">LIVE</span>
          </div>
          <div className="absolute bottom-4 left-4 bg-black/70 backdrop-blur-sm px-4 py-2 rounded-lg">
            <p className="text-white font-medium">{session.candidateName}</p>
            <p className="text-slate-300 text-sm">{session.position}</p>
          </div>
        </div>
      </div>

      {/* Real-time Metrics */}
      <div>
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Real-time Integrity Metrics</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {Object.entries(liveMetrics).map(([key, value]) => (
            <div key={key} className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-medium text-slate-700 capitalize">
                  {key.replace(/([A-Z])/g, ' $1').trim()}
                </h3>
                <span className={`text-2xl font-bold ${getScoreColor(value)}`}>
                  {Math.round(value)}%
                </span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-3">
                <div
                  className={`h-3 rounded-full transition-all duration-500 ${
                    value >= 90 ? 'bg-gradient-to-r from-green-500 to-emerald-500' :
                    value >= 80 ? 'bg-gradient-to-r from-blue-500 to-cyan-500' :
                    value >= 70 ? 'bg-gradient-to-r from-amber-500 to-yellow-500' :
                    'bg-gradient-to-r from-red-500 to-pink-500'
                  }`}
                  style={{ width: `${value}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Event Timeline */}
      <div>
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Event Timeline</h2>
        <div className="bg-white rounded-2xl shadow-lg border border-slate-100 p-6">
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {timeline.length > 0 ? (
              timeline.map((event, index) => (
                <div
                  key={index}
                  className={`p-3 rounded-lg border ${getEventColor(event.type)}`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span>{event.icon}</span>
                      <span className="text-sm font-medium">{event.message}</span>
                    </div>
                    <span className="text-xs opacity-70">{event.time}</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <p className="text-slate-600">Monitoring events will appear here...</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-end space-x-4">
        <button
          onClick={() => alert('Flag session for review')}
          className="px-6 py-3 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors font-medium"
        >
          🚩 Flag Session
        </button>
        <button
          onClick={() => alert('Generate integrity report')}
          className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-medium"
        >
          📊 Generate Report
        </button>
      </div>
    </div>
  );
}
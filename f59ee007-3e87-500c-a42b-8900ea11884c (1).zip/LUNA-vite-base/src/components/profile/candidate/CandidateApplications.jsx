import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function CandidateApplications() {
  const navigate = useNavigate();
  const [filterStatus, setFilterStatus] = useState('all');

  const applications = [
    {
      id: 1,
      company: 'TechCorp Solutions',
      position: 'Senior React Developer',
      appliedDate: '2024-12-20',
      status: 'Interview Scheduled',
      interviewDate: '2024-12-28',
      salary: '$120,000 - $160,000',
      location: 'San Francisco, CA',
      logo: 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=100&h=100&fit=crop'
    },
    {
      id: 2,
      company: 'Innovation Labs',
      position: 'Full Stack Engineer',
      appliedDate: '2024-12-18',
      status: 'Under Review',
      salary: '$110,000 - $150,000',
      location: 'Remote',
      logo: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=100&h=100&fit=crop'
    },
    {
      id: 3,
      company: 'Digital Dynamics',
      position: 'Frontend Developer',
      appliedDate: '2024-12-15',
      status: 'Application Viewed',
      salary: '$100,000 - $140,000',
      location: 'New York, NY',
      logo: 'https://images.unsplash.com/photo-1572044162444-ad60f128bdea?w=100&h=100&fit=crop'
    },
    {
      id: 4,
      company: 'StartupHub Inc',
      position: 'React Developer',
      appliedDate: '2024-12-12',
      status: 'Rejected',
      salary: '$90,000 - $130,000',
      location: 'Austin, TX',
      logo: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=100&h=100&fit=crop'
    },
    {
      id: 5,
      company: 'CloudTech Systems',
      position: 'Software Engineer',
      appliedDate: '2024-12-10',
      status: 'Offer Received',
      salary: '$130,000 - $170,000',
      location: 'Seattle, WA',
      logo: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=100&h=100&fit=crop'
    },
    {
      id: 6,
      company: 'WebFlow Agency',
      position: 'Frontend Developer',
      appliedDate: '2024-12-08',
      status: 'Application Submitted',
      salary: '$95,000 - $135,000',
      location: 'Los Angeles, CA',
      logo: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=100&h=100&fit=crop'
    },
    {
      id: 7,
      company: 'DataViz Corp',
      position: 'UI Developer',
      appliedDate: '2024-12-05',
      status: 'Interview Completed',
      salary: '$105,000 - $145,000',
      location: 'Boston, MA',
      logo: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=100&h=100&fit=crop'
    },
    {
      id: 8,
      company: 'MobileTech Solutions',
      position: 'React Native Developer',
      appliedDate: '2024-12-01',
      status: 'Withdrawn',
      salary: '$115,000 - $155,000',
      location: 'Chicago, IL',
      logo: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=100&h=100&fit=crop'
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'Interview Scheduled':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Under Review':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Application Viewed':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Offer Received':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Interview Completed':
        return 'bg-indigo-100 text-indigo-800 border-indigo-200';
      case 'Rejected':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'Withdrawn':
        return 'bg-slate-100 text-slate-800 border-slate-200';
      default:
        return 'bg-amber-100 text-amber-800 border-amber-200';
    }
  };

  const filteredApplications = filterStatus === 'all' 
    ? applications 
    : applications.filter(app => app.status === filterStatus);

  const stats = {
    total: applications.length,
    active: applications.filter(a => !['Rejected', 'Withdrawn'].includes(a.status)).length,
    interviews: applications.filter(a => a.status.includes('Interview')).length,
    offers: applications.filter(a => a.status === 'Offer Received').length
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-slate-100 p-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-slate-800">My Applications</h2>
        <button
          onClick={() => navigate('/jobs')}
          className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium flex items-center space-x-2 hover:scale-105 active:scale-95"
        >
          <span>🔍</span>
          <span>Browse Jobs</span>
        </button>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-4 border border-blue-100">
          <p className="text-sm text-slate-600 mb-1">Total Applications</p>
          <p className="text-3xl font-bold text-blue-600">{stats.total}</p>
        </div>
        <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-4 border border-green-100">
          <p className="text-sm text-slate-600 mb-1">Active</p>
          <p className="text-3xl font-bold text-green-600">{stats.active}</p>
        </div>
        <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-4 border border-purple-100">
          <p className="text-sm text-slate-600 mb-1">Interviews</p>
          <p className="text-3xl font-bold text-purple-600">{stats.interviews}</p>
        </div>
        <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-xl p-4 border border-amber-100">
          <p className="text-sm text-slate-600 mb-1">Offers</p>
          <p className="text-3xl font-bold text-amber-600">{stats.offers}</p>
        </div>
      </div>

      {/* Filter */}
      <div className="mb-6">
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
        >
          <option value="all">All Applications</option>
          <option value="Interview Scheduled">Interview Scheduled</option>
          <option value="Under Review">Under Review</option>
          <option value="Application Viewed">Application Viewed</option>
          <option value="Offer Received">Offer Received</option>
          <option value="Interview Completed">Interview Completed</option>
          <option value="Application Submitted">Application Submitted</option>
          <option value="Rejected">Rejected</option>
          <option value="Withdrawn">Withdrawn</option>
        </select>
      </div>

      {/* Applications List */}
      <div className="space-y-4">
        {filteredApplications.map((app) => (
          <div
            key={app.id}
            className="bg-slate-50 rounded-xl p-6 border border-slate-200 hover:border-indigo-200 transition-all duration-200 hover:shadow-md"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-4 flex-1">
                <img
                  src={app.logo}
                  alt={app.company}
                  className="w-16 h-16 rounded-xl object-cover border-2 border-slate-100"
                />
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-slate-800 mb-1">{app.position}</h3>
                  <p className="text-indigo-600 font-semibold mb-2">{app.company}</p>
                  <div className="flex flex-wrap gap-3 text-sm text-slate-600 mb-3">
                    <span className="flex items-center">
                      <span className="mr-1">📍</span>
                      {app.location}
                    </span>
                    <span className="flex items-center">
                      <span className="mr-1">💰</span>
                      {app.salary}
                    </span>
                    <span className="flex items-center">
                      <span className="mr-1">📅</span>
                      Applied: {app.appliedDate}
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className={`px-3 py-1 rounded-lg text-sm font-medium border ${getStatusColor(app.status)}`}>
                      {app.status}
                    </span>
                    {app.interviewDate && (
                      <span className="text-sm text-slate-600">
                        Interview: {app.interviewDate}
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <div className="flex flex-col space-y-2 ml-4">
                <button
                  onClick={() => alert(`View details for ${app.position} at ${app.company}`)}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm font-medium whitespace-nowrap"
                >
                  View Details
                </button>
                {app.status === 'Interview Scheduled' && (
                  <button
                    onClick={() => navigate('/scheduling')}
                    className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium whitespace-nowrap"
                  >
                    View Schedule
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
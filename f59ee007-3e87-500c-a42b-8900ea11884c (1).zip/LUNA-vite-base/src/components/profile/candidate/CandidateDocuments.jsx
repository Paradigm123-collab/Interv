import { useState } from 'react';

export default function CandidateDocuments() {
  const [documents, setDocuments] = useState([
    {
      id: 1,
      name: 'Resume_SarahMitchell_2024.pdf',
      type: 'Resume',
      size: '245 KB',
      uploadedAt: '2024-12-15',
      url: '#'
    },
    {
      id: 2,
      name: 'Portfolio_WebProjects.pdf',
      type: 'Portfolio',
      size: '1.2 MB',
      uploadedAt: '2024-12-10',
      url: '#'
    },
    {
      id: 3,
      name: 'CoverLetter_TechCorp.pdf',
      type: 'Cover Letter',
      size: '89 KB',
      uploadedAt: '2024-12-20',
      url: '#'
    },
    {
      id: 4,
      name: 'Certifications_AWS.pdf',
      type: 'Certificate',
      size: '156 KB',
      uploadedAt: '2024-11-28',
      url: '#'
    }
  ]);

  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    handleFileUpload(files);
  };

  const handleFileSelect = (e) => {
    const files = Array.from(e.target.files);
    handleFileUpload(files);
  };

  const handleFileUpload = (files) => {
    const message = document.createElement('div');
    message.className = 'fixed top-20 right-4 bg-indigo-600 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
    message.innerHTML = `
      <div class="flex items-center space-x-3">
        <div class="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
        <span>Uploading ${files.length} file(s)...</span>
      </div>
    `;
    document.body.appendChild(message);
    
    setTimeout(() => {
      message.remove();
      const successMessage = document.createElement('div');
      successMessage.className = 'fixed top-20 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
      successMessage.textContent = `Successfully uploaded ${files.length} file(s)!`;
      document.body.appendChild(successMessage);
      setTimeout(() => successMessage.remove(), 3000);
    }, 2000);
  };

  const handleDelete = (docId) => {
    if (confirm('Are you sure you want to delete this document?')) {
      setDocuments(documents.filter(doc => doc.id !== docId));
      const message = document.createElement('div');
      message.className = 'fixed top-20 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
      message.textContent = 'Document deleted successfully!';
      document.body.appendChild(message);
      setTimeout(() => message.remove(), 3000);
    }
  };

  const getDocumentIcon = (type) => {
    switch (type) {
      case 'Resume':
        return '📄';
      case 'Portfolio':
        return '🎨';
      case 'Cover Letter':
        return '✉️';
      case 'Certificate':
        return '🏆';
      default:
        return '📎';
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-slate-100 p-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-slate-800">Documents & Portfolio</h2>
        <label className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium cursor-pointer flex items-center space-x-2 hover:scale-105 active:scale-95">
          <span>📤</span>
          <span>Upload Document</span>
          <input
            type="file"
            multiple
            onChange={handleFileSelect}
            className="hidden"
            accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
          />
        </label>
      </div>

      {/* Upload Area */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`border-2 border-dashed rounded-xl p-12 text-center mb-8 transition-all duration-200 ${
          isDragging
            ? 'border-indigo-500 bg-indigo-50'
            : 'border-slate-200 hover:border-indigo-300 hover:bg-slate-50'
        }`}
      >
        <div className="w-16 h-16 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <span className="text-3xl">📁</span>
        </div>
        <h3 className="text-lg font-semibold text-slate-800 mb-2">
          Drag and drop files here
        </h3>
        <p className="text-slate-600 mb-4">
          or click the upload button above to browse
        </p>
        <p className="text-sm text-slate-500">
          Supported formats: PDF, DOC, DOCX, JPG, PNG (Max 10MB)
        </p>
      </div>

      {/* Documents List */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-slate-800 mb-4">Uploaded Documents</h3>
        {documents.map((doc) => (
          <div
            key={doc.id}
            className="flex items-center justify-between p-4 bg-slate-50 rounded-xl hover:bg-slate-100 transition-colors border border-slate-100"
          >
            <div className="flex items-center space-x-4 flex-1">
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center text-2xl border border-slate-200">
                {getDocumentIcon(doc.type)}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-semibold text-slate-800 truncate">{doc.name}</h4>
                <div className="flex items-center space-x-4 text-sm text-slate-500 mt-1">
                  <span className="px-2 py-0.5 bg-indigo-100 text-indigo-700 rounded text-xs font-medium">
                    {doc.type}
                  </span>
                  <span>{doc.size}</span>
                  <span>Uploaded: {doc.uploadedAt}</span>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-2 ml-4">
              <button
                onClick={() => window.open(doc.url, '_blank')}
                className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                title="View"
              >
                👁️
              </button>
              <button
                onClick={() => {
                  const link = document.createElement('a');
                  link.href = doc.url;
                  link.download = doc.name;
                  link.click();
                }}
                className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                title="Download"
              >
                ⬇️
              </button>
              <button
                onClick={() => handleDelete(doc.id)}
                className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                title="Delete"
              >
                🗑️
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Tips */}
      <div className="mt-8 p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-100">
        <h4 className="font-semibold text-slate-800 mb-3 flex items-center">
          <span className="mr-2">💡</span>
          Document Tips
        </h4>
        <ul className="space-y-2 text-sm text-slate-700">
          <li className="flex items-start">
            <span className="mr-2">•</span>
            <span>Keep your resume updated with your latest experience and skills</span>
          </li>
          <li className="flex items-start">
            <span className="mr-2">•</span>
            <span>Include a portfolio showcasing your best work and projects</span>
          </li>
          <li className="flex items-start">
            <span className="mr-2">•</span>
            <span>Customize cover letters for specific job applications</span>
          </li>
          <li className="flex items-start">
            <span className="mr-2">•</span>
            <span>Add relevant certifications to stand out to employers</span>
          </li>
        </ul>
      </div>
    </div>
  );
}
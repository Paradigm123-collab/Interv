import { useState } from 'react';

export default function CandidateEducation() {
  const [education, setEducation] = useState([
    {
      id: 1,
      school: 'Stanford University',
      degree: 'Master of Science',
      field: 'Computer Science',
      location: 'Stanford, CA',
      startDate: '2015-09',
      endDate: '2017-06',
      gpa: '3.9',
      achievements: [
        'Dean\'s List all semesters',
        'Research Assistant in AI Lab',
        'Published paper on machine learning algorithms'
      ]
    },
    {
      id: 2,
      school: 'University of California, Berkeley',
      degree: 'Bachelor of Science',
      field: 'Computer Engineering',
      location: 'Berkeley, CA',
      startDate: '2011-09',
      endDate: '2015-06',
      gpa: '3.8',
      achievements: [
        'Graduated with Honors',
        'President of Computer Science Club',
        'Won hackathon competition'
      ]
    }
  ]);

  const [certifications] = useState([
    {
      id: 1,
      name: 'AWS Certified Solutions Architect',
      issuer: 'Amazon Web Services',
      date: '2023-08',
      credentialId: 'AWS-SA-2023-12345',
      url: '#'
    },
    {
      id: 2,
      name: 'Professional Scrum Master I',
      issuer: 'Scrum.org',
      date: '2022-11',
      credentialId: 'PSM-2022-67890',
      url: '#'
    },
    {
      id: 3,
      name: 'React Advanced Certification',
      issuer: 'Meta',
      date: '2023-03',
      credentialId: 'META-REACT-2023-54321',
      url: '#'
    }
  ]);

  const [isAdding, setIsAdding] = useState(false);

  const handleSave = () => {
    setIsAdding(false);
    const message = document.createElement('div');
    message.className = 'fixed top-20 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
    message.textContent = 'Education saved successfully!';
    document.body.appendChild(message);
    setTimeout(() => message.remove(), 3000);
  };

  const formatDate = (dateString) => {
    const [year, month] = dateString.split('-');
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${months[parseInt(month) - 1]} ${year}`;
  };

  return (
    <div className="space-y-6">
      {/* Education Section */}
      <div className="bg-white rounded-2xl shadow-lg border border-slate-100 p-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-slate-800">Education</h2>
          <button
            onClick={() => setIsAdding(true)}
            className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium flex items-center space-x-2 hover:scale-105 active:scale-95"
          >
            <span>➕</span>
            <span>Add Education</span>
          </button>
        </div>

        {/* Add Form */}
        {isAdding && (
          <div className="mb-8 p-6 bg-slate-50 rounded-xl border border-slate-200">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">Add Education</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">School/University</label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="Institution name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Degree</label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g., Bachelor of Science"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Field of Study</label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g., Computer Science"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Location</label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="City, State"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Start Date</label>
                  <input
                    type="month"
                    className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">End Date</label>
                  <input
                    type="month"
                    className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">GPA (Optional)</label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g., 3.8"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-2">
                <button
                  onClick={() => setIsAdding(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors font-medium"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  className="px-6 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 font-medium"
                >
                  Save
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Education List */}
        <div className="space-y-6">
          {education.map((edu) => (
            <div key={edu.id} className="bg-slate-50 rounded-xl p-6 border border-slate-200">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-xl">🎓</span>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-slate-800">{edu.school}</h3>
                    <p className="text-indigo-600 font-semibold">{edu.degree} in {edu.field}</p>
                    <div className="flex items-center space-x-4 text-sm text-slate-500 mt-2">
                      <span className="flex items-center">
                        <span className="mr-1">📍</span>
                        {edu.location}
                      </span>
                      <span className="flex items-center">
                        <span className="mr-1">📅</span>
                        {formatDate(edu.startDate)} - {formatDate(edu.endDate)}
                      </span>
                      {edu.gpa && (
                        <span className="flex items-center">
                          <span className="mr-1">📊</span>
                          GPA: {edu.gpa}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <button className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors">
                    ✏️
                  </button>
                  <button className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                    🗑️
                  </button>
                </div>
              </div>

              {edu.achievements && edu.achievements.length > 0 && (
                <div className="mt-4">
                  <p className="text-sm font-semibold text-slate-700 mb-2">Achievements:</p>
                  <ul className="space-y-1">
                    {edu.achievements.map((achievement, idx) => (
                      <li key={idx} className="text-sm text-slate-600 flex items-start">
                        <span className="mr-2 text-green-600">✓</span>
                        <span>{achievement}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Certifications Section */}
      <div className="bg-white rounded-2xl shadow-lg border border-slate-100 p-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-slate-800">Certifications</h2>
          <button
            onClick={() => alert('Add certification functionality will be implemented!')}
            className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium flex items-center space-x-2 hover:scale-105 active:scale-95"
          >
            <span>➕</span>
            <span>Add Certification</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {certifications.map((cert) => (
            <div key={cert.id} className="bg-slate-50 rounded-xl p-6 border border-slate-200 hover:border-indigo-200 transition-colors">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-start space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-500 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-lg">🏆</span>
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800">{cert.name}</h3>
                    <p className="text-sm text-slate-600">{cert.issuer}</p>
                    <p className="text-xs text-slate-500 mt-1">Issued: {formatDate(cert.date)}</p>
                    <p className="text-xs text-slate-400 mt-1">ID: {cert.credentialId}</p>
                  </div>
                </div>
              </div>
              <a
                href={cert.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-indigo-600 hover:text-indigo-700 font-medium"
              >
                View Credential →
              </a>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function CandidateInterviewHistory() {
  const navigate = useNavigate();
  const [filterType, setFilterType] = useState('all');

  const interviews = [
    {
      id: 1,
      company: 'TechCorp Solutions',
      position: 'Senior React Developer',
      date: '2024-12-28',
      time: '14:00',
      type: 'AI',
      status: 'Scheduled',
      duration: '45 min',
      logo: 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=100&h=100&fit=crop'
    },
    {
      id: 2,
      company: 'Innovation Labs',
      position: 'Full Stack Engineer',
      date: '2024-12-30',
      time: '10:00',
      type: 'Human',
      interviewer: 'Dr. Sarah Johnson',
      status: 'Scheduled',
      duration: '60 min',
      logo: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=100&h=100&fit=crop'
    },
    {
      id: 3,
      company: 'StartupHub Inc',
      position: 'React Developer',
      date: '2024-12-20',
      time: '15:00',
      type: 'AI',
      status: 'Completed',
      duration: '45 min',
      score: 88,
      feedback: 'Excellent technical skills and communication. Strong problem-solving abilities demonstrated.',
      logo: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=100&h=100&fit=crop'
    },
    {
      id: 4,
      company: 'CloudTech Systems',
      position: 'Software Engineer',
      date: '2024-12-18',
      time: '11:00',
      type: 'Human',
      interviewer: 'Mark Wilson',
      status: 'Completed',
      duration: '60 min',
      score: 85,
      feedback: 'Good understanding of core concepts. Would benefit from more experience with cloud technologies.',
      logo: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=100&h=100&fit=crop'
    },
    {
      id: 5,
      company: 'WebFlow Agency',
      position: 'Frontend Developer',
      date: '2024-12-15',
      time: '16:30',
      type: 'AI',
      status: 'Completed',
      duration: '30 min',
      score: 82,
      feedback: 'Solid foundation in frontend development. Recommended to practice more complex state management scenarios.',
      logo: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=100&h=100&fit=crop'
    },
    {
      id: 6,
      company: 'DataViz Corp',
      position: 'UI Developer',
      date: '2024-12-12',
      time: '13:00',
      type: 'Human',
      interviewer: 'Emily Chen',
      status: 'Completed',
      duration: '45 min',
      score: 92,
      feedback: 'Outstanding presentation and design thinking. Impressive portfolio showcasing modern UI/UX principles.',
      logo: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=100&h=100&fit=crop'
    },
    {
      id: 7,
      company: 'MobileTech Solutions',
      position: 'React Native Developer',
      date: '2024-12-10',
      time: '09:30',
      type: 'AI',
      status: 'Completed',
      duration: '45 min',
      score: 87,
      feedback: 'Strong mobile development skills. Great understanding of cross-platform development challenges.',
      logo: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=100&h=100&fit=crop'
    },
    {
      id: 8,
      company: 'Digital Dynamics',
      position: 'Frontend Developer',
      date: '2025-01-02',
      time: '15:30',
      type: 'AI',
      status: 'Pending',
      duration: '30 min',
      logo: 'https://images.unsplash.com/photo-1572044162444-ad60f128bdea?w=100&h=100&fit=crop'
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'Scheduled':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Completed':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Pending':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Cancelled':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 80) return 'text-blue-600';
    if (score >= 70) return 'text-amber-600';
    return 'text-red-600';
  };

  const filteredInterviews = filterType === 'all'
    ? interviews
    : interviews.filter(interview => interview.type === filterType);

  const stats = {
    total: interviews.length,
    scheduled: interviews.filter(i => i.status === 'Scheduled').length,
    completed: interviews.filter(i => i.status === 'Completed').length,
    avgScore: Math.round(
      interviews.filter(i => i.score).reduce((sum, i) => sum + i.score, 0) /
      interviews.filter(i => i.score).length
    )
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-slate-100 p-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-slate-800">Interview History</h2>
        <button
          onClick={() => navigate('/scheduling')}
          className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium flex items-center space-x-2 hover:scale-105 active:scale-95"
        >
          <span>📅</span>
          <span>View Schedule</span>
        </button>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-4 border border-blue-100">
          <p className="text-sm text-slate-600 mb-1">Total Interviews</p>
          <p className="text-3xl font-bold text-blue-600">{stats.total}</p>
        </div>
        <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-4 border border-green-100">
          <p className="text-sm text-slate-600 mb-1">Scheduled</p>
          <p className="text-3xl font-bold text-green-600">{stats.scheduled}</p>
        </div>
        <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-4 border border-purple-100">
          <p className="text-sm text-slate-600 mb-1">Completed</p>
          <p className="text-3xl font-bold text-purple-600">{stats.completed}</p>
        </div>
        <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-xl p-4 border border-amber-100">
          <p className="text-sm text-slate-600 mb-1">Avg Score</p>
          <p className="text-3xl font-bold text-amber-600">{stats.avgScore}</p>
        </div>
      </div>

      {/* Filter */}
      <div className="mb-6">
        <select
          value={filterType}
          onChange={(e) => setFilterType(e.target.value)}
          className="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
        >
          <option value="all">All Interviews</option>
          <option value="AI">🤖 AI Interviews</option>
          <option value="Human">👨‍💼 Human Interviews</option>
        </select>
      </div>

      {/* Interviews List */}
      <div className="space-y-4">
        {filteredInterviews.map((interview) => (
          <div
            key={interview.id}
            className="bg-slate-50 rounded-xl p-6 border border-slate-200 hover:border-indigo-200 transition-all duration-200 hover:shadow-md"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-4 flex-1">
                <img
                  src={interview.logo}
                  alt={interview.company}
                  className="w-16 h-16 rounded-xl object-cover border-2 border-slate-100"
                />
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-slate-800 mb-1">{interview.position}</h3>
                  <p className="text-indigo-600 font-semibold mb-2">{interview.company}</p>
                  <div className="flex flex-wrap gap-3 text-sm text-slate-600 mb-3">
                    <span className="flex items-center">
                      <span className="mr-1">{interview.type === 'AI' ? '🤖' : '👨‍💼'}</span>
                      {interview.type} Interview
                    </span>
                    <span className="flex items-center">
                      <span className="mr-1">📅</span>
                      {interview.date}
                    </span>
                    <span className="flex items-center">
                      <span className="mr-1">🕐</span>
                      {interview.time}
                    </span>
                    <span className="flex items-center">
                      <span className="mr-1">⏱️</span>
                      {interview.duration}
                    </span>
                  </div>
                  {interview.interviewer && (
                    <p className="text-sm text-slate-600 mb-2">
                      Interviewer: {interview.interviewer}
                    </p>
                  )}
                  <div className="flex items-center space-x-3">
                    <span className={`px-3 py-1 rounded-lg text-sm font-medium border ${getStatusColor(interview.status)}`}>
                      {interview.status}
                    </span>
                    {interview.score && (
                      <span className={`text-lg font-bold ${getScoreColor(interview.score)}`}>
                        Score: {interview.score}/100
                      </span>
                    )}
                  </div>
                  {interview.feedback && (
                    <div className="mt-3 p-3 bg-white rounded-lg border border-slate-200">
                      <p className="text-sm font-semibold text-slate-700 mb-1">Feedback:</p>
                      <p className="text-sm text-slate-600">{interview.feedback}</p>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex flex-col space-y-2 ml-4">
                {interview.status === 'Scheduled' && (
                  <button
                    onClick={() => navigate(`/interview/${interview.id}`)}
                    className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium whitespace-nowrap"
                  >
                    Join Interview
                  </button>
                )}
{interview.status === 'Completed' && (
                  <>
                    <button
                      onClick={() => navigate('/recordings')}
                      className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-sm font-medium whitespace-nowrap"
                    >
                      Watch Recording
                    </button>
                    <button
                      onClick={() => alert(`View detailed feedback for ${interview.position}`)}
                      className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm font-medium whitespace-nowrap"
                    >
                      View Feedback
                    </button>
                  </>
                )}
                {interview.status === 'Pending' && (
                  <button
                    onClick={() => alert(`Prepare for interview with ${interview.company}`)}
                    className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-sm font-medium whitespace-nowrap"
                  >
                    Prepare
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
export default function CandidateProfileHeader() {
  const profileData = {
    name: 'Sarah Mitchell',
    title: 'Senior Full Stack Developer',
    location: 'San Francisco, CA',
    email: 'sarah.mitchell@email.com',
    phone: '+1 (555) 123-4567',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop',
    completeness: 85,
    memberSince: 'January 2024'
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden mb-6">
      {/* Cover Image */}
      <div className="h-32 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600"></div>
      
      {/* Profile Content */}
      <div className="px-8 pb-8">
        <div className="flex flex-col md:flex-row items-start md:items-end -mt-16 mb-6">
          {/* Avatar */}
          <img
            src={profileData.avatar}
            alt={profileData.name}
            className="w-32 h-32 rounded-2xl border-4 border-white shadow-xl mb-4 md:mb-0"
          />
          
          {/* Info */}
          <div className="md:ml-6 flex-1">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="text-3xl font-bold text-slate-800 mb-1">{profileData.name}</h1>
                <p className="text-lg text-slate-600 mb-2">{profileData.title}</p>
                <div className="flex flex-wrap gap-4 text-sm text-slate-500">
                  <span className="flex items-center">
                    <span className="mr-2">📍</span>
                    {profileData.location}
                  </span>
                  <span className="flex items-center">
                    <span className="mr-2">📧</span>
                    {profileData.email}
                  </span>
                  <span className="flex items-center">
                    <span className="mr-2">📱</span>
                    {profileData.phone}
                  </span>
                </div>
              </div>
              
              <button
                onClick={() => {
                  alert('Edit profile functionality will be fully implemented with backend integration!');
                }}
                className="mt-4 md:mt-0 px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium flex items-center space-x-2 hover:scale-105 active:scale-95"
              >
                <span>✏️</span>
                <span>Edit Profile</span>
              </button>
            </div>
          </div>
        </div>

        {/* Profile Completeness */}
        <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-6 border border-indigo-100">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="font-semibold text-slate-800 mb-1">Profile Completeness</h3>
              <p className="text-sm text-slate-600">Complete your profile to increase visibility to employers</p>
            </div>
            <div className="text-right">
              <p className="text-3xl font-bold text-indigo-600">{profileData.completeness}%</p>
              <p className="text-xs text-slate-500">Member since {profileData.memberSince}</p>
            </div>
          </div>
          <div className="w-full bg-slate-200 rounded-full h-3 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full transition-all duration-500"
              style={{ width: `${profileData.completeness}%` }}
            ></div>
          </div>
          {profileData.completeness < 100 && (
            <div className="mt-4 flex flex-wrap gap-2">
              <span className="px-3 py-1 bg-white text-indigo-600 rounded-full text-xs font-medium border border-indigo-200">
                + Add portfolio items
              </span>
              <span className="px-3 py-1 bg-white text-indigo-600 rounded-full text-xs font-medium border border-indigo-200">
                + Complete work history
              </span>
              <span className="px-3 py-1 bg-white text-indigo-600 rounded-full text-xs font-medium border border-indigo-200">
                + Add certifications
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
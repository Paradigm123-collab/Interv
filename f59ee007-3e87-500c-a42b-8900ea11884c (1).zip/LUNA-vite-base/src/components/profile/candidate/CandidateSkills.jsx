import { useState } from 'react';

export default function CandidateSkills() {
  const [skills] = useState({
    technical: [
      { name: 'React', level: 95, category: 'Frontend' },
      { name: 'Node.js', level: 90, category: 'Backend' },
      { name: 'TypeScript', level: 88, category: 'Language' },
      { name: 'AWS', level: 85, category: 'Cloud' },
      { name: 'MongoDB', level: 82, category: 'Database' },
      { name: 'Docker', level: 80, category: 'DevOps' },
      { name: 'GraphQL', level: 78, category: 'API' },
      { name: 'Python', level: 75, category: 'Language' }
    ],
    soft: [
      { name: 'Leadership', level: 90 },
      { name: 'Communication', level: 92 },
      { name: 'Problem Solving', level: 95 },
      { name: 'Team Collaboration', level: 88 },
      { name: 'Time Management', level: 85 },
      { name: 'Adaptability', level: 90 }
    ]
  });

  const getSkillColor = (level) => {
    if (level >= 90) return 'from-green-500 to-emerald-500';
    if (level >= 80) return 'from-blue-500 to-cyan-500';
    if (level >= 70) return 'from-amber-500 to-yellow-500';
    return 'from-slate-400 to-slate-500';
  };

  const getCategoryColor = (category) => {
    const colors = {
      'Frontend': 'bg-blue-100 text-blue-800',
      'Backend': 'bg-green-100 text-green-800',
      'Language': 'bg-purple-100 text-purple-800',
      'Cloud': 'bg-indigo-100 text-indigo-800',
      'Database': 'bg-orange-100 text-orange-800',
      'DevOps': 'bg-pink-100 text-pink-800',
      'API': 'bg-cyan-100 text-cyan-800'
    };
    return colors[category] || 'bg-slate-100 text-slate-800';
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-slate-100 p-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-slate-800">Skills & Expertise</h2>
        <button
          onClick={() => alert('Edit skills functionality will be implemented!')}
          className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium flex items-center space-x-2 hover:scale-105 active:scale-95"
        >
          <span>✏️</span>
          <span>Edit Skills</span>
        </button>
      </div>

      {/* Technical Skills */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
          <span className="mr-2">⚡</span>
          Technical Skills
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {skills.technical.map((skill, index) => (
            <div key={index} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="font-semibold text-slate-800">{skill.name}</span>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getCategoryColor(skill.category)}`}>
                    {skill.category}
                  </span>
                </div>
                <span className="text-sm font-semibold text-slate-600">{skill.level}%</span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden">
                <div
                  className={`h-full bg-gradient-to-r ${getSkillColor(skill.level)} rounded-full transition-all duration-500`}
                  style={{ width: `${skill.level}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Soft Skills */}
      <div>
        <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
          <span className="mr-2">🤝</span>
          Soft Skills
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {skills.soft.map((skill, index) => (
            <div key={index} className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-800">{skill.name}</span>
                <span className="text-sm font-semibold text-slate-600">{skill.level}%</span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden">
                <div
                  className={`h-full bg-gradient-to-r ${getSkillColor(skill.level)} rounded-full transition-all duration-500`}
                  style={{ width: `${skill.level}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Skill Categories Summary */}
      <div className="mt-8 p-6 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl border border-indigo-100">
        <h4 className="font-semibold text-slate-800 mb-4">Skill Categories</h4>
        <div className="flex flex-wrap gap-3">
          {Array.from(new Set(skills.technical.map(s => s.category))).map((category, index) => (
            <div key={index} className={`px-4 py-2 rounded-lg ${getCategoryColor(category)} font-medium`}>
              {category}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
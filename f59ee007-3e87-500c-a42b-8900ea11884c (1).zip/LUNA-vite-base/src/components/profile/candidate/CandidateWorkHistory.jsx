import { useState } from 'react';

export default function CandidateWorkHistory() {
  const [workHistory, setWorkHistory] = useState([
    {
      id: 1,
      company: 'TechCorp Solutions',
      position: 'Senior Full Stack Developer',
      location: 'San Francisco, CA',
      startDate: '2021-03',
      endDate: 'Present',
      current: true,
      description: 'Leading development of enterprise web applications using React, Node.js, and AWS. Mentoring junior developers and conducting code reviews.',
      achievements: [
        'Reduced application load time by 40% through optimization',
        'Led migration to microservices architecture',
        'Implemented CI/CD pipeline reducing deployment time by 60%'
      ]
    },
    {
      id: 2,
      company: 'Innovation Labs',
      position: 'Full Stack Developer',
      location: 'San Francisco, CA',
      startDate: '2019-01',
      endDate: '2021-02',
      current: false,
      description: 'Developed and maintained multiple client-facing web applications. Collaborated with design team to implement responsive UI/UX.',
      achievements: [
        'Built real-time collaboration features using WebSockets',
        'Improved test coverage from 40% to 85%',
        'Developed reusable component library used across 5 projects'
      ]
    },
    {
      id: 3,
      company: 'StartupHub Inc',
      position: 'Junior Developer',
      location: 'Remote',
      startDate: '2017-06',
      endDate: '2018-12',
      current: false,
      description: 'Contributed to front-end development of SaaS platform. Worked closely with senior developers to learn best practices.',
      achievements: [
        'Implemented responsive design for mobile users',
        'Fixed over 100 bugs and improved code quality',
        'Participated in agile development process'
      ]
    }
  ]);

  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const handleAdd = () => {
    setIsAdding(true);
  };

  const handleEdit = (id) => {
    setEditingId(id);
  };

  const handleDelete = (id) => {
    if (confirm('Are you sure you want to delete this work experience?')) {
      setWorkHistory(workHistory.filter(work => work.id !== id));
      const message = document.createElement('div');
      message.className = 'fixed top-20 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
      message.textContent = 'Work experience deleted successfully!';
      document.body.appendChild(message);
      setTimeout(() => message.remove(), 3000);
    }
  };

  const handleSave = () => {
    setIsAdding(false);
    setEditingId(null);
    const message = document.createElement('div');
    message.className = 'fixed top-20 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
    message.textContent = 'Work experience saved successfully!';
    document.body.appendChild(message);
    setTimeout(() => message.remove(), 3000);
  };

  const formatDate = (dateString) => {
    if (dateString === 'Present') return 'Present';
    const [year, month] = dateString.split('-');
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${months[parseInt(month) - 1]} ${year}`;
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-slate-100 p-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-slate-800">Work Experience</h2>
        <button
          onClick={handleAdd}
          className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium flex items-center space-x-2 hover:scale-105 active:scale-95"
        >
          <span>➕</span>
          <span>Add Experience</span>
        </button>
      </div>

      {/* Add/Edit Form */}
      {(isAdding || editingId) && (
        <div className="mb-8 p-6 bg-slate-50 rounded-xl border border-slate-200">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">
            {isAdding ? 'Add New Experience' : 'Edit Experience'}
          </h3>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Company</label>
                <input
                  type="text"
                  className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="Company name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Position</label>
                <input
                  type="text"
                  className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="Job title"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Location</label>
                <input
                  type="text"
                  className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="City, State"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Start Date</label>
                <input
                  type="month"
                  className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">End Date</label>
                <input
                  type="month"
                  className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <label className="flex items-center mt-2 text-sm text-slate-600">
                  <input type="checkbox" className="mr-2" />
                  Currently working here
                </label>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Description</label>
              <textarea
                rows={3}
                className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="Describe your role and responsibilities"
              />
            </div>

            <div className="flex justify-end space-x-2">
              <button
                onClick={() => {
                  setIsAdding(false);
                  setEditingId(null);
                }}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors font-medium"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="px-6 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 font-medium"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Work History Timeline */}
      <div className="space-y-6">
        {workHistory.map((work, index) => (
          <div key={work.id} className="relative">
            {/* Timeline Line */}
            {index !== workHistory.length - 1 && (
              <div className="absolute left-6 top-16 bottom-0 w-0.5 bg-slate-200"></div>
            )}

            <div className="flex items-start space-x-4">
              {/* Timeline Dot */}
              <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
                work.current
                  ? 'bg-gradient-to-br from-indigo-600 to-purple-600'
                  : 'bg-slate-200'
              }`}>
                <span className="text-xl">{work.current ? '💼' : '📋'}</span>
              </div>

              {/* Content */}
              <div className="flex-1 bg-slate-50 rounded-xl p-6 border border-slate-200">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="text-lg font-bold text-slate-800">{work.position}</h3>
                    <p className="text-indigo-600 font-semibold">{work.company}</p>
                    <div className="flex items-center space-x-4 text-sm text-slate-500 mt-2">
                      <span className="flex items-center">
                        <span className="mr-1">📍</span>
                        {work.location}
                      </span>
                      <span className="flex items-center">
                        <span className="mr-1">📅</span>
                        {formatDate(work.startDate)} - {work.current ? 'Present' : formatDate(work.endDate)}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleEdit(work.id)}
                      className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                      title="Edit"
                    >
                      ✏️
                    </button>
                    <button
                      onClick={() => handleDelete(work.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      title="Delete"
                    >
                      🗑️
                    </button>
                  </div>
                </div>

                <p className="text-slate-700 mb-4">{work.description}</p>

                {work.achievements && work.achievements.length > 0 && (
                  <div>
                    <p className="text-sm font-semibold text-slate-700 mb-2">Key Achievements:</p>
                    <ul className="space-y-1">
                      {work.achievements.map((achievement, idx) => (
                        <li key={idx} className="text-sm text-slate-600 flex items-start">
                          <span className="mr-2 text-green-600">✓</span>
                          <span>{achievement}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function EmployerCandidateDetail({ candidate, onBack }) {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [rating, setRating] = useState(0);
  const [isBookmarked, setIsBookmarked] = useState(false);

  if (!candidate) {
    return (
      <div className="text-center py-12">
        <p className="text-slate-600">No candidate selected</p>
        <button
          onClick={onBack}
          className="mt-4 px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
        >
          Back to Search
        </button>
      </div>
    );
  }

  const tabs = [
    { id: 'overview', label: 'Overview', icon: '👤' },
    { id: 'experience', label: 'Experience', icon: '💼' },
    { id: 'education', label: 'Education', icon: '🎓' },
    { id: 'documents', label: 'Documents', icon: '📄' },
    { id: 'interviews', label: 'Interview History', icon: '🎥' }
  ];

  const handleScheduleInterview = () => {
    navigate('/scheduling');
  };

  const handleRating = (value) => {
    setRating(value);
    const message = document.createElement('div');
    message.className = 'fixed top-20 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
    message.textContent = `Rating saved: ${value} stars`;
    document.body.appendChild(message);
    setTimeout(() => message.remove(), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="flex items-center space-x-2 text-indigo-600 hover:text-indigo-700 font-medium"
      >
        <span>←</span>
        <span>Back to Search</span>
      </button>

      {/* Candidate Header */}
      <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
        <div className="h-32 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600"></div>
        <div className="px-8 pb-8">
          <div className="flex flex-col md:flex-row items-start md:items-end -mt-16 mb-6">
            <img
              src={candidate.avatar}
              alt={candidate.name}
              className="w-32 h-32 rounded-2xl border-4 border-white shadow-xl mb-4 md:mb-0"
            />
            <div className="md:ml-6 flex-1">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-slate-800 mb-1">{candidate.name}</h1>
                  <p className="text-lg text-slate-600 mb-2">{candidate.title}</p>
                  <div className="flex flex-wrap gap-4 text-sm text-slate-500">
                    <span className="flex items-center">
                      <span className="mr-2">📍</span>
                      {candidate.location}
                    </span>
                    <span className="flex items-center">
                      <span className="mr-2">💼</span>
                      {candidate.experience}
                    </span>
                    <span className="flex items-center">
                      <span className="mr-2">⏰</span>
                      Available: {candidate.availability}
                    </span>
                  </div>
                </div>
                <div className="mt-4 md:mt-0 flex items-center space-x-3">
                  <button
                    onClick={() => setIsBookmarked(!isBookmarked)}
                    className={`p-3 rounded-lg transition-colors ${
                      isBookmarked
                        ? 'bg-amber-100 text-amber-600'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {isBookmarked ? '⭐' : '☆'}
                  </button>
                  <button
                    onClick={handleScheduleInterview}
                    className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium flex items-center space-x-2"
                  >
                    <span>📅</span>
                    <span>Schedule Interview</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Match Score & Rating */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-6 border border-green-100">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-slate-800 mb-1">Match Score</h3>
                  <p className="text-sm text-slate-600">Based on job requirements</p>
                </div>
                <p className="text-4xl font-bold text-green-600">{candidate.matchScore}%</p>
              </div>
            </div>

            <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-6 border border-indigo-100">
              <h3 className="font-semibold text-slate-800 mb-3">Your Rating</h3>
              <div className="flex items-center space-x-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => handleRating(star)}
                    className={`text-3xl transition-transform hover:scale-110 ${
                      star <= rating ? 'text-amber-400' : 'text-slate-300'
                    }`}
                  >
                    ⭐
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white rounded-xl shadow-lg border border-slate-100 overflow-x-auto">
        <div className="flex space-x-1 p-2 min-w-max">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-6 py-3 rounded-lg font-medium transition-all duration-200 flex items-center space-x-2 whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      <div className="bg-white rounded-2xl shadow-lg border border-slate-100 p-8">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-bold text-slate-800 mb-4">Professional Summary</h3>
              <p className="text-slate-700 leading-relaxed">
                Passionate full-stack developer with {candidate.experience} of experience building scalable web applications. 
                Currently working at {candidate.currentCompany}. Specialized in modern web technologies and cloud infrastructure. 
                Strong track record of delivering high-quality solutions and mentoring team members.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-bold text-slate-800 mb-4">Skills</h3>
              <div className="flex flex-wrap gap-3">
                {candidate.skills.map((skill, index) => (
                  <span
                    key={index}
                    className="px-4 py-2 bg-indigo-100 text-indigo-700 rounded-lg font-medium"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-xl font-bold text-slate-800 mb-4">Current Position</h3>
              <div className="bg-slate-50 rounded-xl p-6 border border-slate-200">
                <p className="font-semibold text-slate-800">{candidate.title}</p>
                <p className="text-indigo-600">{candidate.currentCompany}</p>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-bold text-slate-800 mb-4">Education</h3>
              <div className="bg-slate-50 rounded-xl p-6 border border-slate-200">
                <p className="font-semibold text-slate-800">{candidate.education}</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'experience' && (
          <div className="text-center py-12">
            <p className="text-slate-600">Work experience details will be displayed here</p>
          </div>
        )}

        {activeTab === 'education' && (
          <div className="text-center py-12">
            <p className="text-slate-600">Education details will be displayed here</p>
          </div>
        )}

        {activeTab === 'documents' && (
          <div className="text-center py-12">
            <p className="text-slate-600">Resume and portfolio documents will be displayed here</p>
          </div>
        )}

        {activeTab === 'interviews' && (
          <div className="text-center py-12">
            <p className="text-slate-600">Interview history will be displayed here</p>
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="flex items-center justify-between bg-white rounded-xl shadow-lg border border-slate-100 p-6">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => alert('Send message functionality will be implemented!')}
            className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium"
          >
            💬 Send Message
          </button>
          <button
            onClick={() => alert('Add notes functionality will be implemented!')}
            className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium"
          >
            📝 Add Notes
          </button>
        </div>
        <button
          onClick={handleScheduleInterview}
          className="px-8 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium"
        >
          Schedule Interview
        </button>
      </div>
    </div>
  );
}
import { useState } from 'react';

export default function EmployerCandidateSearch({ onViewCandidate }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    skills: [],
    experience: 'all',
    location: 'all',
    availability: 'all'
  });

  const candidates = [
    {
      id: 1,
      name: 'Sarah Mitchell',
      title: 'Senior Full Stack Developer',
      location: 'San Francisco, CA',
      experience: '8 years',
      availability: 'Immediate',
      skills: ['React', 'Node.js', 'TypeScript', 'AWS', 'MongoDB'],
      education: 'MS Computer Science - Stanford',
      currentCompany: 'TechCorp Solutions',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop',
      matchScore: 95,
      applications: 3,
      interviews: 2
    },
    {
      id: 2,
      name: 'Michael Chen',
      title: 'Full Stack Engineer',
      location: 'Remote',
      experience: '6 years',
      availability: '2 weeks',
      skills: ['React', 'Python', 'Django', 'PostgreSQL', 'Docker'],
      education: 'BS Software Engineering - MIT',
      currentCompany: 'Innovation Labs',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop',
      matchScore: 92,
      applications: 2,
      interviews: 1
    },
    {
      id: 3,
      name: 'Emily Rodriguez',
      title: 'Frontend Developer',
      location: 'New York, NY',
      experience: '5 years',
      availability: 'Immediate',
      skills: ['React', 'Vue.js', 'CSS', 'JavaScript', 'Figma'],
      education: 'BS Computer Science - Berkeley',
      currentCompany: 'Digital Dynamics',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop',
      matchScore: 88,
      applications: 4,
      interviews: 3
    },
    {
      id: 4,
      name: 'David Park',
      title: 'UI/UX Designer & Developer',
      location: 'Los Angeles, CA',
      experience: '7 years',
      availability: '1 month',
      skills: ['React', 'Figma', 'Adobe XD', 'CSS', 'JavaScript'],
      education: 'BFA Design - RISD',
      currentCompany: 'Creative Studios',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop',
      matchScore: 85,
      applications: 1,
      interviews: 1
    },
    {
      id: 5,
      name: 'Lisa Anderson',
      title: 'Product Manager & Developer',
      location: 'Seattle, WA',
      experience: '9 years',
      availability: 'Immediate',
      skills: ['React', 'Product Strategy', 'Agile', 'Data Analysis', 'SQL'],
      education: 'MBA & BS CS - Harvard',
      currentCompany: 'StartupHub Inc',
      avatar: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=200&h=200&fit=crop',
      matchScore: 90,
      applications: 2,
      interviews: 2
    },
    {
      id: 6,
      name: 'James Wilson',
      title: 'DevOps Engineer',
      location: 'Austin, TX',
      experience: '6 years',
      availability: '2 weeks',
      skills: ['AWS', 'Docker', 'Kubernetes', 'Python', 'Terraform'],
      education: 'BS Computer Engineering - UT Austin',
      currentCompany: 'CloudTech Systems',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop',
      matchScore: 87,
      applications: 3,
      interviews: 1
    },
    {
      id: 7,
      name: 'Maria Garcia',
      title: 'Data Scientist',
      location: 'Boston, MA',
      experience: '5 years',
      availability: 'Immediate',
      skills: ['Python', 'Machine Learning', 'SQL', 'TensorFlow', 'R'],
      education: 'PhD Data Science - MIT',
      currentCompany: 'Analytics Pro',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop',
      matchScore: 93,
      applications: 2,
      interviews: 2
    },
    {
      id: 8,
      name: 'Robert Taylor',
      title: 'Backend Developer',
      location: 'Chicago, IL',
      experience: '7 years',
      availability: '1 month',
      skills: ['Node.js', 'Java', 'Spring Boot', 'MySQL', 'Redis'],
      education: 'MS Software Engineering - CMU',
      currentCompany: 'ServerTech Inc',
      avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&h=200&fit=crop',
      matchScore: 86,
      applications: 1,
      interviews: 1
    }
  ];

  const filteredCandidates = candidates.filter(candidate => {
    const matchesSearch = searchQuery === '' ||
      candidate.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      candidate.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      candidate.skills.some(skill => skill.toLowerCase().includes(searchQuery.toLowerCase()));
    
    return matchesSearch;
  });

  const getMatchScoreColor = (score) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 80) return 'text-blue-600';
    if (score >= 70) return 'text-amber-600';
    return 'text-slate-600';
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-800 mb-2">Candidate Search</h1>
        <p className="text-slate-600">Find and evaluate the best candidates for your positions</p>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl shadow-lg border border-slate-100 p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-2">
            <input
              type="text"
              placeholder="Search by name, title, or skills..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
          <select
            value={filters.experience}
            onChange={(e) => setFilters({ ...filters, experience: e.target.value })}
            className="px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Experience</option>
            <option value="0-2">0-2 years</option>
            <option value="3-5">3-5 years</option>
            <option value="6-10">6-10 years</option>
            <option value="10+">10+ years</option>
          </select>
          <select
            value={filters.availability}
            onChange={(e) => setFilters({ ...filters, availability: e.target.value })}
            className="px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Availability</option>
            <option value="immediate">Immediate</option>
            <option value="2weeks">Within 2 weeks</option>
            <option value="1month">Within 1 month</option>
          </select>
        </div>
      </div>

      {/* Results Count */}
      <div className="flex items-center justify-between">
        <p className="text-slate-600">
          Found <span className="font-bold text-slate-800">{filteredCandidates.length}</span> candidates
        </p>
        <select className="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500">
          <option>Sort by: Best Match</option>
          <option>Sort by: Experience</option>
          <option>Sort by: Availability</option>
          <option>Sort by: Recent Activity</option>
        </select>
      </div>

      {/* Candidates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCandidates.map((candidate) => (
          <div
            key={candidate.id}
            onClick={() => onViewCandidate(candidate)}
            className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-slate-100 cursor-pointer group hover:scale-105 active:scale-95"
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <img
                src={candidate.avatar}
                alt={candidate.name}
                className="w-16 h-16 rounded-full border-2 border-indigo-200 group-hover:scale-110 transition-transform"
              />
              <div className={`text-right`}>
                <p className={`text-2xl font-bold ${getMatchScoreColor(candidate.matchScore)}`}>
                  {candidate.matchScore}%
                </p>
                <p className="text-xs text-slate-500">Match Score</p>
              </div>
            </div>

            {/* Info */}
            <h3 className="text-lg font-bold text-slate-800 mb-1 group-hover:text-indigo-600 transition-colors">
              {candidate.name}
            </h3>
            <p className="text-sm text-slate-600 mb-3">{candidate.title}</p>

            {/* Details */}
            <div className="space-y-2 mb-4 text-sm text-slate-600">
              <div className="flex items-center">
                <span className="mr-2">📍</span>
                <span>{candidate.location}</span>
              </div>
              <div className="flex items-center">
                <span className="mr-2">💼</span>
                <span>{candidate.experience} experience</span>
              </div>
              <div className="flex items-center">
                <span className="mr-2">🎓</span>
                <span className="truncate">{candidate.education}</span>
              </div>
              <div className="flex items-center">
                <span className="mr-2">⏰</span>
                <span>Available: {candidate.availability}</span>
              </div>
            </div>

            {/* Skills */}
            <div className="mb-4">
              <div className="flex flex-wrap gap-2">
                {candidate.skills.slice(0, 3).map((skill, index) => (
                  <span
                    key={index}
                    className="px-2 py-1 bg-indigo-100 text-indigo-700 rounded-md text-xs font-medium"
                  >
                    {skill}
                  </span>
                ))}
                {candidate.skills.length > 3 && (
                  <span className="px-2 py-1 bg-slate-100 text-slate-700 rounded-md text-xs font-medium">
                    +{candidate.skills.length - 3} more
                  </span>
                )}
              </div>
            </div>

            {/* Stats */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-100">
              <div className="text-center">
                <p className="text-lg font-bold text-indigo-600">{candidate.applications}</p>
                <p className="text-xs text-slate-500">Applications</p>
              </div>
              <div className="text-center">
                <p className="text-lg font-bold text-purple-600">{candidate.interviews}</p>
                <p className="text-xs text-slate-500">Interviews</p>
              </div>
              <span className="text-indigo-600 text-sm font-medium group-hover:translate-x-1 transition-transform">
                View Profile →
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
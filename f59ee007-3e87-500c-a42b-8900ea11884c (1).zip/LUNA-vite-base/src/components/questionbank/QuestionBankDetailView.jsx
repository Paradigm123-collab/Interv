import { useState } from 'react';

export default function QuestionBankDetailView({ question, onBack, currentRole }) {
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', label: 'Overview', icon: '📋' },
    { id: 'usage', label: 'Usage Stats', icon: '📊' },
    { id: 'feedback', label: 'Feedback', icon: '💬' },
    { id: 'settings', label: 'Settings', icon: '⚙️' }
  ];

  const usageHistory = [
    {
      id: 1,
      candidate: 'Sarah Mitchell',
      interviewer: 'John Anderson',
      date: '2024-01-20',
      score: 8.5,
      feedback: 'Excellent understanding of React concepts',
      duration: '6 min'
    },
    {
      id: 2,
      candidate: 'Michael Chen',
      interviewer: 'Emily Rodriguez',
      date: '2024-01-18',
      score: 7.2,
      feedback: 'Good grasp but needs more practical examples',
      duration: '7 min'
    },
    {
      id: 3,
      candidate: 'David Park',
      interviewer: 'Lisa Anderson',
      date: '2024-01-15',
      score: 9.0,
      feedback: 'Outstanding explanation with real-world examples',
      duration: '5 min'
    }
  ];

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Easy':
        return 'bg-green-100 text-green-800';
      case 'Intermediate':
        return 'bg-amber-100 text-amber-800';
      case 'Advanced':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100">
        <button
          onClick={onBack}
          className="text-indigo-600 hover:text-indigo-700 font-medium mb-6 flex items-center space-x-2"
        >
          <span>←</span>
          <span>Back to Question Bank</span>
        </button>

        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-4 mb-4">
              <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${question.color} flex items-center justify-center`}>
                <span className="text-white text-3xl">
                  {question.type === 'Coding' ? '💻' : 
                   question.type === 'Design' ? '🎨' : 
                   question.type === 'Behavioral' ? '💬' : '📝'}
                </span>
              </div>
              <div>
                <h1 className="text-3xl font-bold text-slate-800 mb-2">{question.title}</h1>
                <div className="flex items-center space-x-4 text-sm text-slate-600">
                  <span className="flex items-center">
                    <span className="mr-1">📁</span>
                    {question.category}
                  </span>
                  <span className="flex items-center">
                    <span className="mr-1">👤</span>
                    {question.role}
                  </span>
                  <span className="flex items-center">
                    <span className="mr-1">⏱️</span>
                    {question.duration}
                  </span>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getDifficultyColor(question.difficulty)}`}>
                    {question.difficulty}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-6 mt-6">
              <div className="text-center">
                <p className="text-3xl font-bold text-indigo-600">{question.usageCount}</p>
                <p className="text-sm text-slate-600">Times Used</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-green-600">{question.avgScore}/10</p>
                <p className="text-sm text-slate-600">Avg Score</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-purple-600">{question.isApproved ? '✓' : '⏳'}</p>
                <p className="text-sm text-slate-600">{question.isApproved ? 'Approved' : 'Pending'}</p>
              </div>
            </div>
          </div>

          <div className="flex flex-col space-y-3">
            <button className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium">
              Edit Question
            </button>
            <button className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium">
              Duplicate
            </button>
            <button className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium">
              Share
            </button>
            {currentRole === 'admin' && (
              <button className="px-6 py-3 bg-white text-red-600 border-2 border-red-200 rounded-lg hover:border-red-300 hover:bg-red-50 transition-all duration-200 font-medium">
                Delete
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
        <div className="flex border-b border-slate-200">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 px-6 py-4 font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <span className="mr-2">{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </div>

        <div className="p-8">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-bold text-slate-800 mb-4">Question Description</h3>
                <p className="text-slate-700 leading-relaxed">{question.description}</p>
              </div>

              <div>
                <h3 className="text-xl font-bold text-slate-800 mb-4">Sample Answer</h3>
                <div className="bg-slate-50 rounded-xl p-6 border border-slate-200">
                  <p className="text-slate-700 leading-relaxed">{question.sampleAnswer}</p>
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-slate-800 mb-4">Required Skills</h3>
                <div className="flex flex-wrap gap-2">
                  {question.skills.map((skill, index) => (
                    <span
                      key={index}
                      className="px-4 py-2 bg-indigo-100 text-indigo-800 rounded-lg text-sm font-medium"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-slate-800 mb-4">Tags</h3>
                <div className="flex flex-wrap gap-2">
                  {question.tags.map((tag, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-medium"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 border-t border-slate-200">
                <div>
                  <h4 className="font-semibold text-slate-800 mb-2">Created By</h4>
                  <p className="text-slate-600">{question.createdBy}</p>
                  <p className="text-sm text-slate-500">{question.createdDate}</p>
                </div>
                <div>
                  <h4 className="font-semibold text-slate-800 mb-2">Last Used</h4>
                  <p className="text-slate-600">{question.lastUsed}</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'usage' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-slate-800 mb-6">Usage History</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl p-6 border border-blue-100">
                  <h4 className="font-semibold text-slate-800 mb-2">Total Uses</h4>
                  <p className="text-4xl font-bold text-blue-600">{question.usageCount}</p>
                  <p className="text-sm text-slate-600 mt-2">Across all interviews</p>
                </div>
                
                <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-6 border border-green-100">
                  <h4 className="font-semibold text-slate-800 mb-2">Average Score</h4>
                  <p className="text-4xl font-bold text-green-600">{question.avgScore}/10</p>
                  <p className="text-sm text-slate-600 mt-2">Candidate performance</p>
                </div>
                
                <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6 border border-purple-100">
                  <h4 className="font-semibold text-slate-800 mb-2">Success Rate</h4>
                  <p className="text-4xl font-bold text-purple-600">78%</p>
                  <p className="text-sm text-slate-600 mt-2">Passed threshold</p>
                </div>
              </div>

              <div className="space-y-4">
                {usageHistory.map((usage) => (
                  <div
                    key={usage.id}
                    className="bg-slate-50 rounded-xl p-6 hover:bg-slate-100 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-4 mb-2">
                          <h4 className="font-semibold text-slate-800">{usage.candidate}</h4>
                          <span className="text-sm text-slate-600">interviewed by {usage.interviewer}</span>
                        </div>
                        <p className="text-sm text-slate-600 mb-2">{usage.feedback}</p>
                        <div className="flex items-center space-x-4 text-sm text-slate-500">
                          <span>📅 {usage.date}</span>
                          <span>⏱️ {usage.duration}</span>
                        </div>
                      </div>
                      <div className="text-center ml-6">
                        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center mb-2">
                          <span className="text-white text-xl font-bold">{usage.score}</span>
                        </div>
                        <p className="text-xs text-slate-600">Score</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'feedback' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-slate-800 mb-6">Interviewer Feedback</h3>
              
              <div className="space-y-4">
                {[
                  {
                    id: 1,
                    interviewer: 'John Anderson',
                    date: '2024-01-20',
                    rating: 5,
                    comment: 'Great question for assessing React knowledge. Candidates responses reveal their depth of understanding.'
                  },
                  {
                    id: 2,
                    interviewer: 'Emily Rodriguez',
                    date: '2024-01-18',
                    rating: 4,
                    comment: 'Good question but could benefit from more specific follow-up prompts.'
                  },
                  {
                    id: 3,
                    interviewer: 'Lisa Anderson',
                    date: '2024-01-15',
                    rating: 5,
                    comment: 'Perfect for intermediate level candidates. Sample answer is very helpful.'
                  }
                ].map((feedback) => (
                  <div
                    key={feedback.id}
                    className="bg-slate-50 rounded-xl p-6 border border-slate-200"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="font-semibold text-slate-800">{feedback.interviewer}</h4>
                        <p className="text-sm text-slate-500">{feedback.date}</p>
                      </div>
                      <div className="flex items-center space-x-1">
                        {[...Array(5)].map((_, i) => (
                          <span key={i} className={i < feedback.rating ? 'text-yellow-500' : 'text-slate-300'}>
                            ⭐
                          </span>
                        ))}
                      </div>
                    </div>
                    <p className="text-slate-700">{feedback.comment}</p>
                  </div>
                ))}
              </div>

              <div className="pt-6 border-t border-slate-200">
                <button className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium">
                  Add Your Feedback
                </button>
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-slate-800 mb-6">Question Settings</h3>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div>
                    <h4 className="font-semibold text-slate-800">Question Status</h4>
                    <p className="text-sm text-slate-600">Control question availability</p>
                  </div>
                  <select className="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <option>Active</option>
                    <option>Draft</option>
                    <option>Archived</option>
                  </select>
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div>
                    <h4 className="font-semibold text-slate-800">Approval Required</h4>
                    <p className="text-sm text-slate-600">Require admin approval before use</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked={question.isApproved} />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div>
                    <h4 className="font-semibold text-slate-800">Public Visibility</h4>
                    <p className="text-sm text-slate-600">Make question visible to all users</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div>
                    <h4 className="font-semibold text-slate-800">AI Suggestions</h4>
                    <p className="text-sm text-slate-600">Enable AI-powered improvements</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                  </label>
                </div>
              </div>

              {currentRole === 'admin' && (
                <div className="pt-6 border-t border-slate-200">
                  <button className="px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium">
                    Delete Question
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
export default function QuestionBankFilters({ filters, onFilterChange }) {
  const roles = [
    'All Roles',
    'Frontend Developer',
    'Backend Developer',
    'Full Stack Developer',
    'DevOps Engineer',
    'UI/UX Designer',
    'Database Administrator',
    'Software Engineer'
  ];

  const skills = [
    'All Skills',
    'React',
    'JavaScript',
    'Python',
    'Java',
    'SQL',
    'AWS',
    'Docker',
    'Kubernetes',
    'UI Design',
    'System Design'
  ];

  const difficulties = ['All Levels', 'Easy', 'Intermediate', 'Advanced'];
  const categories = ['All Categories', 'Technical', 'Behavioral', 'Coding', 'Design', 'System Design', 'DevOps', 'Security'];

  const handleFilterChange = (key, value) => {
    const normalizedValue = value === 'All Roles' || value === 'All Skills' || value === 'All Levels' || value === 'All Categories' 
      ? 'all' 
      : value;
    onFilterChange({ ...filters, [key]: normalizedValue });
  };

  return (
    <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100 mb-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="lg:col-span-2">
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Search Questions
          </label>
          <div className="relative">
            <input
              type="text"
              value={filters.search}
              onChange={(e) => handleFilterChange('search', e.target.value)}
              placeholder="Search by title, description, or tags..."
              className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400">
              🔍
            </span>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Job Role
          </label>
          <select
            value={filters.role === 'all' ? 'All Roles' : filters.role}
            onChange={(e) => handleFilterChange('role', e.target.value)}
            className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          >
            {roles.map((role) => (
              <option key={role} value={role}>
                {role}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Skill
          </label>
          <select
            value={filters.skill === 'all' ? 'All Skills' : filters.skill}
            onChange={(e) => handleFilterChange('skill', e.target.value)}
            className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          >
            {skills.map((skill) => (
              <option key={skill} value={skill}>
                {skill}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Difficulty
          </label>
          <select
            value={filters.difficulty === 'all' ? 'All Levels' : filters.difficulty}
            onChange={(e) => handleFilterChange('difficulty', e.target.value)}
            className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          >
            {difficulties.map((difficulty) => (
              <option key={difficulty} value={difficulty}>
                {difficulty}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-slate-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <label className="block text-sm font-medium text-slate-700">
              Category
            </label>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => handleFilterChange('category', category)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    (filters.category === 'all' && category === 'All Categories') ||
                    filters.category === category
                      ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={() => onFilterChange({
              search: '',
              role: 'all',
              skill: 'all',
              difficulty: 'all',
              category: 'all'
            })}
            className="px-4 py-2 text-slate-600 hover:text-slate-800 font-medium text-sm flex items-center space-x-2"
          >
            <span>🔄</span>
            <span>Reset Filters</span>
          </button>
        </div>
      </div>
    </div>
  );
}
import { useState } from 'react';

export default function QuestionBankList({ filters, onViewQuestion, currentRole }) {
  const [questions] = useState([
    {
      id: 1,
      title: 'Explain React Hooks and their benefits',
      category: 'Technical',
      role: 'Frontend Developer',
      skills: ['React', 'JavaScript', 'Hooks'],
      difficulty: 'Intermediate',
      type: 'Conceptual',
      duration: '5-7 min',
      usageCount: 45,
      avgScore: 7.8,
      createdBy: 'John Anderson',
      createdDate: '2024-01-15',
      lastUsed: '2 days ago',
      description: 'Assess candidate\'s understanding of React Hooks, including useState, useEffect, and custom hooks.',
      sampleAnswer: 'React Hooks are functions that let you use state and other React features in functional components...',
      tags: ['React', 'Frontend', 'Modern JavaScript'],
      isApproved: true,
      color: 'from-blue-500 to-cyan-500'
    },
    {
      id: 2,
      title: 'Design a scalable microservices architecture',
      category: 'System Design',
      role: 'Backend Developer',
      skills: ['Architecture', 'Microservices', 'Cloud'],
      difficulty: 'Advanced',
      type: 'Design',
      duration: '15-20 min',
      usageCount: 32,
      avgScore: 8.2,
      createdBy: 'Sarah Mitchell',
      createdDate: '2024-01-10',
      lastUsed: '1 week ago',
      description: 'Evaluate candidate\'s ability to design and architect scalable distributed systems.',
      sampleAnswer: 'A scalable microservices architecture should consider service boundaries, communication patterns...',
      tags: ['Architecture', 'Backend', 'Scalability'],
      isApproved: true,
      color: 'from-purple-500 to-pink-500'
    },
    {
      id: 3,
      title: 'Implement a binary search algorithm',
      category: 'Coding',
      role: 'Software Engineer',
      skills: ['Algorithms', 'Data Structures', 'Problem Solving'],
      difficulty: 'Intermediate',
      type: 'Coding',
      duration: '10-15 min',
      usageCount: 67,
      avgScore: 7.5,
      createdBy: 'Michael Chen',
      createdDate: '2024-01-20',
      lastUsed: '1 day ago',
      description: 'Test candidate\'s understanding of search algorithms and their implementation.',
      sampleAnswer: 'Binary search is an efficient algorithm for finding an item in a sorted array...',
      tags: ['Algorithms', 'Coding', 'Computer Science'],
      isApproved: true,
      color: 'from-green-500 to-emerald-500'
    },
    {
      id: 4,
      title: 'Describe your approach to handling conflicts in a team',
      category: 'Behavioral',
      role: 'All Roles',
      skills: ['Communication', 'Teamwork', 'Conflict Resolution'],
      difficulty: 'Easy',
      type: 'Behavioral',
      duration: '5-8 min',
      usageCount: 89,
      avgScore: 8.0,
      createdBy: 'Emily Rodriguez',
      createdDate: '2024-01-05',
      lastUsed: '3 hours ago',
      description: 'Assess candidate\'s interpersonal skills and ability to handle workplace conflicts.',
      sampleAnswer: 'When handling conflicts, I first try to understand all perspectives involved...',
      tags: ['Soft Skills', 'Communication', 'Leadership'],
      isApproved: true,
      color: 'from-orange-500 to-red-500'
    },
    {
      id: 5,
      title: 'Optimize database query performance',
      category: 'Technical',
      role: 'Database Administrator',
      skills: ['SQL', 'Database', 'Performance'],
      difficulty: 'Advanced',
      type: 'Problem Solving',
      duration: '12-15 min',
      usageCount: 28,
      avgScore: 8.5,
      createdBy: 'David Park',
      createdDate: '2024-01-18',
      lastUsed: '5 days ago',
      description: 'Evaluate candidate\'s expertise in database optimization and query tuning.',
      sampleAnswer: 'Query optimization involves analyzing execution plans, indexing strategies...',
      tags: ['Database', 'SQL', 'Performance'],
      isApproved: true,
      color: 'from-indigo-500 to-purple-500'
    },
    {
      id: 6,
      title: 'Explain CI/CD pipeline implementation',
      category: 'DevOps',
      role: 'DevOps Engineer',
      skills: ['CI/CD', 'Automation', 'DevOps'],
      difficulty: 'Intermediate',
      type: 'Conceptual',
      duration: '8-10 min',
      usageCount: 41,
      avgScore: 7.9,
      createdBy: 'Lisa Anderson',
      createdDate: '2024-01-12',
      lastUsed: '4 days ago',
      description: 'Test candidate\'s knowledge of continuous integration and deployment practices.',
      sampleAnswer: 'A CI/CD pipeline automates the software delivery process from code commit to production...',
      tags: ['DevOps', 'Automation', 'CI/CD'],
      isApproved: true,
      color: 'from-teal-500 to-cyan-500'
    },
    {
      id: 7,
      title: 'Design a responsive mobile-first UI',
      category: 'Design',
      role: 'UI/UX Designer',
      skills: ['UI Design', 'Responsive Design', 'Mobile'],
      difficulty: 'Intermediate',
      type: 'Design',
      duration: '15-20 min',
      usageCount: 35,
      avgScore: 8.3,
      createdBy: 'James Wilson',
      createdDate: '2024-01-08',
      lastUsed: '1 week ago',
      description: 'Assess candidate\'s ability to create responsive and mobile-friendly interfaces.',
      sampleAnswer: 'Mobile-first design starts with designing for the smallest screen size...',
      tags: ['UI/UX', 'Design', 'Mobile'],
      isApproved: true,
      color: 'from-pink-500 to-rose-500'
    },
    {
      id: 8,
      title: 'Implement authentication and authorization',
      category: 'Security',
      role: 'Full Stack Developer',
      skills: ['Security', 'Authentication', 'Backend'],
      difficulty: 'Advanced',
      type: 'Coding',
      duration: '20-25 min',
      usageCount: 52,
      avgScore: 8.1,
      createdBy: 'Maria Garcia',
      createdDate: '2024-01-14',
      lastUsed: '2 days ago',
      description: 'Evaluate candidate\'s understanding of security best practices and implementation.',
      sampleAnswer: 'Authentication verifies user identity while authorization determines access rights...',
      tags: ['Security', 'Backend', 'Authentication'],
      isApproved: true,
      color: 'from-amber-500 to-yellow-500'
    }
  ]);

  const filteredQuestions = questions.filter(question => {
    const matchesSearch = filters.search === '' || 
      question.title.toLowerCase().includes(filters.search.toLowerCase()) ||
      question.description.toLowerCase().includes(filters.search.toLowerCase()) ||
      question.tags.some(tag => tag.toLowerCase().includes(filters.search.toLowerCase()));
    
    const matchesRole = filters.role === 'all' || question.role === filters.role;
    const matchesSkill = filters.skill === 'all' || question.skills.includes(filters.skill);
    const matchesDifficulty = filters.difficulty === 'all' || question.difficulty === filters.difficulty;
    const matchesCategory = filters.category === 'all' || question.category === filters.category;

    return matchesSearch && matchesRole && matchesSkill && matchesDifficulty && matchesCategory;
  });

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Easy':
        return 'bg-green-100 text-green-800';
      case 'Intermediate':
        return 'bg-amber-100 text-amber-800';
      case 'Advanced':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">
            Question Library ({filteredQuestions.length})
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            {filters.search && `Showing results for "${filters.search}"`}
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={() => alert('Bulk import feature will be available with backend integration!')}
            className="px-4 py-2 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all font-medium flex items-center space-x-2"
          >
            <span>📥</span>
            <span>Import</span>
          </button>
          <button
            onClick={() => alert('Export feature will be available with backend integration!')}
            className="px-4 py-2 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all font-medium flex items-center space-x-2"
          >
            <span>📤</span>
            <span>Export</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredQuestions.map((question) => (
          <div
            key={question.id}
            onClick={() => onViewQuestion(question)}
            className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-slate-100 cursor-pointer group hover:scale-105 active:scale-95"
          >
            <div className="flex items-start justify-between mb-4">
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${question.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                <span className="text-white text-xl font-bold">
                  {question.type === 'Coding' ? '💻' : 
                   question.type === 'Design' ? '🎨' : 
                   question.type === 'Behavioral' ? '💬' : '📝'}
                </span>
              </div>
              {question.isApproved && (
                <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium flex items-center space-x-1">
                  <span>✓</span>
                  <span>Approved</span>
                </span>
              )}
            </div>

            <h3 className="font-semibold text-slate-800 mb-2 line-clamp-2 group-hover:text-indigo-600 transition-colors">
              {question.title}
            </h3>

            <p className="text-sm text-slate-600 mb-4 line-clamp-2">
              {question.description}
            </p>

            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-600">Category</span>
                <span className="font-medium text-slate-800">{question.category}</span>
              </div>

              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-600">Role</span>
                <span className="font-medium text-slate-800">{question.role}</span>
              </div>

              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-600">Difficulty</span>
                <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getDifficultyColor(question.difficulty)}`}>
                  {question.difficulty}
                </span>
              </div>

              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-600">Duration</span>
                <span className="font-medium text-slate-800">{question.duration}</span>
              </div>

              <div className="pt-3 border-t border-slate-100">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center space-x-1 text-slate-600">
                    <span>📊</span>
                    <span>Used {question.usageCount} times</span>
                  </div>
                  <div className="flex items-center space-x-1 text-green-600 font-medium">
                    <span>⭐</span>
                    <span>{question.avgScore}/10</span>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-1 pt-2">
                {question.skills.slice(0, 3).map((skill, index) => (
                  <span
                    key={index}
                    className="px-2 py-1 bg-indigo-50 text-indigo-700 rounded text-xs font-medium"
                  >
                    {skill}
                  </span>
                ))}
                {question.skills.length > 3 && (
                  <span className="px-2 py-1 bg-slate-100 text-slate-600 rounded text-xs font-medium">
                    +{question.skills.length - 3}
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredQuestions.length === 0 && (
        <div className="text-center py-12">
          <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-4xl">🔍</span>
          </div>
          <h3 className="text-xl font-bold text-slate-800 mb-2">No questions found</h3>
          <p className="text-slate-600 mb-6">Try adjusting your filters or create a new question</p>
        </div>
      )}
    </div>
  );
}
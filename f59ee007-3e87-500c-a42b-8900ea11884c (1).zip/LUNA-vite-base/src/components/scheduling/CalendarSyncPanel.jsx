export default function CalendarSyncPanel({ onClose }) {
  const calendars = [
    {
      id: 'google',
      name: 'Google Calendar',
      icon: '📅',
      color: 'from-blue-500 to-cyan-500',
      connected: true,
      lastSync: '2 minutes ago'
    },
    {
      id: 'outlook',
      name: 'Microsoft Outlook',
      icon: '📧',
      color: 'from-indigo-500 to-blue-500',
      connected: false,
      lastSync: null
    },
    {
      id: 'apple',
      name: 'Apple Calendar',
      icon: '🍎',
      color: 'from-slate-600 to-slate-800',
      connected: false,
      lastSync: null
    }
  ];

  const handleConnect = (calendar) => {
    const message = document.createElement('div');
    message.className = 'fixed top-20 right-4 bg-indigo-600 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
    message.innerHTML = `
      <div class="flex items-center space-x-3">
        <div class="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
        <span>Connecting to ${calendar.name}...</span>
      </div>
    `;
    document.body.appendChild(message);
    
    setTimeout(() => {
      message.remove();
      alert(`${calendar.name} integration will be available with backend implementation!\n\nFeatures:\n- Two-way sync\n- Automatic updates\n- Conflict detection\n- Real-time notifications`);
    }, 2000);
  };

  const handleDisconnect = (calendar) => {
    if (confirm(`Disconnect ${calendar.name}?`)) {
      alert('Calendar disconnection will be implemented with backend!');
    }
  };

  const handleSync = (calendar) => {
    const message = document.createElement('div');
    message.className = 'fixed top-20 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
    message.innerHTML = `
      <div class="flex items-center space-x-3">
        <span class="text-xl">✓</span>
        <span>${calendar.name} synced successfully!</span>
      </div>
    `;
    document.body.appendChild(message);
    setTimeout(() => message.remove(), 3000);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full">
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-6 rounded-t-2xl">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold">Calendar Integration</h2>
              <p className="text-sm opacity-90 mt-1">
                Connect your calendars for seamless scheduling
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
            >
              <span className="text-2xl">×</span>
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-8 space-y-6">
          {/* Sync Status */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
            <div className="flex items-start space-x-3">
              <span className="text-2xl">ℹ️</span>
              <div>
                <h3 className="font-semibold text-blue-900 mb-1">Two-Way Sync Enabled</h3>
                <p className="text-sm text-blue-800">
                  Interviews scheduled here will automatically appear in your connected calendars, 
                  and calendar events will be reflected in the platform.
                </p>
              </div>
            </div>
          </div>

          {/* Calendar List */}
          <div className="space-y-4">
            {calendars.map(calendar => (
              <div
                key={calendar.id}
                className="bg-slate-50 rounded-xl p-6 border-2 border-slate-200 hover:border-slate-300 transition-all"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${calendar.color} flex items-center justify-center`}>
                      <span className="text-2xl">{calendar.icon}</span>
                    </div>
                    <div>
                      <h3 className="font-semibold text-slate-800 text-lg">{calendar.name}</h3>
                      {calendar.connected ? (
                        <div className="flex items-center space-x-2 mt-1">
                          <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                          <p className="text-sm text-slate-600">
                            Connected • Last sync: {calendar.lastSync}
                          </p>
                        </div>
                      ) : (
                        <p className="text-sm text-slate-500 mt-1">Not connected</p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    {calendar.connected ? (
                      <>
                        <button
                          onClick={() => handleSync(calendar)}
                          className="px-4 py-2 bg-white text-indigo-600 border-2 border-indigo-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition-all font-medium"
                        >
                          🔄 Sync Now
                        </button>
                        <button
                          onClick={() => handleDisconnect(calendar)}
                          className="px-4 py-2 bg-white text-red-600 border-2 border-red-200 rounded-lg hover:border-red-300 hover:bg-red-50 transition-all font-medium"
                        >
                          Disconnect
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={() => handleConnect(calendar)}
                        className="px-6 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all font-medium"
                      >
                        Connect
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Sync Settings */}
          <div className="bg-slate-50 rounded-xl p-6 space-y-4">
            <h3 className="font-semibold text-slate-800 mb-4">Sync Settings</h3>
            
            <label className="flex items-center justify-between cursor-pointer">
              <div>
                <p className="font-medium text-slate-800">Auto-sync interviews</p>
                <p className="text-sm text-slate-600">Automatically sync new interviews to calendars</p>
              </div>
              <input
                type="checkbox"
                defaultChecked
                className="w-12 h-6 rounded-full appearance-none bg-slate-300 checked:bg-indigo-600 relative cursor-pointer transition-colors
                  before:content-[''] before:absolute before:w-5 before:h-5 before:rounded-full before:bg-white before:top-0.5 before:left-0.5 
                  before:transition-transform checked:before:translate-x-6"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer">
              <div>
                <p className="font-medium text-slate-800">Sync reminders</p>
                <p className="text-sm text-slate-600">Include interview reminders in calendar events</p>
              </div>
              <input
                type="checkbox"
                defaultChecked
                className="w-12 h-6 rounded-full appearance-none bg-slate-300 checked:bg-indigo-600 relative cursor-pointer transition-colors
                  before:content-[''] before:absolute before:w-5 before:h-5 before:rounded-full before:bg-white before:top-0.5 before:left-0.5 
                  before:transition-transform checked:before:translate-x-6"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer">
              <div>
                <p className="font-medium text-slate-800">Block calendar time</p>
                <p className="text-sm text-slate-600">Mark interview slots as busy in your calendar</p>
              </div>
              <input
                type="checkbox"
                defaultChecked
                className="w-12 h-6 rounded-full appearance-none bg-slate-300 checked:bg-indigo-600 relative cursor-pointer transition-colors
                  before:content-[''] before:absolute before:w-5 before:h-5 before:rounded-full before:bg-white before:top-0.5 before:left-0.5 
                  before:transition-transform checked:before:translate-x-6"
              />
            </label>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end space-x-4 pt-6 border-t border-slate-200">
            <button
              onClick={onClose}
              className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
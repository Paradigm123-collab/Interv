import { useState } from 'react';

export default function ScheduleInterviewModal({ interview, onClose, onSchedule }) {
  const [formData, setFormData] = useState({
    candidate: interview?.candidate || '',
    candidateEmail: interview?.email || '',
    position: interview?.position || '',
    type: interview?.type || 'AI',
    date: interview?.date || '',
    time: interview?.time || '',
    duration: interview?.duration || 45,
    interviewer: interview?.interviewer || '',
    interviewerEmail: interview?.interviewerEmail || '',
    notes: interview?.notes || '',
    sendEmail: true,
    sendWhatsApp: true,
    syncCalendar: true
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      onSchedule(formData);
      setIsSubmitting(false);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-slate-200 px-8 py-6 rounded-t-2xl">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">
                {interview ? 'Edit Interview' : 'Schedule New Interview'}
              </h2>
              <p className="text-sm text-slate-600 mt-1">
                Set up AI or human-based interview with automated notifications
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <span className="text-2xl text-slate-400">×</span>
            </button>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          {/* Interview Type Selection */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-3">
              Interview Type *
            </label>
            <div className="grid grid-cols-2 gap-4">
              <button
                type="button"
                onClick={() => handleInputChange('type', 'AI')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  formData.type === 'AI'
                    ? 'border-purple-500 bg-purple-50'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="text-center">
                  <span className="text-3xl mb-2 block">🤖</span>
                  <p className="font-semibold text-slate-800">AI Interview</p>
                  <p className="text-xs text-slate-600 mt-1">Automated & Consistent</p>
                </div>
              </button>
              <button
                type="button"
                onClick={() => handleInputChange('type', 'Human')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  formData.type === 'Human'
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="text-center">
                  <span className="text-3xl mb-2 block">👨‍💼</span>
                  <p className="font-semibold text-slate-800">Human Interview</p>
                  <p className="text-xs text-slate-600 mt-1">Personal & Nuanced</p>
                </div>
              </button>
            </div>
          </div>

          {/* Candidate Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Candidate Name *
              </label>
              <input
                type="text"
                value={formData.candidate}
                onChange={(e) => handleInputChange('candidate', e.target.value)}
                placeholder="John Doe"
                required
                className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Candidate Email *
              </label>
              <input
                type="email"
                value={formData.candidateEmail}
                onChange={(e) => handleInputChange('candidateEmail', e.target.value)}
                placeholder="john.doe@email.com"
                required
                className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Position */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Position *
            </label>
            <input
              type="text"
              value={formData.position}
              onChange={(e) => handleInputChange('position', e.target.value)}
              placeholder="Senior React Developer"
              required
              className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Human Interviewer (only for Human type) */}
          {formData.type === 'Human' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Interviewer Name *
                </label>
                <input
                  type="text"
                  value={formData.interviewer}
                  onChange={(e) => handleInputChange('interviewer', e.target.value)}
                  placeholder="Dr. Sarah Johnson"
                  required
                  className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Interviewer Email *
                </label>
                <input
                  type="email"
                  value={formData.interviewerEmail}
                  onChange={(e) => handleInputChange('interviewerEmail', e.target.value)}
                  placeholder="sarah.johnson@company.com"
                  required
                  className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>
          )}

          {/* Date, Time, Duration */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Date *
              </label>
              <input
                type="date"
                value={formData.date}
                onChange={(e) => handleInputChange('date', e.target.value)}
                required
                className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Time *
              </label>
              <input
                type="time"
                value={formData.time}
                onChange={(e) => handleInputChange('time', e.target.value)}
                required
                className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Duration (min) *
              </label>
              <select
                value={formData.duration}
                onChange={(e) => handleInputChange('duration', parseInt(e.target.value))}
                className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value={30}>30 minutes</option>
                <option value={45}>45 minutes</option>
                <option value={60}>60 minutes</option>
                <option value={90}>90 minutes</option>
              </select>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Additional Notes
            </label>
            <textarea
              value={formData.notes}
              onChange={(e) => handleInputChange('notes', e.target.value)}
              placeholder="Any special instructions or requirements..."
              rows={3}
              className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
            />
          </div>

          {/* Notification Options */}
          <div className="bg-slate-50 rounded-xl p-4 space-y-3">
            <h3 className="font-semibold text-slate-800 mb-3">Notification Settings</h3>
            
            <label className="flex items-center space-x-3 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.sendEmail}
                onChange={(e) => handleInputChange('sendEmail', e.target.checked)}
                className="w-5 h-5 text-indigo-600 rounded focus:ring-2 focus:ring-indigo-500"
              />
              <div>
                <p className="font-medium text-slate-800">📧 Send Email Notifications</p>
                <p className="text-xs text-slate-600">Automated email reminders to all participants</p>
              </div>
            </label>

            <label className="flex items-center space-x-3 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.sendWhatsApp}
                onChange={(e) => handleInputChange('sendWhatsApp', e.target.checked)}
                className="w-5 h-5 text-indigo-600 rounded focus:ring-2 focus:ring-indigo-500"
              />
              <div>
                <p className="font-medium text-slate-800">💬 Send WhatsApp Reminders</p>
                <p className="text-xs text-slate-600">WhatsApp notifications 24h and 1h before interview</p>
              </div>
            </label>

            <label className="flex items-center space-x-3 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.syncCalendar}
                onChange={(e) => handleInputChange('syncCalendar', e.target.checked)}
                className="w-5 h-5 text-indigo-600 rounded focus:ring-2 focus:ring-indigo-500"
              />
              <div>
                <p className="font-medium text-slate-800">📅 Sync to Calendar</p>
                <p className="text-xs text-slate-600">Add to Google Calendar and Outlook automatically</p>
              </div>
            </label>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end space-x-4 pt-6 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-3 text-slate-700 hover:bg-slate-100 rounded-lg transition-colors font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium flex items-center space-x-2 disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Scheduling...</span>
                </>
              ) : (
                <>
                  <span>✓</span>
                  <span>{interview ? 'Update Interview' : 'Schedule Interview'}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
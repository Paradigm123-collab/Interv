import { useState } from 'react';

export default function SchedulingCalendar({ onScheduleInterview, onEditInterview }) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(null);

  const interviews = [
    {
      id: 1,
      candidate: 'Sarah Mitchell',
      position: 'Senior React Developer',
      type: 'AI',
      date: '2024-12-28',
      time: '14:00',
      duration: 45,
      status: 'scheduled',
      color: 'from-purple-500 to-pink-500'
    },
    {
      id: 2,
      candidate: 'Michael Chen',
      position: 'Full Stack Engineer',
      type: 'Human',
      interviewer: 'Dr. Sarah Johnson',
      date: '2024-12-30',
      time: '10:00',
      duration: 60,
      status: 'scheduled',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      id: 3,
      candidate: 'Emily Rodriguez',
      position: 'Frontend Developer',
      type: 'AI',
      date: '2025-01-02',
      time: '15:30',
      duration: 30,
      status: 'pending',
      color: 'from-green-500 to-emerald-500'
    },
    {
      id: 4,
      candidate: 'David Park',
      position: 'UI/UX Designer',
      type: 'Human',
      interviewer: 'John Anderson',
      date: '2025-01-02',
      time: '11:00',
      duration: 45,
      status: 'scheduled',
      color: 'from-orange-500 to-red-500'
    }
  ];

  const getDaysInMonth = (date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days = [];
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(new Date(year, month, i));
    }
    return days;
  };

  const getInterviewsForDate = (date) => {
    if (!date) return [];
    const dateStr = date.toISOString().split('T')[0];
    return interviews.filter(interview => interview.date === dateStr);
  };

  const handlePreviousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  const handleToday = () => {
    setCurrentDate(new Date());
  };

  const days = getDaysInMonth(currentDate);
  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const isToday = (date) => {
    if (!date) return false;
    const today = new Date();
    return date.toDateString() === today.toDateString();
  };

  const isSelected = (date) => {
    if (!date || !selectedDate) return false;
    return date.toDateString() === selectedDate.toDateString();
  };

  return (
    <div className="space-y-6">
      {/* Calendar Header */}
      <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-slate-800">
              {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              {interviews.length} interviews scheduled this month
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={handleToday}
              className="px-4 py-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors font-medium"
            >
              Today
            </button>
            <button
              onClick={handlePreviousMonth}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <span className="text-xl">←</span>
            </button>
            <button
              onClick={handleNextMonth}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <span className="text-xl">→</span>
            </button>
          </div>
        </div>

        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-2">
          {/* Day Headers */}
          {dayNames.map(day => (
            <div key={day} className="text-center py-2 text-sm font-semibold text-slate-600">
              {day}
            </div>
          ))}

          {/* Calendar Days */}
          {days.map((date, index) => {
            const dayInterviews = getInterviewsForDate(date);
            return (
              <div
                key={index}
                onClick={() => date && setSelectedDate(date)}
                className={`min-h-24 p-2 rounded-lg border-2 transition-all cursor-pointer ${
                  !date
                    ? 'bg-slate-50 border-transparent'
                    : isToday(date)
                    ? 'bg-indigo-50 border-indigo-300'
                    : isSelected(date)
                    ? 'bg-purple-50 border-purple-300'
                    : dayInterviews.length > 0
                    ? 'bg-white border-slate-200 hover:border-indigo-200'
                    : 'bg-white border-slate-100 hover:border-slate-200'
                }`}
              >
                {date && (
                  <>
                    <div className={`text-sm font-semibold mb-1 ${
                      isToday(date) ? 'text-indigo-600' : 'text-slate-700'
                    }`}>
                      {date.getDate()}
                    </div>
                    <div className="space-y-1">
                      {dayInterviews.slice(0, 2).map(interview => (
                        <button
                          key={interview.id}
                          onClick={(e) => {
                            e.stopPropagation();
                            onEditInterview(interview);
                          }}
                          className={`w-full text-left px-2 py-1 rounded text-xs font-medium bg-gradient-to-r ${interview.color} text-white hover:opacity-90 transition-opacity`}
                        >
                          <div className="flex items-center space-x-1">
                            <span>{interview.type === 'AI' ? '🤖' : '👨‍💼'}</span>
                            <span className="truncate">{interview.time}</span>
                          </div>
                        </button>
                      ))}
                      {dayInterviews.length > 2 && (
                        <div className="text-xs text-slate-500 text-center">
                          +{dayInterviews.length - 2} more
                        </div>
                      )}
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Date Details */}
      {selectedDate && (
        <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-slate-800">
              {selectedDate.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}
            </h3>
            <button
              onClick={onScheduleInterview}
              className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 font-medium text-sm"
            >
              + Add Interview
            </button>
          </div>

          {getInterviewsForDate(selectedDate).length > 0 ? (
            <div className="space-y-3">
              {getInterviewsForDate(selectedDate).map(interview => (
                <button
                  key={interview.id}
                  onClick={() => onEditInterview(interview)}
                  className="w-full bg-slate-50 rounded-xl p-4 hover:bg-slate-100 transition-colors text-left"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${interview.color} flex items-center justify-center`}>
                        <span className="text-white text-xl">
                          {interview.type === 'AI' ? '🤖' : '👨‍💼'}
                        </span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-slate-800">{interview.candidate}</h4>
                        <p className="text-sm text-slate-600">{interview.position}</p>
                        {interview.type === 'Human' && interview.interviewer && (
                          <p className="text-xs text-slate-500">with {interview.interviewer}</p>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-slate-800">{interview.time}</p>
                      <p className="text-sm text-slate-600">{interview.duration} min</p>
                      <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium mt-1 ${
                        interview.status === 'scheduled'
                          ? 'bg-green-100 text-green-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {interview.status}
                      </span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">📅</span>
              </div>
              <p className="text-slate-600 mb-4">No interviews scheduled for this day</p>
              <button
                onClick={onScheduleInterview}
                className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 font-medium"
              >
                Schedule Interview
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
import { useState } from 'react';

export default function SchedulingList({ onScheduleInterview, onEditInterview }) {
  const [filterType, setFilterType] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const interviews = [
    {
      id: 1,
      candidate: 'Sarah Mitchell',
      email: 'sarah.mitchell@email.com',
      position: 'Senior React Developer',
      company: 'TechCorp Solutions',
      type: 'AI',
      date: '2024-12-28',
      time: '14:00',
      duration: 45,
      status: 'scheduled',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      color: 'from-purple-500 to-pink-500'
    },
    {
      id: 2,
      candidate: 'Michael Chen',
      email: 'michael.chen@email.com',
      position: 'Full Stack Engineer',
      company: 'Innovation Labs',
      type: 'Human',
      interviewer: 'Dr. Sarah Johnson',
      interviewerEmail: 'sarah.johnson@company.com',
      date: '2024-12-30',
      time: '10:00',
      duration: 60,
      status: 'scheduled',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      id: 3,
      candidate: 'Emily Rodriguez',
      email: 'emily.rodriguez@email.com',
      position: 'Frontend Developer',
      company: 'Digital Dynamics',
      type: 'AI',
      date: '2025-01-02',
      time: '15:30',
      duration: 30,
      status: 'pending',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
      color: 'from-green-500 to-emerald-500'
    },
    {
      id: 4,
      candidate: 'David Park',
      email: 'david.park@email.com',
      position: 'UI/UX Designer',
      company: 'Creative Studios',
      type: 'Human',
      interviewer: 'John Anderson',
      interviewerEmail: 'john.anderson@company.com',
      date: '2025-01-02',
      time: '11:00',
      duration: 45,
      status: 'scheduled',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
      color: 'from-orange-500 to-red-500'
    },
    {
      id: 5,
      candidate: 'Lisa Anderson',
      email: 'lisa.anderson@email.com',
      position: 'Product Manager',
      company: 'StartupHub Inc',
      type: 'Human',
      interviewer: 'Mark Wilson',
      interviewerEmail: 'mark.wilson@company.com',
      date: '2025-01-03',
      time: '13:00',
      duration: 60,
      status: 'scheduled',
      avatar: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop',
      color: 'from-indigo-500 to-purple-500'
    },
    {
      id: 6,
      candidate: 'James Wilson',
      email: 'james.wilson@email.com',
      position: 'DevOps Engineer',
      company: 'CloudTech Systems',
      type: 'AI',
      date: '2025-01-04',
      time: '09:00',
      duration: 45,
      status: 'completed',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop',
      color: 'from-teal-500 to-cyan-500'
    },
    {
      id: 7,
      candidate: 'Maria Garcia',
      email: 'maria.garcia@email.com',
      position: 'Data Scientist',
      company: 'Analytics Pro',
      type: 'Human',
      interviewer: 'Dr. Emily Chen',
      interviewerEmail: 'emily.chen@company.com',
      date: '2025-01-05',
      time: '14:30',
      duration: 60,
      status: 'scheduled',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop',
      color: 'from-pink-500 to-rose-500'
    },
    {
      id: 8,
      candidate: 'Robert Taylor',
      email: 'robert.taylor@email.com',
      position: 'Backend Developer',
      company: 'ServerTech Inc',
      type: 'AI',
      date: '2025-01-06',
      time: '16:00',
      duration: 45,
      status: 'cancelled',
      avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop',
      color: 'from-amber-500 to-yellow-500'
    }
  ];

  const filteredInterviews = interviews.filter(interview => {
    const matchesType = filterType === 'all' || interview.type.toLowerCase() === filterType.toLowerCase();
    const matchesStatus = filterStatus === 'all' || interview.status.toLowerCase() === filterStatus.toLowerCase();
    const matchesSearch = searchQuery === '' || 
      interview.candidate.toLowerCase().includes(searchQuery.toLowerCase()) ||
      interview.position.toLowerCase().includes(searchQuery.toLowerCase()) ||
      interview.company.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesType && matchesStatus && matchesSearch;
  });

  const stats = {
    total: interviews.length,
    ai: interviews.filter(i => i.type === 'AI').length,
    human: interviews.filter(i => i.type === 'Human').length,
    scheduled: interviews.filter(i => i.status === 'scheduled').length,
    pending: interviews.filter(i => i.status === 'pending').length,
    completed: interviews.filter(i => i.status === 'completed').length
  };

  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case 'scheduled':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-amber-100 text-amber-800';
      case 'completed':
        return 'bg-blue-100 text-blue-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  const handleSendReminder = (interview) => {
    const message = document.createElement('div');
    message.className = 'fixed top-20 right-4 bg-indigo-600 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
    message.innerHTML = `
      <div class="flex items-center space-x-3">
        <span class="text-xl">📧</span>
        <div>
          <p class="font-semibold">Reminder Sent!</p>
          <p class="text-sm opacity-90">Email and WhatsApp notifications sent to ${interview.candidate}</p>
        </div>
      </div>
    `;
    document.body.appendChild(message);
    setTimeout(() => message.remove(), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="bg-white rounded-xl p-4 shadow-lg border border-slate-100">
          <p className="text-sm text-slate-600 mb-1">Total</p>
          <p className="text-2xl font-bold text-slate-800">{stats.total}</p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-lg border border-slate-100">
          <p className="text-sm text-slate-600 mb-1">🤖 AI</p>
          <p className="text-2xl font-bold text-purple-600">{stats.ai}</p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-lg border border-slate-100">
          <p className="text-sm text-slate-600 mb-1">👨‍💼 Human</p>
          <p className="text-2xl font-bold text-blue-600">{stats.human}</p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-lg border border-slate-100">
          <p className="text-sm text-slate-600 mb-1">Scheduled</p>
          <p className="text-2xl font-bold text-green-600">{stats.scheduled}</p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-lg border border-slate-100">
          <p className="text-sm text-slate-600 mb-1">Pending</p>
          <p className="text-2xl font-bold text-amber-600">{stats.pending}</p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-lg border border-slate-100">
          <p className="text-sm text-slate-600 mb-1">Completed</p>
          <p className="text-2xl font-bold text-indigo-600">{stats.completed}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <input
            type="text"
            placeholder="Search interviews..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Types</option>
            <option value="ai">🤖 AI Interviews</option>
            <option value="human">👨‍💼 Human Interviews</option>
          </select>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Status</option>
            <option value="scheduled">Scheduled</option>
            <option value="pending">Pending</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
          <button
            onClick={onScheduleInterview}
            className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 font-medium"
          >
            + New Interview
          </button>
        </div>
      </div>

      {/* Interviews List */}
      <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
        {filteredInterviews.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase">Candidate</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase">Position</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase">Type</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase">Date & Time</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase">Duration</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase">Status</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredInterviews.map(interview => (
                  <tr key={interview.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        <img
                          src={interview.avatar}
                          alt={interview.candidate}
                          className="w-10 h-10 rounded-full border-2 border-slate-100"
                        />
                        <div>
                          <p className="font-semibold text-slate-800">{interview.candidate}</p>
                          <p className="text-sm text-slate-500">{interview.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-sm text-slate-800">{interview.position}</p>
                      <p className="text-xs text-slate-500">{interview.company}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${
                        interview.type === 'AI'
                          ? 'bg-purple-100 text-purple-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {interview.type === 'AI' ? '🤖 AI' : '👨‍💼 Human'}
                      </span>
                      {interview.type === 'Human' && interview.interviewer && (
                        <p className="text-xs text-slate-500 mt-1">{interview.interviewer}</p>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-sm text-slate-800">{interview.date}</p>
                      <p className="text-xs text-slate-500">{interview.time}</p>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-sm text-slate-800">{interview.duration} min</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(interview.status)}`}>
                        {interview.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-2">
<button
                          onClick={() => window.location.href = `/#/interview/${interview.id}`}
                          className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                          title="Start Interview"
                        >
                          🎥
                        </button>
                        <button
                          onClick={() => onEditInterview(interview)}
                          className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                          title="Edit"
                        >
                          ✏️
                        </button>
                        <button
                          onClick={() => handleSendReminder(interview)}
                          className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                          title="Send Reminder"
                        >
                          📧
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Cancel interview with ${interview.candidate}?`)) {
                              alert('Interview cancellation functionality will be implemented with backend!');
                            }
                          }}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Cancel"
                        >
                          ❌
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-4xl">🔍</span>
            </div>
            <h3 className="text-xl font-semibold text-slate-800 mb-2">No interviews found</h3>
            <p className="text-slate-600 mb-6">Try adjusting your filters or search query</p>
            <button
              onClick={onScheduleInterview}
              className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 font-medium"
            >
              Schedule New Interview
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
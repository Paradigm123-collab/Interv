import { useState } from 'react';
import AssessmentBasicInfo from './AssessmentBasicInfo';
import QuestionBuilder from './QuestionBuilder';
import AssessmentPreview from './AssessmentPreview';

export default function AssessmentBuilder({ assessment, onBack, onSave }) {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState(assessment || {
    title: '',
    description: '',
    category: 'Frontend Development',
    difficulty: 'Intermediate',
    duration: 45,
    passingScore: 70,
    skills: [],
    questions: [],
    status: 'Draft'
  });

  const steps = [
    { id: 1, label: 'Basic Info', icon: '📋' },
    { id: 2, label: 'Add Questions', icon: '❓' },
    { id: 3, label: 'Preview & Save', icon: '👁️' }
  ];

  const handleNext = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSave = () => {
    const savedAssessment = {
      ...formData,
      id: assessment?.id || Date.now(),
      createdBy: 'Current User',
      createdDate: new Date().toISOString().split('T')[0],
      lastUsed: 'Never',
      completions: assessment?.completions || 0,
      avgScore: assessment?.avgScore || 0,
      questionCount: formData.questions.length,
      color: 'from-indigo-500 to-purple-500'
    };
    onSave(savedAssessment);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100">
        <div className="flex items-center justify-between mb-8">
          {steps.map((step, index) => (
            <div key={step.id} className="flex items-center flex-1">
              <div className={`flex items-center justify-center w-12 h-12 rounded-full font-bold transition-all ${
                currentStep >= step.id
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
                  : 'bg-slate-200 text-slate-500'
              }`}>
                <span className="text-xl">{step.icon}</span>
              </div>
              {index < steps.length - 1 && (
                <div className={`flex-1 h-1 mx-4 rounded transition-all ${
                  currentStep > step.id ? 'bg-gradient-to-r from-indigo-600 to-purple-600' : 'bg-slate-200'
                }`}></div>
              )}
            </div>
          ))}
        </div>

        <div className="flex justify-between mb-8">
          {steps.map(step => (
            <span
              key={step.id}
              className={`text-sm font-medium ${
                currentStep >= step.id ? 'text-indigo-600' : 'text-slate-500'
              }`}
            >
              {step.label}
            </span>
          ))}
        </div>

        {currentStep === 1 && (
          <AssessmentBasicInfo
            formData={formData}
            onChange={setFormData}
          />
        )}

        {currentStep === 2 && (
          <QuestionBuilder
            formData={formData}
            onChange={setFormData}
          />
        )}

        {currentStep === 3 && (
          <AssessmentPreview
            assessment={formData}
          />
        )}

        <div className="flex items-center justify-between mt-8 pt-6 border-t border-slate-200">
          <button
            onClick={currentStep === 1 ? onBack : handlePrevious}
            className="px-6 py-3 text-slate-700 hover:bg-slate-100 rounded-lg transition-colors font-medium"
          >
            {currentStep === 1 ? '← Back to Assessments' : '← Previous'}
          </button>

          {currentStep < 3 ? (
            <button
              onClick={handleNext}
              className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium"
            >
              Next →
            </button>
          ) : (
            <button
              onClick={handleSave}
              className="px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all duration-200 shadow-lg font-medium flex items-center space-x-2"
            >
              <span>✓</span>
              <span>Save Assessment</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
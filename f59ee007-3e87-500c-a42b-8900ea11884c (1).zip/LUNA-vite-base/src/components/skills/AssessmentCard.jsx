export default function AssessmentCard({ assessment, onView, onEdit }) {
  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Easy':
        return 'bg-green-100 text-green-800';
      case 'Intermediate':
        return 'bg-amber-100 text-amber-800';
      case 'Advanced':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  return (
    <div
      onClick={() => onView(assessment)}
      className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-slate-100 cursor-pointer group hover:scale-105 active:scale-95"
    >
      <div className="flex items-start justify-between mb-4">
        <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${assessment.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
          <span className="text-white text-2xl">🎯</span>
        </div>
        <div className="flex items-center space-x-2">
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
            assessment.status === 'Active'
              ? 'bg-green-100 text-green-800'
              : 'bg-slate-100 text-slate-800'
          }`}>
            {assessment.status}
          </span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onEdit(assessment);
            }}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <span className="text-slate-600">✏️</span>
          </button>
        </div>
      </div>

      <h3 className="font-bold text-slate-800 mb-2 line-clamp-2 group-hover:text-indigo-600 transition-colors">
        {assessment.title}
      </h3>
      <p className="text-sm text-slate-600 mb-4 line-clamp-2">{assessment.description}</p>

      <div className="space-y-2 mb-4">
        <div className="flex items-center justify-between text-sm">
          <span className="text-slate-600">Category</span>
          <span className="font-medium text-slate-800">{assessment.category}</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-slate-600">Difficulty</span>
          <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getDifficultyColor(assessment.difficulty)}`}>
            {assessment.difficulty}
          </span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-slate-600">Questions</span>
          <span className="font-medium text-slate-800">{assessment.questionCount}</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-slate-600">Duration</span>
          <span className="font-medium text-slate-800">{assessment.duration} min</span>
        </div>
      </div>

      <div className="flex flex-wrap gap-1 mb-4">
        {assessment.skills.slice(0, 3).map((skill, index) => (
          <span
            key={index}
            className="px-2 py-1 bg-indigo-50 text-indigo-700 rounded text-xs font-medium"
          >
            {skill}
          </span>
        ))}
        {assessment.skills.length > 3 && (
          <span className="px-2 py-1 bg-slate-100 text-slate-600 rounded text-xs font-medium">
            +{assessment.skills.length - 3}
          </span>
        )}
      </div>

      <div className="pt-4 border-t border-slate-100">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center space-x-1 text-slate-600">
            <span>📊</span>
            <span>{assessment.completions} completions</span>
          </div>
          <div className="flex items-center space-x-1 text-green-600 font-medium">
            <span>⭐</span>
            <span>{assessment.avgScore}%</span>
          </div>
        </div>
      </div>
    </div>
  );
}
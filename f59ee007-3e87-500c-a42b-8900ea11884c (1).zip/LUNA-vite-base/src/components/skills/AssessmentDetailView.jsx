import { useState } from 'react';

export default function AssessmentDetailView({ assessment, onBack, onEdit }) {
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', label: 'Overview', icon: '📋' },
    { id: 'questions', label: 'Questions', icon: '❓' },
    { id: 'results', label: 'Results', icon: '📊' },
    { id: 'settings', label: 'Settings', icon: '⚙️' }
  ];

  const recentResults = [
    {
      id: 1,
      candidateName: 'Sarah Mitchell',
      candidateAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      score: 85,
      passed: true,
      completedDate: '2024-01-20',
      duration: 42,
      correctAnswers: 21,
      totalQuestions: 25
    },
    {
      id: 2,
      candidateName: 'Michael Chen',
      candidateAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      score: 68,
      passed: false,
      completedDate: '2024-01-19',
      duration: 45,
      correctAnswers: 17,
      totalQuestions: 25
    },
    {
      id: 3,
      candidateName: 'Emily Rodriguez',
      candidateAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
      score: 92,
      passed: true,
      completedDate: '2024-01-18',
      duration: 38,
      correctAnswers: 23,
      totalQuestions: 25
    }
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100">
        <button
          onClick={onBack}
          className="text-indigo-600 hover:text-indigo-700 font-medium mb-6 flex items-center space-x-2"
        >
          <span>←</span>
          <span>Back to Assessments</span>
        </button>

        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-4 mb-4">
              <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${assessment.color} flex items-center justify-center`}>
                <span className="text-white text-3xl">🎯</span>
              </div>
              <div>
                <h1 className="text-3xl font-bold text-slate-800 mb-2">{assessment.title}</h1>
                <p className="text-slate-600">{assessment.description}</p>
              </div>
            </div>

            <div className="flex items-center space-x-6 mt-6">
              <div className="text-center">
                <p className="text-3xl font-bold text-indigo-600">{assessment.completions}</p>
                <p className="text-sm text-slate-600">Completions</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-green-600">{assessment.avgScore}%</p>
                <p className="text-sm text-slate-600">Avg Score</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-purple-600">{assessment.questionCount}</p>
                <p className="text-sm text-slate-600">Questions</p>
              </div>
            </div>
          </div>

          <div className="flex flex-col space-y-3">
            <button
              onClick={() => onEdit(assessment)}
              className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium"
            >
              Edit Assessment
            </button>
            <button className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium">
              Duplicate
            </button>
            <button className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium">
              Share
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
        <div className="flex border-b border-slate-200">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 px-6 py-4 font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <span className="mr-2">{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </div>

        <div className="p-8">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-slate-50 rounded-xl p-6">
                  <h3 className="font-semibold text-slate-800 mb-4">Assessment Details</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-slate-600">Category</span>
                      <span className="font-medium text-slate-800">{assessment.category}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">Difficulty</span>
                      <span className="font-medium text-slate-800">{assessment.difficulty}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">Duration</span>
                      <span className="font-medium text-slate-800">{assessment.duration} min</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">Passing Score</span>
                      <span className="font-medium text-slate-800">{assessment.passingScore}%</span>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-50 rounded-xl p-6">
                  <h3 className="font-semibold text-slate-800 mb-4">Question Types</h3>
                  <div className="space-y-3">
                    {Object.entries(assessment.questionTypes).map(([type, count]) => (
                      <div key={type} className="flex justify-between">
                        <span className="text-slate-600 capitalize">{type.replace(/([A-Z])/g, ' $1').trim()}</span>
                        <span className="font-medium text-slate-800">{count}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-semibold text-slate-800 mb-4">Skills Tested</h3>
                <div className="flex flex-wrap gap-2">
                  {assessment.skills.map((skill, index) => (
                    <span
                      key={index}
                      className="px-4 py-2 bg-indigo-100 text-indigo-800 rounded-lg font-medium"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'questions' && (
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-slate-800 mb-6">Assessment Questions</h3>
              <p className="text-slate-600">Question details will be displayed here with full functionality in the complete implementation.</p>
            </div>
          )}

          {activeTab === 'results' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-slate-800 mb-6">Recent Results</h3>
              <div className="space-y-4">
                {recentResults.map((result) => (
                  <div
                    key={result.id}
                    className="bg-slate-50 rounded-xl p-6 hover:bg-slate-100 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <img
                          src={result.candidateAvatar}
                          alt={result.candidateName}
                          className="w-12 h-12 rounded-full border-2 border-indigo-200"
                        />
                        <div>
                          <h4 className="font-semibold text-slate-800">{result.candidateName}</h4>
                          <p className="text-sm text-slate-600">Completed on {result.completedDate}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-6">
                        <div className="text-center">
                          <p className={`text-2xl font-bold ${result.passed ? 'text-green-600' : 'text-red-600'}`}>
                            {result.score}%
                          </p>
                          <p className="text-xs text-slate-600">{result.correctAnswers}/{result.totalQuestions} correct</p>
                        </div>
                        <span className={`px-4 py-2 rounded-lg font-medium ${
                          result.passed
                            ? 'bg-green-100 text-green-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {result.passed ? 'Passed' : 'Failed'}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-slate-800 mb-6">Assessment Settings</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div>
                    <h4 className="font-semibold text-slate-800">Status</h4>
                    <p className="text-sm text-slate-600">Control assessment availability</p>
                  </div>
                  <select className="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <option>Active</option>
                    <option>Draft</option>
                    <option>Archived</option>
                  </select>
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div>
                    <h4 className="font-semibold text-slate-800">Randomize Questions</h4>
                    <p className="text-sm text-slate-600">Show questions in random order</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div>
                    <h4 className="font-semibold text-slate-800">Show Correct Answers</h4>
                    <p className="text-sm text-slate-600">Display correct answers after completion</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                  </label>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
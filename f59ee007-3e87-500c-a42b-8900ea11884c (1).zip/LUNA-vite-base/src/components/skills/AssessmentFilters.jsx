export default function AssessmentFilters({ filters, onFilterChange }) {
  const categories = [
    'All Categories',
    'Frontend Development',
    'Backend Development',
    'Database',
    'Design',
    'DevOps',
    'Data Science',
    'Project Management'
  ];

  const difficulties = ['All Levels', 'Easy', 'Intermediate', 'Advanced'];
  const statuses = ['All Status', 'Active', 'Draft'];

  const handleFilterChange = (key, value) => {
    const normalizedValue = value.startsWith('All') ? 'all' : value;
    onFilterChange({ ...filters, [key]: normalizedValue });
  };

  return (
    <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Search Assessments
          </label>
          <div className="relative">
            <input
              type="text"
              value={filters.search}
              onChange={(e) => handleFilterChange('search', e.target.value)}
              placeholder="Search by title, description, or skills..."
              className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400">
              🔍
            </span>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Category
          </label>
          <select
            value={filters.category === 'all' ? 'All Categories' : filters.category}
            onChange={(e) => handleFilterChange('category', e.target.value)}
            className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          >
            {categories.map((category) => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Difficulty
          </label>
          <select
            value={filters.difficulty === 'all' ? 'All Levels' : filters.difficulty}
            onChange={(e) => handleFilterChange('difficulty', e.target.value)}
            className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          >
            {difficulties.map((difficulty) => (
              <option key={difficulty} value={difficulty}>
                {difficulty}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <label className="block text-sm font-medium text-slate-700">
            Status
          </label>
          <div className="flex gap-2">
            {statuses.map((status) => (
              <button
                key={status}
                onClick={() => handleFilterChange('status', status)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  (filters.status === 'all' && status === 'All Status') ||
                  filters.status === status
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {status}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={() => onFilterChange({
            search: '',
            category: 'all',
            difficulty: 'all',
            status: 'all'
          })}
          className="px-4 py-2 text-slate-600 hover:text-slate-800 font-medium text-sm flex items-center space-x-2"
        >
          <span>🔄</span>
          <span>Reset Filters</span>
        </button>
      </div>
    </div>
  );
}
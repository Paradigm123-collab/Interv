export default function AssessmentPreview({ assessment }) {
  const totalPoints = assessment.questions.reduce((sum, q) => sum + q.points, 0);

  const questionTypeCount = assessment.questions.reduce((acc, q) => {
    acc[q.type] = (acc[q.type] || 0) + 1;
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-800 mb-6">Assessment Preview</h2>

      <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl p-8 border border-indigo-100">
        <h3 className="text-2xl font-bold text-slate-800 mb-2">{assessment.title}</h3>
        <p className="text-slate-700 mb-6">{assessment.description}</p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white rounded-lg p-4">
            <p className="text-sm text-slate-600 mb-1">Category</p>
            <p className="font-semibold text-slate-800">{assessment.category}</p>
          </div>
          <div className="bg-white rounded-lg p-4">
            <p className="text-sm text-slate-600 mb-1">Difficulty</p>
            <p className="font-semibold text-slate-800">{assessment.difficulty}</p>
          </div>
          <div className="bg-white rounded-lg p-4">
            <p className="text-sm text-slate-600 mb-1">Duration</p>
            <p className="font-semibold text-slate-800">{assessment.duration} min</p>
          </div>
          <div className="bg-white rounded-lg p-4">
            <p className="text-sm text-slate-600 mb-1">Passing Score</p>
            <p className="font-semibold text-slate-800">{assessment.passingScore}%</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl p-6 border border-slate-200">
        <h4 className="font-semibold text-slate-800 mb-4">Assessment Statistics</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <p className="text-sm text-slate-600 mb-1">Total Questions</p>
            <p className="text-2xl font-bold text-indigo-600">{assessment.questions.length}</p>
          </div>
          <div>
            <p className="text-sm text-slate-600 mb-1">Total Points</p>
            <p className="text-2xl font-bold text-purple-600">{totalPoints}</p>
          </div>
          <div>
            <p className="text-sm text-slate-600 mb-1">Skills Tested</p>
            <p className="text-2xl font-bold text-green-600">{assessment.skills.length}</p>
          </div>
          <div>
            <p className="text-sm text-slate-600 mb-1">Question Types</p>
            <p className="text-2xl font-bold text-blue-600">{Object.keys(questionTypeCount).length}</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl p-6 border border-slate-200">
        <h4 className="font-semibold text-slate-800 mb-4">Skills Covered</h4>
        <div className="flex flex-wrap gap-2">
          {assessment.skills.map((skill, index) => (
            <span
              key={index}
              className="px-4 py-2 bg-indigo-100 text-indigo-800 rounded-lg font-medium"
            >
              {skill}
            </span>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl p-6 border border-slate-200">
        <h4 className="font-semibold text-slate-800 mb-4">Question Breakdown</h4>
        <div className="space-y-3">
          {Object.entries(questionTypeCount).map(([type, count]) => (
            <div key={type} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <span className="text-slate-700 capitalize">{type.replace(/([A-Z])/g, ' $1').trim()}</span>
              <span className="font-semibold text-slate-800">{count} questions</span>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <span className="text-2xl">✅</span>
          <div>
            <h4 className="font-semibold text-green-900 mb-1">Ready to Save</h4>
            <p className="text-sm text-green-800">
              Your assessment is complete and ready to be saved. Click "Save Assessment" to make it available for use.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
import { useState } from 'react';

export default function QuestionBuilder({ formData, onChange }) {
  const [showAddQuestion, setShowAddQuestion] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState({
    type: 'multipleChoice',
    question: '',
    options: ['', '', '', ''],
    correctAnswer: 0,
    points: 1,
    explanation: ''
  });

  const questionTypes = [
    { id: 'multipleChoice', label: 'Multiple Choice', icon: '☑️' },
    { id: 'trueFalse', label: 'True/False', icon: '✓✗' },
    { id: 'coding', label: 'Coding Challenge', icon: '💻' }
  ];

  const handleAddQuestion = () => {
    if (currentQuestion.question.trim()) {
      onChange({
        ...formData,
        questions: [...formData.questions, { ...currentQuestion, id: Date.now() }]
      });
      setCurrentQuestion({
        type: 'multipleChoice',
        question: '',
        options: ['', '', '', ''],
        correctAnswer: 0,
        points: 1,
        explanation: ''
      });
      setShowAddQuestion(false);
    }
  };

  const handleRemoveQuestion = (questionId) => {
    onChange({
      ...formData,
      questions: formData.questions.filter(q => q.id !== questionId)
    });
  };

  const handleOptionChange = (index, value) => {
    const newOptions = [...currentQuestion.options];
    newOptions[index] = value;
    setCurrentQuestion({ ...currentQuestion, options: newOptions });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-800">Build Your Assessment</h2>
        <button
          onClick={() => setShowAddQuestion(true)}
          className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium flex items-center space-x-2"
        >
          <span>➕</span>
          <span>Add Question</span>
        </button>
      </div>

      {formData.questions.length > 0 ? (
        <div className="space-y-4">
          {formData.questions.map((question, index) => (
            <div
              key={question.id}
              className="bg-white rounded-xl p-6 border border-slate-200 hover:border-indigo-200 transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-start space-x-4 flex-1">
                  <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-lg flex items-center justify-center text-white font-bold">
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <span className="px-3 py-1 bg-indigo-100 text-indigo-800 rounded-full text-xs font-medium">
                        {questionTypes.find(t => t.id === question.type)?.label}
                      </span>
                      <span className="text-sm text-slate-600">{question.points} point(s)</span>
                    </div>
                    <p className="text-slate-800 font-medium mb-3">{question.question}</p>
                    {question.type === 'multipleChoice' && (
                      <div className="space-y-2">
                        {question.options.map((option, optIndex) => (
                          <div
                            key={optIndex}
                            className={`p-3 rounded-lg border ${
                              optIndex === question.correctAnswer
                                ? 'bg-green-50 border-green-200'
                                : 'bg-slate-50 border-slate-200'
                            }`}
                          >
                            <div className="flex items-center space-x-2">
                              {optIndex === question.correctAnswer && (
                                <span className="text-green-600">✓</span>
                              )}
                              <span className="text-sm">{option}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => handleRemoveQuestion(question.id)}
                  className="text-red-600 hover:text-red-700 p-2"
                >
                  🗑️
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-slate-50 rounded-xl p-12 text-center border-2 border-dashed border-slate-300">
          <div className="w-20 h-20 bg-slate-200 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-4xl">❓</span>
          </div>
          <h3 className="text-xl font-semibold text-slate-800 mb-2">No questions yet</h3>
          <p className="text-slate-600 mb-6">Start building your assessment by adding questions</p>
          <button
            onClick={() => setShowAddQuestion(true)}
            className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium"
          >
            Add Your First Question
          </button>
        </div>
      )}

      {showAddQuestion && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-slate-200 px-8 py-6 z-10">
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-bold text-slate-800">Add New Question</h3>
                <button
                  onClick={() => setShowAddQuestion(false)}
                  className="text-slate-400 hover:text-slate-600 transition-colors"
                >
                  <span className="text-2xl">×</span>
                </button>
              </div>
            </div>

            <div className="p-8 space-y-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Question Type
                </label>
                <div className="grid grid-cols-3 gap-4">
                  {questionTypes.map((type) => (
                    <button
                      key={type.id}
                      onClick={() => setCurrentQuestion({ ...currentQuestion, type: type.id })}
                      className={`p-4 rounded-lg border-2 transition-all ${
                        currentQuestion.type === type.id
                          ? 'border-indigo-600 bg-indigo-50'
                          : 'border-slate-200 hover:border-indigo-300'
                      }`}
                    >
                      <div className="text-2xl mb-2">{type.icon}</div>
                      <div className="text-sm font-medium">{type.label}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Question *
                </label>
                <textarea
                  value={currentQuestion.question}
                  onChange={(e) => setCurrentQuestion({ ...currentQuestion, question: e.target.value })}
                  placeholder="Enter your question..."
                  rows={3}
                  className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
                />
              </div>

              {currentQuestion.type === 'multipleChoice' && (
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Answer Options
                  </label>
                  <div className="space-y-3">
                    {currentQuestion.options.map((option, index) => (
                      <div key={index} className="flex items-center space-x-3">
                        <input
                          type="radio"
                          name="correctAnswer"
                          checked={currentQuestion.correctAnswer === index}
                          onChange={() => setCurrentQuestion({ ...currentQuestion, correctAnswer: index })}
                          className="w-5 h-5 text-indigo-600"
                        />
                        <input
                          type="text"
                          value={option}
                          onChange={(e) => handleOptionChange(index, e.target.value)}
                          placeholder={`Option ${index + 1}`}
                          className="flex-1 px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                        />
                      </div>
                    ))}
                  </div>
                  <p className="text-sm text-slate-500 mt-2">
                    💡 Select the radio button to mark the correct answer
                  </p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Points
                  </label>
                  <input
                    type="number"
                    value={currentQuestion.points}
                    onChange={(e) => setCurrentQuestion({ ...currentQuestion, points: parseInt(e.target.value) })}
                    min="1"
                    className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Explanation (Optional)
                </label>
                <textarea
                  value={currentQuestion.explanation}
                  onChange={(e) => setCurrentQuestion({ ...currentQuestion, explanation: e.target.value })}
                  placeholder="Explain the correct answer..."
                  rows={3}
                  className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
                />
              </div>
            </div>

            <div className="sticky bottom-0 bg-white border-t border-slate-200 px-8 py-6">
              <div className="flex items-center justify-end space-x-4">
                <button
                  onClick={() => setShowAddQuestion(false)}
                  className="px-6 py-3 text-slate-700 hover:bg-slate-100 rounded-lg transition-colors font-medium"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddQuestion}
                  className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium"
                >
                  Add Question
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
import { useState } from 'react';
import AssessmentCard from './AssessmentCard';
import AssessmentFilters from './AssessmentFilters';

export default function SkillsAssessmentDashboard({ onCreateAssessment, onViewAssessment, onEditAssessment }) {
  const [filters, setFilters] = useState({
    search: '',
    category: 'all',
    difficulty: 'all',
    status: 'all'
  });

  const assessments = [
    {
      id: 1,
      title: 'React Advanced Concepts',
      description: 'Comprehensive assessment covering hooks, context, performance optimization, and advanced patterns',
      category: 'Frontend Development',
      difficulty: 'Advanced',
      duration: 45,
      questionCount: 25,
      passingScore: 70,
      completions: 156,
      avgScore: 78,
      status: 'Active',
      createdBy: 'John Anderson',
      createdDate: '2024-01-15',
      lastUsed: '2 hours ago',
      skills: ['React', 'JavaScript', 'Hooks', 'Performance'],
      questionTypes: {
        multipleChoice: 15,
        coding: 5,
        trueFalse: 5
      },
      color: 'from-blue-500 to-cyan-500'
    },
    {
      id: 2,
      title: 'Python Data Structures & Algorithms',
      description: 'Test knowledge of Python data structures, algorithms, and problem-solving skills',
      category: 'Backend Development',
      difficulty: 'Intermediate',
      duration: 60,
      questionCount: 30,
      passingScore: 65,
      completions: 203,
      avgScore: 72,
      status: 'Active',
      createdBy: 'Sarah Mitchell',
      createdDate: '2024-01-10',
      lastUsed: '1 day ago',
      skills: ['Python', 'Algorithms', 'Data Structures', 'Problem Solving'],
      questionTypes: {
        multipleChoice: 20,
        coding: 8,
        trueFalse: 2
      },
      color: 'from-green-500 to-emerald-500'
    },
    {
      id: 3,
      title: 'SQL Database Fundamentals',
      description: 'Evaluate SQL query writing, database design, and optimization knowledge',
      category: 'Database',
      difficulty: 'Intermediate',
      duration: 40,
      questionCount: 20,
      passingScore: 70,
      completions: 189,
      avgScore: 75,
      status: 'Active',
      createdBy: 'Michael Chen',
      createdDate: '2024-01-20',
      lastUsed: '3 hours ago',
      skills: ['SQL', 'Database Design', 'Query Optimization', 'Indexing'],
      questionTypes: {
        multipleChoice: 12,
        coding: 6,
        trueFalse: 2
      },
      color: 'from-purple-500 to-pink-500'
    },
    {
      id: 4,
      title: 'UI/UX Design Principles',
      description: 'Assess understanding of design thinking, user research, and interface design',
      category: 'Design',
      difficulty: 'Easy',
      duration: 35,
      questionCount: 18,
      passingScore: 60,
      completions: 142,
      avgScore: 81,
      status: 'Active',
      createdBy: 'Emily Rodriguez',
      createdDate: '2024-01-18',
      lastUsed: '5 hours ago',
      skills: ['UI Design', 'UX Research', 'Design Thinking', 'Prototyping'],
      questionTypes: {
        multipleChoice: 15,
        trueFalse: 3
      },
      color: 'from-orange-500 to-red-500'
    },
    {
      id: 5,
      title: 'DevOps & Cloud Infrastructure',
      description: 'Test knowledge of CI/CD, containerization, and cloud services',
      category: 'DevOps',
      difficulty: 'Advanced',
      duration: 50,
      questionCount: 22,
      passingScore: 75,
      completions: 98,
      avgScore: 69,
      status: 'Active',
      createdBy: 'David Park',
      createdDate: '2024-01-12',
      lastUsed: '1 week ago',
      skills: ['Docker', 'Kubernetes', 'AWS', 'CI/CD', 'Terraform'],
      questionTypes: {
        multipleChoice: 14,
        coding: 6,
        trueFalse: 2
      },
      color: 'from-indigo-500 to-purple-500'
    },
    {
      id: 6,
      title: 'JavaScript ES6+ Features',
      description: 'Modern JavaScript features, async programming, and best practices',
      category: 'Frontend Development',
      difficulty: 'Intermediate',
      duration: 40,
      questionCount: 24,
      passingScore: 65,
      completions: 178,
      avgScore: 76,
      status: 'Active',
      createdBy: 'Lisa Anderson',
      createdDate: '2024-01-08',
      lastUsed: '4 hours ago',
      skills: ['JavaScript', 'ES6+', 'Async/Await', 'Promises'],
      questionTypes: {
        multipleChoice: 16,
        coding: 6,
        trueFalse: 2
      },
      color: 'from-teal-500 to-cyan-500'
    },
    {
      id: 7,
      title: 'Machine Learning Basics',
      description: 'Fundamental ML concepts, algorithms, and practical applications',
      category: 'Data Science',
      difficulty: 'Advanced',
      duration: 55,
      questionCount: 28,
      passingScore: 70,
      completions: 87,
      avgScore: 71,
      status: 'Draft',
      createdBy: 'James Wilson',
      createdDate: '2024-01-22',
      lastUsed: 'Never',
      skills: ['Machine Learning', 'Python', 'Statistics', 'Neural Networks'],
      questionTypes: {
        multipleChoice: 20,
        coding: 5,
        trueFalse: 3
      },
      color: 'from-pink-500 to-rose-500'
    },
    {
      id: 8,
      title: 'Agile & Scrum Methodology',
      description: 'Test understanding of agile principles, scrum framework, and team practices',
      category: 'Project Management',
      difficulty: 'Easy',
      duration: 30,
      questionCount: 15,
      passingScore: 60,
      completions: 234,
      avgScore: 83,
      status: 'Active',
      createdBy: 'Maria Garcia',
      createdDate: '2024-01-14',
      lastUsed: '6 hours ago',
      skills: ['Agile', 'Scrum', 'Project Management', 'Team Collaboration'],
      questionTypes: {
        multipleChoice: 12,
        trueFalse: 3
      },
      color: 'from-amber-500 to-yellow-500'
    }
  ];

  const filteredAssessments = assessments.filter(assessment => {
    const matchesSearch = filters.search === '' ||
      assessment.title.toLowerCase().includes(filters.search.toLowerCase()) ||
      assessment.description.toLowerCase().includes(filters.search.toLowerCase()) ||
      assessment.skills.some(skill => skill.toLowerCase().includes(filters.search.toLowerCase()));
    
    const matchesCategory = filters.category === 'all' || assessment.category === filters.category;
    const matchesDifficulty = filters.difficulty === 'all' || assessment.difficulty === filters.difficulty;
    const matchesStatus = filters.status === 'all' || assessment.status === filters.status;

    return matchesSearch && matchesCategory && matchesDifficulty && matchesStatus;
  });

  const stats = {
    total: assessments.length,
    active: assessments.filter(a => a.status === 'Active').length,
    draft: assessments.filter(a => a.status === 'Draft').length,
    totalCompletions: assessments.reduce((sum, a) => sum + a.completions, 0),
    avgScore: Math.round(assessments.reduce((sum, a) => sum + a.avgScore, 0) / assessments.length)
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Total Assessments</p>
              <p className="text-3xl font-bold text-slate-800">{stats.total}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">🎯</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Active</p>
              <p className="text-3xl font-bold text-green-600">{stats.active}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">✅</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Draft</p>
              <p className="text-3xl font-bold text-amber-600">{stats.draft}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-yellow-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">📝</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Completions</p>
              <p className="text-3xl font-bold text-indigo-600">{stats.totalCompletions}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">📊</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Avg Score</p>
              <p className="text-3xl font-bold text-purple-600">{stats.avgScore}%</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">⭐</span>
            </div>
          </div>
        </div>
      </div>

      <AssessmentFilters filters={filters} onFilterChange={setFilters} />

      {filteredAssessments.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAssessments.map(assessment => (
            <AssessmentCard
              key={assessment.id}
              assessment={assessment}
              onView={onViewAssessment}
              onEdit={onEditAssessment}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl p-12 text-center shadow-lg border border-slate-100">
          <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-4xl">🔍</span>
          </div>
          <h3 className="text-xl font-semibold text-slate-800 mb-2">No assessments found</h3>
          <p className="text-slate-600 mb-6">Try adjusting your filters or create a new assessment</p>
          <button
            onClick={onCreateAssessment}
            className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium"
          >
            Create Your First Assessment
          </button>
        </div>
      )}
    </div>
  );
}
import { useState } from 'react';
import TemplateCard from './TemplateCard';
import TemplateFilters from './TemplateFilters';

export default function TemplateBuilderDashboard({ onCreateTemplate, onViewTemplate, onEditTemplate }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [sortBy, setSortBy] = useState('recent');

  const templates = [
    {
      id: 1,
      name: 'Senior Developer Technical Assessment',
      description: 'Comprehensive technical evaluation for senior engineering positions',
      category: 'Technical',
      role: 'Senior Developer',
      questionCount: 12,
      duration: 90,
      usageCount: 45,
      avgScore: 8.2,
      createdBy: 'John Anderson',
      createdDate: '2024-01-15',
      lastUsed: '2 days ago',
      isActive: true,
      sections: [
        { name: 'Coding Challenge', questions: 4, duration: 30 },
        { name: 'System Design', questions: 3, duration: 25 },
        { name: 'Behavioral', questions: 5, duration: 35 }
      ],
      color: 'from-blue-500 to-cyan-500'
    },
    {
      id: 2,
      name: 'Product Manager Interview Framework',
      description: 'Structured interview for product management roles',
      category: 'Product',
      role: 'Product Manager',
      questionCount: 10,
      duration: 75,
      usageCount: 32,
      avgScore: 7.8,
      createdBy: 'Sarah Mitchell',
      createdDate: '2024-01-10',
      lastUsed: '1 week ago',
      isActive: true,
      sections: [
        { name: 'Product Strategy', questions: 4, duration: 30 },
        { name: 'Leadership', questions: 3, duration: 20 },
        { name: 'Case Study', questions: 3, duration: 25 }
      ],
      color: 'from-purple-500 to-pink-500'
    },
    {
      id: 3,
      name: 'UX Designer Portfolio Review',
      description: 'Design thinking and portfolio evaluation template',
      category: 'Design',
      role: 'UX Designer',
      questionCount: 8,
      duration: 60,
      usageCount: 28,
      avgScore: 8.5,
      createdBy: 'Emily Rodriguez',
      createdDate: '2024-01-20',
      lastUsed: '3 days ago',
      isActive: true,
      sections: [
        { name: 'Portfolio Review', questions: 3, duration: 25 },
        { name: 'Design Process', questions: 3, duration: 20 },
        { name: 'Collaboration', questions: 2, duration: 15 }
      ],
      color: 'from-green-500 to-emerald-500'
    },
    {
      id: 4,
      name: 'DevOps Engineer Assessment',
      description: 'Infrastructure and automation skills evaluation',
      category: 'Technical',
      role: 'DevOps Engineer',
      questionCount: 15,
      duration: 100,
      usageCount: 38,
      avgScore: 7.9,
      createdBy: 'Michael Chen',
      createdDate: '2024-01-08',
      lastUsed: '5 days ago',
      isActive: true,
      sections: [
        { name: 'Infrastructure', questions: 5, duration: 35 },
        { name: 'CI/CD', questions: 5, duration: 30 },
        { name: 'Problem Solving', questions: 5, duration: 35 }
      ],
      color: 'from-orange-500 to-red-500'
    },
    {
      id: 5,
      name: 'Data Scientist Evaluation',
      description: 'ML and statistical analysis assessment',
      category: 'Technical',
      role: 'Data Scientist',
      questionCount: 11,
      duration: 85,
      usageCount: 25,
      avgScore: 8.1,
      createdBy: 'David Park',
      createdDate: '2024-01-12',
      lastUsed: '1 week ago',
      isActive: true,
      sections: [
        { name: 'Statistics', questions: 4, duration: 30 },
        { name: 'ML Algorithms', questions: 4, duration: 30 },
        { name: 'Case Study', questions: 3, duration: 25 }
      ],
      color: 'from-indigo-500 to-purple-500'
    },
    {
      id: 6,
      name: 'Marketing Manager Interview',
      description: 'Marketing strategy and campaign evaluation',
      category: 'Marketing',
      role: 'Marketing Manager',
      questionCount: 9,
      duration: 70,
      usageCount: 22,
      avgScore: 7.6,
      createdBy: 'Lisa Anderson',
      createdDate: '2024-01-18',
      lastUsed: '4 days ago',
      isActive: false,
      sections: [
        { name: 'Strategy', questions: 3, duration: 25 },
        { name: 'Analytics', questions: 3, duration: 20 },
        { name: 'Leadership', questions: 3, duration: 25 }
      ],
      color: 'from-pink-500 to-rose-500'
    },
    {
      id: 7,
      name: 'Sales Executive Assessment',
      description: 'Sales skills and relationship building evaluation',
      category: 'Sales',
      role: 'Sales Executive',
      questionCount: 10,
      duration: 65,
      usageCount: 35,
      avgScore: 8.0,
      createdBy: 'James Wilson',
      createdDate: '2024-01-14',
      lastUsed: '1 day ago',
      isActive: true,
      sections: [
        { name: 'Sales Process', questions: 4, duration: 25 },
        { name: 'Negotiation', questions: 3, duration: 20 },
        { name: 'Relationship Building', questions: 3, duration: 20 }
      ],
      color: 'from-teal-500 to-cyan-500'
    },
    {
      id: 8,
      name: 'Content Writer Evaluation',
      description: 'Writing skills and creativity assessment',
      category: 'Content',
      role: 'Content Writer',
      questionCount: 7,
      duration: 55,
      usageCount: 18,
      avgScore: 7.7,
      createdBy: 'Maria Garcia',
      createdDate: '2024-01-22',
      lastUsed: '6 days ago',
      isActive: true,
      sections: [
        { name: 'Writing Sample', questions: 3, duration: 25 },
        { name: 'SEO Knowledge', questions: 2, duration: 15 },
        { name: 'Creativity', questions: 2, duration: 15 }
      ],
      color: 'from-amber-500 to-yellow-500'
    }
  ];

  const filteredTemplates = templates.filter(template => {
    const matchesSearch = searchQuery === '' ||
      template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.role.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = categoryFilter === 'all' || template.category === categoryFilter;
    
    return matchesSearch && matchesCategory;
  });

  const sortedTemplates = [...filteredTemplates].sort((a, b) => {
    switch (sortBy) {
      case 'recent':
        return b.id - a.id;
      case 'usage':
        return b.usageCount - a.usageCount;
      case 'score':
        return b.avgScore - a.avgScore;
      case 'name':
        return a.name.localeCompare(b.name);
      default:
        return 0;
    }
  });

  const stats = {
    total: templates.length,
    active: templates.filter(t => t.isActive).length,
    inactive: templates.filter(t => !t.isActive).length,
    totalUsage: templates.reduce((sum, t) => sum + t.usageCount, 0),
    avgScore: (templates.reduce((sum, t) => sum + t.avgScore, 0) / templates.length).toFixed(1)
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Total Templates</p>
              <p className="text-3xl font-bold text-slate-800">{stats.total}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">📋</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Active</p>
              <p className="text-3xl font-bold text-green-600">{stats.active}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">✅</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Inactive</p>
              <p className="text-3xl font-bold text-slate-600">{stats.inactive}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-slate-500 to-slate-600 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">⏸️</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Total Usage</p>
              <p className="text-3xl font-bold text-indigo-600">{stats.totalUsage}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">📊</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Avg Score</p>
              <p className="text-3xl font-bold text-purple-600">{stats.avgScore}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">⭐</span>
            </div>
          </div>
        </div>
      </div>

      <TemplateFilters
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        categoryFilter={categoryFilter}
        onCategoryChange={setCategoryFilter}
        sortBy={sortBy}
        onSortChange={setSortBy}
      />

      {sortedTemplates.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sortedTemplates.map(template => (
            <TemplateCard
              key={template.id}
              template={template}
              onView={onViewTemplate}
              onEdit={onEditTemplate}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl p-12 text-center shadow-lg border border-slate-100">
          <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-4xl">🔍</span>
          </div>
          <h3 className="text-xl font-semibold text-slate-800 mb-2">No templates found</h3>
          <p className="text-slate-600 mb-6">Try adjusting your search or filters</p>
          <button
            onClick={onCreateTemplate}
            className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium"
          >
            Create Your First Template
          </button>
        </div>
      )}
    </div>
  );
}
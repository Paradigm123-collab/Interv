import { useState } from 'react';
import TemplateBasicInfo from './TemplateBasicInfo';
import TemplateQuestionBuilder from './TemplateQuestionBuilder';
import TemplatePreview from './TemplatePreview';

export default function TemplateBuilderWizard({ template, onBack, onSave }) {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState(template || {
    name: '',
    description: '',
    category: 'Technical',
    role: '',
    duration: 60,
    sections: [],
    isActive: true
  });

  const steps = [
    { id: 1, label: 'Basic Info', icon: '📋' },
    { id: 2, label: 'Build Template', icon: '🔨' },
    { id: 3, label: 'Preview & Save', icon: '👁️' }
  ];

  const handleNext = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSave = () => {
    const savedTemplate = {
      ...formData,
      id: template?.id || Date.now(),
      createdBy: 'Current User',
      createdDate: new Date().toISOString().split('T')[0],
      lastUsed: 'Never',
      usageCount: template?.usageCount || 0,
      avgScore: template?.avgScore || 0,
      questionCount: formData.sections.reduce((sum, section) => sum + section.questions.length, 0),
      color: 'from-indigo-500 to-purple-500'
    };
    onSave(savedTemplate);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100">
        <div className="flex items-center justify-between mb-8">
          {steps.map((step, index) => (
            <div key={step.id} className="flex items-center flex-1">
              <div className={`flex items-center justify-center w-12 h-12 rounded-full font-bold transition-all ${
                currentStep >= step.id
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
                  : 'bg-slate-200 text-slate-500'
              }`}>
                <span className="text-xl">{step.icon}</span>
              </div>
              {index < steps.length - 1 && (
                <div className={`flex-1 h-1 mx-4 rounded transition-all ${
                  currentStep > step.id ? 'bg-gradient-to-r from-indigo-600 to-purple-600' : 'bg-slate-200'
                }`}></div>
              )}
            </div>
          ))}
        </div>

        <div className="flex justify-between mb-8">
          {steps.map(step => (
            <span
              key={step.id}
              className={`text-sm font-medium ${
                currentStep >= step.id ? 'text-indigo-600' : 'text-slate-500'
              }`}
            >
              {step.label}
            </span>
          ))}
        </div>

        {currentStep === 1 && (
          <TemplateBasicInfo
            formData={formData}
            onChange={setFormData}
          />
        )}

        {currentStep === 2 && (
          <TemplateQuestionBuilder
            formData={formData}
            onChange={setFormData}
          />
        )}

        {currentStep === 3 && (
          <TemplatePreview
            template={formData}
          />
        )}

        <div className="flex items-center justify-between mt-8 pt-6 border-t border-slate-200">
          <button
            onClick={currentStep === 1 ? onBack : handlePrevious}
            className="px-6 py-3 text-slate-700 hover:bg-slate-100 rounded-lg transition-colors font-medium"
          >
            {currentStep === 1 ? '← Back to Templates' : '← Previous'}
          </button>

          {currentStep < 3 ? (
            <button
              onClick={handleNext}
              className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg font-medium"
            >
              Next →
            </button>
          ) : (
            <button
              onClick={handleSave}
              className="px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all duration-200 shadow-lg font-medium flex items-center space-x-2"
            >
              <span>✓</span>
              <span>Save Template</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
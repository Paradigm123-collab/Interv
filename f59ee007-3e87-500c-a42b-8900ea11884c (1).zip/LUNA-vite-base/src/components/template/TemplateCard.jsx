export default function TemplateCard({ template, onView, onEdit }) {
  return (
    <div
      onClick={() => onView(template)}
      className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-slate-100 cursor-pointer group hover:scale-105 active:scale-95"
    >
      <div className="flex items-start justify-between mb-4">
        <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${template.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
          <span className="text-white text-2xl">📋</span>
        </div>
        <div className="flex items-center space-x-2">
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
            template.isActive
              ? 'bg-green-100 text-green-800'
              : 'bg-slate-100 text-slate-800'
          }`}>
            {template.isActive ? 'Active' : 'Inactive'}
          </span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onEdit(template);
            }}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <span className="text-slate-600">✏️</span>
          </button>
        </div>
      </div>

      <h3 className="font-bold text-slate-800 mb-2 line-clamp-2 group-hover:text-indigo-600 transition-colors">
        {template.name}
      </h3>
      <p className="text-sm text-slate-600 mb-4 line-clamp-2">{template.description}</p>

      <div className="space-y-2 mb-4">
        <div className="flex items-center justify-between text-sm">
          <span className="text-slate-600">Role</span>
          <span className="font-medium text-slate-800">{template.role}</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-slate-600">Questions</span>
          <span className="font-medium text-slate-800">{template.questionCount}</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-slate-600">Duration</span>
          <span className="font-medium text-slate-800">{template.duration} min</span>
        </div>
      </div>

      <div className="pt-4 border-t border-slate-100">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center space-x-1 text-slate-600">
            <span>📊</span>
            <span>Used {template.usageCount} times</span>
          </div>
          <div className="flex items-center space-x-1 text-green-600 font-medium">
            <span>⭐</span>
            <span>{template.avgScore}/10</span>
          </div>
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-slate-100">
        <div className="flex items-center justify-between text-xs text-slate-500">
          <span>By {template.createdBy}</span>
          <span>Used {template.lastUsed}</span>
        </div>
      </div>
    </div>
  );
}
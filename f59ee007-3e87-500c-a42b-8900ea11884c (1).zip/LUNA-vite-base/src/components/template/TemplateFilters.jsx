export default function TemplateFilters({
  searchQuery,
  onSearchChange,
  categoryFilter,
  onCategoryChange,
  sortBy,
  onSortChange
}) {
  const categories = [
    'All Categories',
    'Technical',
    'Product',
    'Design',
    'Marketing',
    'Sales',
    'Content'
  ];

  return (
    <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Search Templates
          </label>
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search by name, role, or description..."
              className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400">
              🔍
            </span>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Category
          </label>
          <select
            value={categoryFilter === 'all' ? 'All Categories' : categoryFilter}
            onChange={(e) => onCategoryChange(e.target.value === 'All Categories' ? 'all' : e.target.value)}
            className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          >
            {categories.map(category => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Sort By
          </label>
          <select
            value={sortBy}
            onChange={(e) => onSortChange(e.target.value)}
            className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          >
            <option value="recent">Most Recent</option>
            <option value="usage">Most Used</option>
            <option value="score">Highest Score</option>
            <option value="name">Name (A-Z)</option>
          </select>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className="text-sm text-slate-600">Quick Filters:</span>
          <button
            onClick={() => onCategoryChange('Technical')}
            className="px-3 py-1 bg-blue-100 text-blue-800 rounded-lg text-sm font-medium hover:bg-blue-200 transition-colors"
          >
            Technical
          </button>
          <button
            onClick={() => onCategoryChange('Product')}
            className="px-3 py-1 bg-purple-100 text-purple-800 rounded-lg text-sm font-medium hover:bg-purple-200 transition-colors"
          >
            Product
          </button>
          <button
            onClick={() => onCategoryChange('Design')}
            className="px-3 py-1 bg-green-100 text-green-800 rounded-lg text-sm font-medium hover:bg-green-200 transition-colors"
          >
            Design
          </button>
        </div>

        <button
          onClick={() => {
            onSearchChange('');
            onCategoryChange('all');
            onSortChange('recent');
          }}
          className="px-4 py-2 text-slate-600 hover:text-slate-800 font-medium text-sm flex items-center space-x-2"
        >
          <span>🔄</span>
          <span>Reset Filters</span>
        </button>
      </div>
    </div>
  );
}
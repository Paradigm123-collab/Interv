import { useState, useRef, useEffect } from 'react';

export default function VideoPlayerModal({ recording, onClose }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [showControls, setShowControls] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showTranscript, setShowTranscript] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);
  
  const videoRef = useRef(null);
  const containerRef = useRef(null);
  const controlsTimeoutRef = useRef(null);

  useEffect(() => {
    const handleKeyPress = (e) => {
      if (e.code === 'Space') {
        e.preventDefault();
        togglePlay();
      } else if (e.code === 'Escape') {
        onClose();
      } else if (e.code === 'KeyF') {
        toggleFullscreen();
      } else if (e.code === 'KeyM') {
        toggleMute();
      }
    };

    document.addEventListener('keydown', handleKeyPress);
    return () => document.removeEventListener('keydown', handleKeyPress);
  }, [isPlaying]);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  };

  const handleSeek = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    const time = pos * duration;
    if (videoRef.current) {
      videoRef.current.currentTime = time;
      setCurrentTime(time);
    }
  };

  const handleVolumeChange = (e) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    if (videoRef.current) {
      videoRef.current.volume = newVolume;
    }
    setIsMuted(newVolume === 0);
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const changePlaybackRate = (rate) => {
    setPlaybackRate(rate);
    if (videoRef.current) {
      videoRef.current.playbackRate = rate;
    }
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) {
        setShowControls(false);
      }
    }, 3000);
  };

  const mockTranscript = [
    { time: '00:00', speaker: 'Interviewer', text: 'Good afternoon! Thank you for joining us today. Could you start by telling us about yourself?' },
    { time: '00:15', speaker: recording.candidateName, text: 'Thank you for having me. I\'m a senior developer with 8 years of experience in React and modern web technologies.' },
    { time: '00:35', speaker: 'Interviewer', text: 'That\'s impressive. Can you walk us through your most challenging project?' },
    { time: '00:45', speaker: recording.candidateName, text: 'Certainly. I led the development of a real-time collaboration platform that serves over 100,000 users...' }
  ];

  const mockAnalytics = {
    engagement: 92,
    clarity: 88,
    confidence: 85,
    technicalDepth: 90,
    keyMoments: [
      { time: '05:23', label: 'Strong Technical Answer', score: 95 },
      { time: '12:45', label: 'Problem-Solving Approach', score: 88 },
      { time: '18:30', label: 'Leadership Example', score: 92 }
    ]
  };

  return (
    <div className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center">
      <div 
        ref={containerRef}
        className="w-full h-full flex flex-col"
        onMouseMove={handleMouseMove}
      >
        {/* Header */}
        <div className={`bg-gradient-to-b from-black/80 to-transparent p-6 transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <img
                src={recording.candidateAvatar}
                alt={recording.candidateName}
                className="w-12 h-12 rounded-full border-2 border-white"
              />
              <div>
                <h2 className="text-xl font-bold text-white">{recording.candidateName}</h2>
                <p className="text-sm text-slate-300">{recording.position} • {recording.company}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center transition-colors"
            >
              <span className="text-white text-xl">✕</span>
            </button>
          </div>
        </div>

        {/* Video Container */}
        <div className="flex-1 flex items-center justify-center relative">
          <video
            ref={videoRef}
            className="max-w-full max-h-full"
            onTimeUpdate={handleTimeUpdate}
            onLoadedMetadata={handleLoadedMetadata}
            poster={recording.thumbnail}
          >
            <source src="#" type="video/mp4" />
          </video>

          {/* Play/Pause Overlay */}
          {!isPlaying && (
            <button
              onClick={togglePlay}
              className="absolute inset-0 flex items-center justify-center"
            >
              <div className="w-20 h-20 bg-white/90 rounded-full flex items-center justify-center hover:scale-110 transition-transform shadow-2xl">
                <span className="text-4xl ml-2">▶️</span>
              </div>
            </button>
          )}

          {/* Side Panels */}
          {showTranscript && (
            <div className="absolute right-0 top-0 bottom-0 w-96 bg-black/90 backdrop-blur-sm p-6 overflow-y-auto">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-white">📝 Transcript</h3>
                <button
                  onClick={() => setShowTranscript(false)}
                  className="text-white hover:text-slate-300"
                >
                  ✕
                </button>
              </div>
              <div className="space-y-4">
                {mockTranscript.map((item, index) => (
                  <div key={index} className="bg-white/10 rounded-lg p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-medium text-indigo-400">{item.time}</span>
                      <span className="text-xs font-medium text-slate-300">{item.speaker}</span>
                    </div>
                    <p className="text-sm text-white">{item.text}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {showAnalytics && (
            <div className="absolute right-0 top-0 bottom-0 w-96 bg-black/90 backdrop-blur-sm p-6 overflow-y-auto">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-white">📊 Analytics</h3>
                <button
                  onClick={() => setShowAnalytics(false)}
                  className="text-white hover:text-slate-300"
                >
                  ✕
                </button>
              </div>
              <div className="space-y-6">
                <div className="bg-white/10 rounded-lg p-4">
                  <h4 className="text-sm font-medium text-slate-300 mb-3">Performance Metrics</h4>
                  <div className="space-y-3">
                    {Object.entries(mockAnalytics).filter(([key]) => key !== 'keyMoments').map(([key, value]) => (
                      <div key={key}>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs text-slate-300 capitalize">{key}</span>
                          <span className="text-xs font-bold text-white">{value}</span>
                        </div>
                        <div className="w-full bg-white/20 rounded-full h-2">
                          <div
                            className="h-2 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full"
                            style={{ width: `${value}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="bg-white/10 rounded-lg p-4">
                  <h4 className="text-sm font-medium text-slate-300 mb-3">Key Moments</h4>
                  <div className="space-y-2">
                    {mockAnalytics.keyMoments.map((moment, index) => (
                      <div key={index} className="bg-white/10 rounded p-2">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs text-indigo-400">{moment.time}</span>
                          <span className="text-xs font-bold text-green-400">{moment.score}</span>
                        </div>
                        <p className="text-xs text-white">{moment.label}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Controls */}
        <div className={`bg-gradient-to-t from-black/80 to-transparent p-6 transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
          {/* Progress Bar */}
          <div 
            className="w-full h-2 bg-white/20 rounded-full mb-4 cursor-pointer group"
            onClick={handleSeek}
          >
            <div 
              className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full relative group-hover:h-3 transition-all"
              style={{ width: `${(currentTime / duration) * 100}%` }}
            >
              <div className="absolute right-0 top-1/2 transform -translate-y-1/2 w-4 h-4 bg-white rounded-full shadow-lg opacity-0 group-hover:opacity-100"></div>
            </div>
          </div>

          {/* Control Buttons */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              {/* Play/Pause */}
              <button
                onClick={togglePlay}
                className="w-12 h-12 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center transition-colors"
              >
                <span className="text-white text-xl">{isPlaying ? '⏸️' : '▶️'}</span>
              </button>

              {/* Volume */}
              <div className="flex items-center space-x-2">
                <button
                  onClick={toggleMute}
                  className="w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center transition-colors"
                >
                  <span className="text-white">{isMuted || volume === 0 ? '🔇' : volume < 0.5 ? '🔉' : '🔊'}</span>
                </button>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={volume}
                  onChange={handleVolumeChange}
                  className="w-24"
                />
              </div>

              {/* Time */}
              <span className="text-white text-sm font-medium">
                {formatTime(currentTime)} / {formatTime(duration)}
              </span>

              {/* Playback Speed */}
              <select
                value={playbackRate}
                onChange={(e) => changePlaybackRate(parseFloat(e.target.value))}
                className="bg-white/20 text-white px-3 py-1 rounded-lg text-sm"
              >
                <option value="0.5">0.5x</option>
                <option value="0.75">0.75x</option>
                <option value="1">1x</option>
                <option value="1.25">1.25x</option>
                <option value="1.5">1.5x</option>
                <option value="2">2x</option>
              </select>
            </div>

            <div className="flex items-center space-x-2">
              {/* Transcript */}
              {recording.hasTranscript && (
                <button
                  onClick={() => {
                    setShowTranscript(!showTranscript);
                    setShowAnalytics(false);
                  }}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    showTranscript
                      ? 'bg-indigo-600 text-white'
                      : 'bg-white/20 text-white hover:bg-white/30'
                  }`}
                >
                  📝 Transcript
                </button>
              )}

              {/* Analytics */}
              {recording.hasAnalytics && (
                <button
                  onClick={() => {
                    setShowAnalytics(!showAnalytics);
                    setShowTranscript(false);
                  }}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    showAnalytics
                      ? 'bg-purple-600 text-white'
                      : 'bg-white/20 text-white hover:bg-white/30'
                  }`}
                >
                  📊 Analytics
                </button>
              )}

              {/* Fullscreen */}
              <button
                onClick={toggleFullscreen}
                className="w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center transition-colors"
              >
                <span className="text-white">{isFullscreen ? '⛶' : '⛶'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
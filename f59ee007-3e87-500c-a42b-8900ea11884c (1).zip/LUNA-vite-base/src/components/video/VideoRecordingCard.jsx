export default function VideoRecordingCard({ recording, onPlay }) {
  const getStatusColor = (status) => {
    switch (status) {
      case 'Available':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Processing':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Archived':
        return 'bg-slate-100 text-slate-800 border-slate-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const handleDownload = (e) => {
    e.stopPropagation();
    alert(`Downloading recording for ${recording.candidateName}...\n\nFile: ${recording.position}_${recording.interviewDate}.mp4\nSize: ${recording.size}\nQuality: ${recording.quality}\n\nDownload will start with backend integration!`);
  };

  const handleShare = (e) => {
    e.stopPropagation();
    alert(`Share recording with team members:\n\nCandidate: ${recording.candidateName}\nPosition: ${recording.position}\nDate: ${recording.interviewDate}\n\nSharing options will be available with backend integration!`);
  };

  const handleDelete = (e) => {
    e.stopPropagation();
    if (confirm(`Are you sure you want to delete this recording?\n\nCandidate: ${recording.candidateName}\nThis action cannot be undone.`)) {
      alert('Recording deletion will be implemented with backend integration!');
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden hover:shadow-xl transition-all duration-300 group">
      {/* Thumbnail */}
      <div className="relative aspect-video bg-slate-900 overflow-hidden">
        <img
          src={recording.thumbnail}
          alt={recording.candidateName}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        
        {/* Play Overlay */}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <button
            onClick={() => onPlay(recording)}
            className="w-16 h-16 bg-white rounded-full flex items-center justify-center hover:scale-110 transition-transform shadow-2xl"
          >
            <span className="text-3xl ml-1">▶️</span>
          </button>
        </div>

        {/* Duration Badge */}
        <div className="absolute bottom-3 right-3 bg-black/80 backdrop-blur-sm px-3 py-1 rounded-lg">
          <span className="text-white text-sm font-medium">{recording.duration}</span>
        </div>

        {/* Status Badge */}
        <div className="absolute top-3 left-3">
          <span className={`px-3 py-1 rounded-lg text-xs font-medium border ${getStatusColor(recording.status)}`}>
            {recording.status}
          </span>
        </div>

        {/* Quality Badge */}
        <div className="absolute top-3 right-3 bg-indigo-600 px-3 py-1 rounded-lg">
          <span className="text-white text-xs font-bold">{recording.quality}</span>
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {/* Candidate Info */}
        <div className="flex items-center space-x-3 mb-4">
          <img
            src={recording.candidateAvatar}
            alt={recording.candidateName}
            className="w-12 h-12 rounded-full border-2 border-slate-100"
          />
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-slate-800 truncate">{recording.candidateName}</h3>
            <p className="text-sm text-slate-600 truncate">{recording.position}</p>
          </div>
        </div>

        {/* Details */}
        <div className="space-y-2 mb-4">
          <div className="flex items-center text-sm text-slate-600">
            <span className="mr-2">🏢</span>
            <span className="truncate">{recording.company}</span>
          </div>
          <div className="flex items-center text-sm text-slate-600">
            <span className="mr-2">📅</span>
            <span>{recording.interviewDate} at {recording.interviewTime}</span>
          </div>
          <div className="flex items-center text-sm text-slate-600">
            <span className="mr-2">{recording.type === 'AI' ? '🤖' : '👨‍💼'}</span>
            <span>{recording.type} Interview - {recording.recordedBy}</span>
          </div>
          <div className="flex items-center text-sm text-slate-600">
            <span className="mr-2">👁️</span>
            <span>{recording.views} views • Last viewed {recording.lastViewed}</span>
          </div>
        </div>

        {/* Features */}
        <div className="flex items-center space-x-2 mb-4">
          {recording.hasTranscript && (
            <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs font-medium">
              📝 Transcript
            </span>
          )}
          {recording.hasAnalytics && (
            <span className="px-2 py-1 bg-purple-100 text-purple-800 rounded text-xs font-medium">
              📊 Analytics
            </span>
          )}
          <span className="px-2 py-1 bg-slate-100 text-slate-800 rounded text-xs font-medium">
            💾 {recording.size}
            </span>
        </div>

        {/* Actions */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => onPlay(recording)}
            className="flex-1 px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 font-medium text-sm"
          >
            ▶️ Play
          </button>
          <button
            onClick={handleDownload}
            className="px-4 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors text-sm font-medium"
            title="Download"
          >
            ⬇️
          </button>
          <button
            onClick={handleShare}
            className="px-4 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors text-sm font-medium"
            title="Share"
          >
            🔗
          </button>
          <button
            onClick={handleDelete}
            className="px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors text-sm font-medium"
            title="Delete"
          >
            🗑️
          </button>
        </div>
      </div>
    </div>
  );
}
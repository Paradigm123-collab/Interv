import { useState } from 'react';
import VideoRecordingCard from './VideoRecordingCard';
import VideoRecordingsFilters from './VideoRecordingsFilters';

export default function VideoRecordingsList({ currentRole, onPlayRecording }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterType, setFilterType] = useState('all');
  const [sortBy, setSortBy] = useState('recent');

  const allRecordings = [
    {
      id: 1,
      candidateName: 'Sarah Mitchell',
      candidateAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      position: 'Senior React Developer',
      company: 'TechCorp Solutions',
      interviewDate: '2024-12-28',
      interviewTime: '14:00',
      duration: '45:32',
      type: 'AI',
      status: 'Available',
      quality: '1080p',
      size: '2.3 GB',
      thumbnail: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=400&h=225&fit=crop',
      views: 3,
      lastViewed: '2 hours ago',
      recordedBy: 'AI System',
      hasTranscript: true,
      hasAnalytics: true
    },
    {
      id: 2,
      candidateName: 'Michael Chen',
      candidateAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      position: 'Full Stack Engineer',
      company: 'Innovation Labs',
      interviewDate: '2024-12-27',
      interviewTime: '10:00',
      duration: '58:15',
      type: 'Human',
      status: 'Available',
      quality: '1080p',
      size: '3.1 GB',
      thumbnail: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=400&h=225&fit=crop',
      views: 5,
      lastViewed: '1 day ago',
      recordedBy: 'Dr. Sarah Johnson',
      hasTranscript: true,
      hasAnalytics: true
    },
    {
      id: 3,
      candidateName: 'Emily Rodriguez',
      candidateAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
      position: 'Frontend Developer',
      company: 'Digital Dynamics',
      interviewDate: '2024-12-26',
      interviewTime: '15:30',
      duration: '32:48',
      type: 'AI',
      status: 'Processing',
      quality: '1080p',
      size: '1.8 GB',
      thumbnail: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=400&h=225&fit=crop',
      views: 0,
      lastViewed: 'Never',
      recordedBy: 'AI System',
      hasTranscript: false,
      hasAnalytics: false
    },
    {
      id: 4,
      candidateName: 'David Park',
      candidateAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
      position: 'UI/UX Designer',
      company: 'Creative Studios',
      interviewDate: '2024-12-25',
      interviewTime: '11:00',
      duration: '42:20',
      type: 'Human',
      status: 'Available',
      quality: '720p',
      size: '1.5 GB',
      thumbnail: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=400&h=225&fit=crop',
      views: 8,
      lastViewed: '3 days ago',
      recordedBy: 'Mark Wilson',
      hasTranscript: true,
      hasAnalytics: true
    },
    {
      id: 5,
      candidateName: 'Lisa Anderson',
      candidateAvatar: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop',
      position: 'Product Manager',
      company: 'StartupHub Inc',
      interviewDate: '2024-12-24',
      interviewTime: '13:00',
      duration: '55:10',
      type: 'AI',
      status: 'Available',
      quality: '1080p',
      size: '2.9 GB',
      thumbnail: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=400&h=225&fit=crop',
      views: 12,
      lastViewed: '5 days ago',
      recordedBy: 'AI System',
      hasTranscript: true,
      hasAnalytics: true
    },
    {
      id: 6,
      candidateName: 'James Wilson',
      candidateAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop',
      position: 'DevOps Engineer',
      company: 'CloudTech Systems',
      interviewDate: '2024-12-23',
      interviewTime: '09:00',
      duration: '48:35',
      type: 'Human',
      status: 'Archived',
      quality: '1080p',
      size: '2.6 GB',
      thumbnail: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=400&h=225&fit=crop',
      views: 6,
      lastViewed: '1 week ago',
      recordedBy: 'Emily Chen',
      hasTranscript: true,
      hasAnalytics: true
    },
    {
      id: 7,
      candidateName: 'Maria Garcia',
      candidateAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop',
      position: 'Data Scientist',
      company: 'Analytics Pro',
      interviewDate: '2024-12-22',
      interviewTime: '14:30',
      duration: '51:45',
      type: 'AI',
      status: 'Available',
      quality: '1080p',
      size: '2.7 GB',
      thumbnail: 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=400&h=225&fit=crop',
      views: 4,
      lastViewed: '1 week ago',
      recordedBy: 'AI System',
      hasTranscript: true,
      hasAnalytics: true
    },
    {
      id: 8,
      candidateName: 'Robert Taylor',
      candidateAvatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop',
      position: 'Backend Developer',
      company: 'ServerTech Inc',
      interviewDate: '2024-12-21',
      interviewTime: '16:00',
      duration: '39:28',
      type: 'Human',
      status: 'Available',
      quality: '720p',
      size: '1.4 GB',
      thumbnail: 'https://images.unsplash.com/photo-1572044162444-ad60f128bdea?w=400&h=225&fit=crop',
      views: 7,
      lastViewed: '2 weeks ago',
      recordedBy: 'John Anderson',
      hasTranscript: true,
      hasAnalytics: true
    }
  ];

  const filteredRecordings = allRecordings.filter(recording => {
    const matchesSearch = 
      recording.candidateName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      recording.position.toLowerCase().includes(searchQuery.toLowerCase()) ||
      recording.company.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = filterStatus === 'all' || recording.status.toLowerCase() === filterStatus.toLowerCase();
    const matchesType = filterType === 'all' || recording.type.toLowerCase() === filterType.toLowerCase();
    
    return matchesSearch && matchesStatus && matchesType;
  });

  const sortedRecordings = [...filteredRecordings].sort((a, b) => {
    switch (sortBy) {
      case 'recent':
        return new Date(b.interviewDate) - new Date(a.interviewDate);
      case 'oldest':
        return new Date(a.interviewDate) - new Date(b.interviewDate);
      case 'views':
        return b.views - a.views;
      case 'duration':
        return b.duration.localeCompare(a.duration);
      case 'name':
        return a.candidateName.localeCompare(b.candidateName);
      default:
        return 0;
    }
  });

  const stats = {
    total: allRecordings.length,
    available: allRecordings.filter(r => r.status === 'Available').length,
    processing: allRecordings.filter(r => r.status === 'Processing').length,
    archived: allRecordings.filter(r => r.status === 'Archived').length,
    totalSize: allRecordings.reduce((sum, r) => sum + parseFloat(r.size), 0).toFixed(1),
    totalDuration: allRecordings.reduce((sum, r) => {
      const [mins, secs] = r.duration.split(':').map(Number);
      return sum + mins * 60 + secs;
    }, 0)
  };

  const formatTotalDuration = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  };

  return (
    <div className="space-y-6">
      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Total Recordings</p>
              <p className="text-3xl font-bold text-slate-800">{stats.total}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">🎥</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Available</p>
              <p className="text-3xl font-bold text-green-600">{stats.available}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">✅</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Processing</p>
              <p className="text-3xl font-bold text-amber-600">{stats.processing}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-yellow-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">⏳</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Archived</p>
              <p className="text-3xl font-bold text-slate-600">{stats.archived}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-slate-500 to-slate-600 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">📦</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Total Storage</p>
              <p className="text-3xl font-bold text-indigo-600">{stats.totalSize} GB</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">💾</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Total Duration</p>
              <p className="text-2xl font-bold text-purple-600">{formatTotalDuration(stats.totalDuration)}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
              <span className="text-white text-2xl">⏱️</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <VideoRecordingsFilters
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        filterStatus={filterStatus}
        onStatusChange={setFilterStatus}
        filterType={filterType}
        onTypeChange={setFilterType}
        sortBy={sortBy}
        onSortChange={setSortBy}
      />

      {/* Recordings Grid */}
      {sortedRecordings.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sortedRecordings.map(recording => (
            <VideoRecordingCard
              key={recording.id}
              recording={recording}
              onPlay={onPlayRecording}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl p-12 text-center shadow-lg border border-slate-100">
          <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-4xl">🔍</span>
          </div>
          <h3 className="text-xl font-semibold text-slate-800 mb-2">No recordings found</h3>
          <p className="text-slate-600">Try adjusting your search or filters</p>
        </div>
      )}
    </div>
  );
}
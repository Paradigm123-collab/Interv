import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import DashboardFooter from '../components/dashboard/DashboardFooter';
import EvaluationDashboard from '../components/evaluation/EvaluationDashboard';
import EvaluationDetailView from '../components/evaluation/EvaluationDetailView';
import ErrorBoundary from '../components/common/ErrorBoundary';

export default function AIEvaluationPage() {
  const navigate = useNavigate();
  const [currentView, setCurrentView] = useState('dashboard');
  const [selectedEvaluation, setSelectedEvaluation] = useState(null);
  const [currentRole] = useState('employer');

  const handleViewEvaluation = (evaluation) => {
    setSelectedEvaluation(evaluation);
    setCurrentView('detail');
  };

  const handleBackToDashboard = () => {
    setCurrentView('dashboard');
    setSelectedEvaluation(null);
  };

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <DashboardHeader currentRole={currentRole} onRoleChange={() => {}} />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-slate-800 mb-2">AI Evaluation System</h1>
                <p className="text-slate-600">Automated interview analysis with intelligent feedback generation</p>
              </div>
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => navigate('/dashboard')}
                  className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium flex items-center space-x-2"
                >
                  <span>←</span>
                  <span>Back to Dashboard</span>
                </button>
              </div>
            </div>
          </div>

          {/* Content Area */}
          {currentView === 'dashboard' && (
            <EvaluationDashboard onViewEvaluation={handleViewEvaluation} />
          )}
          
          {currentView === 'detail' && selectedEvaluation && (
            <EvaluationDetailView 
              evaluation={selectedEvaluation} 
              onBack={handleBackToDashboard} 
            />
          )}
        </div>

        <DashboardFooter />
      </div>
    </ErrorBoundary>
  );
}
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import DashboardFooter from '../components/dashboard/DashboardFooter';
import BiasDetectionDashboard from '../components/bias/BiasDetectionDashboard';
import BiasDetailView from '../components/bias/BiasDetailView';
import QuestionBiasAnalyzer from '../components/bias/QuestionBiasAnalyzer';
import ErrorBoundary from '../components/common/ErrorBoundary';

export default function BiasDetectionPage() {
  const navigate = useNavigate();
  const [currentView, setCurrentView] = useState('dashboard');
  const [selectedAlert, setSelectedAlert] = useState(null);
  const [currentRole, setCurrentRole] = useState('employer');
  const [showQuestionAnalyzer, setShowQuestionAnalyzer] = useState(false);

  const handleViewAlert = (alert) => {
    setSelectedAlert(alert);
    setCurrentView('detail');
  };

  const handleBackToDashboard = () => {
    setCurrentView('dashboard');
    setSelectedAlert(null);
  };

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <DashboardHeader currentRole={currentRole} onRoleChange={setCurrentRole} />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-slate-800 mb-2">
                  Bias Detection & Mitigation
                </h1>
                <p className="text-slate-600">
                  AI-powered system to ensure fair and unbiased hiring practices
                </p>
              </div>
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => setShowQuestionAnalyzer(true)}
                  className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all duration-200 shadow-lg hover:shadow-xl font-medium flex items-center space-x-2 hover:scale-105 active:scale-95"
                >
                  <span>🔍</span>
                  <span>Analyze Question</span>
                </button>
                <button
                  onClick={() => navigate('/dashboard')}
                  className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium flex items-center space-x-2"
                >
                  <span>←</span>
                  <span>Back to Dashboard</span>
                </button>
              </div>
            </div>
          </div>

          {/* Content Area */}
          {currentView === 'dashboard' && (
            <BiasDetectionDashboard 
              onViewAlert={handleViewAlert}
              currentRole={currentRole}
            />
          )}
          
          {currentView === 'detail' && selectedAlert && (
            <BiasDetailView 
              alert={selectedAlert} 
              onBack={handleBackToDashboard}
              currentRole={currentRole}
            />
          )}

          {/* Question Analyzer Modal */}
          {showQuestionAnalyzer && (
            <QuestionBiasAnalyzer
              onClose={() => setShowQuestionAnalyzer(false)}
              currentRole={currentRole}
            />
          )}
        </div>

        <DashboardFooter />
      </div>
    </ErrorBoundary>
  );
}
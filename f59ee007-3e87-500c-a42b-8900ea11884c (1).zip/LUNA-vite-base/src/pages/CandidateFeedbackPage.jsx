import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import DashboardFooter from '../components/dashboard/DashboardFooter';
import FeedbackSubmissionForm from '../components/feedback/FeedbackSubmissionForm';
import FeedbackHistory from '../components/feedback/FeedbackHistory';
import FeedbackAnalytics from '../components/feedback/FeedbackAnalytics';
import ErrorBoundary from '../components/common/ErrorBoundary';

export default function CandidateFeedbackPage() {
  const navigate = useNavigate();
  const [currentRole] = useState('candidate');
  const [activeView, setActiveView] = useState('submit');

  const views = [
    { id: 'submit', label: 'Submit Feedback', icon: '✍️' },
    { id: 'history', label: 'My Feedback', icon: '📋' },
    { id: 'analytics', label: 'Platform Insights', icon: '📊' }
  ];

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <DashboardHeader currentRole={currentRole} onRoleChange={() => {}} />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-slate-800 mb-2">Candidate Feedback Portal</h1>
                <p className="text-slate-600">Share your interview experience and help us improve</p>
              </div>
              <button
                onClick={() => navigate('/dashboard')}
                className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium flex items-center space-x-2 hover:scale-105 active:scale-95"
              >
                <span>←</span>
                <span>Back to Dashboard</span>
              </button>
            </div>
          </div>

          {/* View Tabs */}
          <div className="bg-white rounded-xl shadow-lg border border-slate-100 mb-6 overflow-x-auto">
            <div className="flex space-x-1 p-2 min-w-max">
              {views.map((view) => (
                <button
                  key={view.id}
                  onClick={() => setActiveView(view.id)}
                  className={`px-6 py-3 rounded-lg font-medium transition-all duration-200 flex items-center space-x-2 whitespace-nowrap ${
                    activeView === view.id
                      ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <span>{view.icon}</span>
                  <span>{view.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Content Area */}
          <div className="space-y-6">
            {activeView === 'submit' && <FeedbackSubmissionForm />}
            {activeView === 'history' && <FeedbackHistory />}
            {activeView === 'analytics' && <FeedbackAnalytics />}
          </div>
        </div>

        <DashboardFooter />
      </div>
    </ErrorBoundary>
  );
}
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import DashboardFooter from '../components/dashboard/DashboardFooter';
import CandidateProfileHeader from '../components/profile/candidate/CandidateProfileHeader';
import CandidatePersonalInfo from '../components/profile/candidate/CandidatePersonalInfo';
import CandidateDocuments from '../components/profile/candidate/CandidateDocuments';
import CandidateWorkHistory from '../components/profile/candidate/CandidateWorkHistory';
import CandidateEducation from '../components/profile/candidate/CandidateEducation';
import CandidateSkills from '../components/profile/candidate/CandidateSkills';
import CandidateApplications from '../components/profile/candidate/CandidateApplications';
import CandidateInterviewHistory from '../components/profile/candidate/CandidateInterviewHistory';
import ErrorBoundary from '../components/common/ErrorBoundary';

export default function CandidateProfilePage() {
  const navigate = useNavigate();
  const [currentRole] = useState('candidate');
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', label: 'Overview', icon: '👤' },
    { id: 'documents', label: 'Documents', icon: '📄' },
    { id: 'experience', label: 'Experience', icon: '💼' },
    { id: 'education', label: 'Education', icon: '🎓' },
    { id: 'skills', label: 'Skills', icon: '⚡' },
    { id: 'applications', label: 'Applications', icon: '📋' },
    { id: 'interviews', label: 'Interviews', icon: '🎥' }
  ];

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <DashboardHeader currentRole={currentRole} onRoleChange={() => {}} />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <CandidateProfileHeader />

          {/* Tab Navigation */}
          <div className="bg-white rounded-xl shadow-lg border border-slate-100 mb-6 overflow-x-auto">
            <div className="flex space-x-1 p-2 min-w-max">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-6 py-3 rounded-lg font-medium transition-all duration-200 flex items-center space-x-2 whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <span>{tab.icon}</span>
                  <span>{tab.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Tab Content */}
          <div className="space-y-6">
            {activeTab === 'overview' && (
              <>
                <CandidatePersonalInfo />
                <CandidateSkills />
              </>
            )}
            
            {activeTab === 'documents' && <CandidateDocuments />}
            
            {activeTab === 'experience' && <CandidateWorkHistory />}
            
            {activeTab === 'education' && <CandidateEducation />}
            
            {activeTab === 'skills' && <CandidateSkills />}
            
            {activeTab === 'applications' && <CandidateApplications />}
            
            {activeTab === 'interviews' && <CandidateInterviewHistory />}
          </div>
        </div>

        <DashboardFooter />
      </div>
    </ErrorBoundary>
  );
}
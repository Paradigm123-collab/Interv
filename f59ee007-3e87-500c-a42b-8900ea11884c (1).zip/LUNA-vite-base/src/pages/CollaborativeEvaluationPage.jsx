import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import DashboardFooter from '../components/dashboard/DashboardFooter';
import CollaborativeWorkspace from '../components/collaborative/CollaborativeWorkspace';
import CandidateSelectionPanel from '../components/collaborative/CandidateSelectionPanel';
import ErrorBoundary from '../components/common/ErrorBoundary';

export default function CollaborativeEvaluationPage() {
  const navigate = useNavigate();
  const [currentRole] = useState('employer');
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [viewMode, setViewMode] = useState('workspace');

  const handleCandidateSelect = (candidate) => {
    setSelectedCandidate(candidate);
    setViewMode('workspace');
  };

  const handleBackToSelection = () => {
    setViewMode('selection');
    setSelectedCandidate(null);
  };

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <DashboardHeader currentRole={currentRole} onRoleChange={() => {}} />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-slate-800 mb-2">
                  🤝 Collaborative Evaluation Workspace
                </h1>
                <p className="text-slate-600">
                  Work together with your team to evaluate candidates and make hiring decisions
                </p>
              </div>
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => navigate('/dashboard')}
                  className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium flex items-center space-x-2"
                >
                  <span>←</span>
                  <span>Back to Dashboard</span>
                </button>
              </div>
            </div>
          </div>

          {/* Content Area */}
          {viewMode === 'selection' || !selectedCandidate ? (
            <CandidateSelectionPanel onSelectCandidate={handleCandidateSelect} />
          ) : (
            <CollaborativeWorkspace 
              candidate={selectedCandidate}
              onBack={handleBackToSelection}
            />
          )}
        </div>

        <DashboardFooter />
      </div>
    </ErrorBoundary>
  );
}
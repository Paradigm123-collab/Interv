import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import DashboardFooter from '../components/dashboard/DashboardFooter';
import ComplianceDashboard from '../components/compliance/ComplianceDashboard';
import AuditTrailViewer from '../components/compliance/AuditTrailViewer';
import ComplianceRulesManager from '../components/compliance/ComplianceRulesManager';
import ComplianceReportGenerator from '../components/compliance/ComplianceReportGenerator';
import ErrorBoundary from '../components/common/ErrorBoundary';

export default function CompliancePage() {
  const navigate = useNavigate();
  const [currentView, setCurrentView] = useState('dashboard');
  const [currentRole, setCurrentRole] = useState('admin');

  const handleViewAuditTrail = () => {
    setCurrentView('audit');
  };

  const handleManageRules = () => {
    setCurrentView('rules');
  };

  const handleGenerateReport = () => {
    setCurrentView('report');
  };

  const handleBackToDashboard = () => {
    setCurrentView('dashboard');
  };

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <DashboardHeader currentRole={currentRole} onRoleChange={setCurrentRole} />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-slate-800 mb-2">
                  🔒 Compliance & Audit Trail
                </h1>
                <p className="text-slate-600">
                  Comprehensive compliance management and detailed activity tracking
                </p>
              </div>
              {currentView === 'dashboard' && (
                <button
                  onClick={() => navigate('/dashboard')}
                  className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium flex items-center space-x-2"
                >
                  <span>←</span>
                  <span>Back to Dashboard</span>
                </button>
              )}
            </div>
          </div>

          {/* Content Area */}
          {currentView === 'dashboard' && (
            <ComplianceDashboard
              onViewAuditTrail={handleViewAuditTrail}
              onManageRules={handleManageRules}
              onGenerateReport={handleGenerateReport}
            />
          )}

          {currentView === 'audit' && (
            <AuditTrailViewer onBack={handleBackToDashboard} />
          )}

          {currentView === 'rules' && (
            <ComplianceRulesManager onBack={handleBackToDashboard} />
          )}

          {currentView === 'report' && (
            <ComplianceReportGenerator onBack={handleBackToDashboard} />
          )}
        </div>

        <DashboardFooter />
      </div>
    </ErrorBoundary>
  );
}
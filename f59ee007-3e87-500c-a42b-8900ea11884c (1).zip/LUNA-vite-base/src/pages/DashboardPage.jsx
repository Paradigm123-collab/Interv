import { useState } from 'react';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import DashboardHero from '../components/dashboard/DashboardHero';
import RoleDashboard from '../components/dashboard/RoleDashboard';
import QuickActions from '../components/dashboard/QuickActions';
import RecentActivity from '../components/dashboard/RecentActivity';
import DashboardFooter from '../components/dashboard/DashboardFooter';
import ErrorBoundary from '../components/common/ErrorBoundary';

function DashboardPage() {
  const [currentRole, setCurrentRole] = useState('employer');

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <DashboardHeader currentRole={currentRole} onRoleChange={setCurrentRole} />
        <DashboardHero currentRole={currentRole} />
        <RoleDashboard currentRole={currentRole} />
        <QuickActions currentRole={currentRole} />
        <RecentActivity currentRole={currentRole} />
        <DashboardFooter />
      </div>
    </ErrorBoundary>
  );
}

export default DashboardPage;
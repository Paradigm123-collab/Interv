import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import DashboardFooter from '../components/dashboard/DashboardFooter';
import EmployerCandidateSearch from '../components/profile/employer/EmployerCandidateSearch';
import EmployerCandidateDetail from '../components/profile/employer/EmployerCandidateDetail';
import ErrorBoundary from '../components/common/ErrorBoundary';

export default function EmployerCandidateSearchPage() {
  const navigate = useNavigate();
  const { candidateId } = useParams();
  const [currentRole] = useState('employer');
  const [selectedCandidate, setSelectedCandidate] = useState(null);

  const handleViewCandidate = (candidate) => {
    setSelectedCandidate(candidate);
    navigate(`/employer/candidates/${candidate.id}`);
  };

  const handleBackToSearch = () => {
    setSelectedCandidate(null);
    navigate('/employer/candidates');
  };

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <DashboardHeader currentRole={currentRole} onRoleChange={() => {}} />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {!candidateId && !selectedCandidate ? (
            <EmployerCandidateSearch onViewCandidate={handleViewCandidate} />
          ) : (
            <EmployerCandidateDetail 
              candidate={selectedCandidate} 
              onBack={handleBackToSearch}
            />
          )}
        </div>

        <DashboardFooter />
      </div>
    </ErrorBoundary>
  );
}
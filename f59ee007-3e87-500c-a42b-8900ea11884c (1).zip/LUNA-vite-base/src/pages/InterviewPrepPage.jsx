import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import DashboardFooter from '../components/dashboard/DashboardFooter';
import PrepResourceLibrary from '../components/prep/PrepResourceLibrary';
import PrepMockInterview from '../components/prep/PrepMockInterview';
import PrepProgressTracker from '../components/prep/PrepProgressTracker';
import PrepRecommendations from '../components/prep/PrepRecommendations';
import ErrorBoundary from '../components/common/ErrorBoundary';

export default function InterviewPrepPage() {
  const navigate = useNavigate();
  const [currentRole] = useState('candidate');
  const [activeTab, setActiveTab] = useState('resources');

  const tabs = [
    { id: 'resources', label: 'Resource Library', icon: '📚' },
    { id: 'mock', label: 'Mock Interviews', icon: '🎯' },
    { id: 'progress', label: 'My Progress', icon: '📊' },
    { id: 'recommendations', label: 'Recommendations', icon: '💡' }
  ];

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <DashboardHeader currentRole={currentRole} onRoleChange={() => {}} />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-slate-800 mb-2">
                  🎓 Interview Preparation Center
                </h1>
                <p className="text-slate-600">
                  Master your interview skills with AI-powered practice and comprehensive resources
                </p>
              </div>
              <button
                onClick={() => navigate('/dashboard')}
                className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium flex items-center space-x-2"
              >
                <span>←</span>
                <span>Back to Dashboard</span>
              </button>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="bg-white rounded-xl shadow-lg border border-slate-100 mb-6 overflow-x-auto">
            <div className="flex space-x-1 p-2 min-w-max">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-6 py-3 rounded-lg font-medium transition-all duration-200 flex items-center space-x-2 whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <span>{tab.icon}</span>
                  <span>{tab.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Tab Content */}
          <div className="space-y-6">
            {activeTab === 'resources' && <PrepResourceLibrary />}
            {activeTab === 'mock' && <PrepMockInterview />}
            {activeTab === 'progress' && <PrepProgressTracker />}
            {activeTab === 'recommendations' && <PrepRecommendations />}
          </div>
        </div>

        <DashboardFooter />
      </div>
    </ErrorBoundary>
  );
}
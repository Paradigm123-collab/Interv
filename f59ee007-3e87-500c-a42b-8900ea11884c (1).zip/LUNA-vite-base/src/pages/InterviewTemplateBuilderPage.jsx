import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import DashboardFooter from '../components/dashboard/DashboardFooter';
import TemplateBuilderDashboard from '../components/template/TemplateBuilderDashboard';
import TemplateBuilderWizard from '../components/template/TemplateBuilderWizard';
import TemplateDetailView from '../components/template/TemplateDetailView';
import ErrorBoundary from '../components/common/ErrorBoundary';

export default function InterviewTemplateBuilderPage() {
  const navigate = useNavigate();
  const [currentView, setCurrentView] = useState('dashboard');
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [currentRole] = useState('employer');

  const handleCreateTemplate = () => {
    setSelectedTemplate(null);
    setCurrentView('wizard');
  };

  const handleViewTemplate = (template) => {
    setSelectedTemplate(template);
    setCurrentView('detail');
  };

  const handleEditTemplate = (template) => {
    setSelectedTemplate(template);
    setCurrentView('wizard');
  };

  const handleBackToDashboard = () => {
    setCurrentView('dashboard');
    setSelectedTemplate(null);
  };

  const handleTemplateSaved = (template) => {
    setCurrentView('dashboard');
    const message = document.createElement('div');
    message.className = 'fixed top-20 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
    message.innerHTML = `
      <div class="flex items-center space-x-3">
        <span class="text-xl">✅</span>
        <div>
          <p class="font-semibold">Template Saved Successfully!</p>
          <p class="text-sm opacity-90">${template.name} is ready to use</p>
        </div>
      </div>
    `;
    document.body.appendChild(message);
    setTimeout(() => message.remove(), 3000);
  };

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <DashboardHeader currentRole={currentRole} onRoleChange={() => {}} />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-slate-800 mb-2">Interview Template Builder</h1>
                <p className="text-slate-600">Create and manage standardized interview formats for consistent evaluation</p>
              </div>
              {currentView === 'dashboard' && (
                <button
                  onClick={handleCreateTemplate}
                  className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl font-medium flex items-center space-x-2 hover:scale-105 active:scale-95"
                >
                  <span className="text-xl">➕</span>
                  <span>Create Template</span>
                </button>
              )}
            </div>
          </div>

          {currentView === 'dashboard' && (
            <TemplateBuilderDashboard 
              onCreateTemplate={handleCreateTemplate}
              onViewTemplate={handleViewTemplate}
              onEditTemplate={handleEditTemplate}
            />
          )}

          {currentView === 'wizard' && (
            <TemplateBuilderWizard
              template={selectedTemplate}
              onBack={handleBackToDashboard}
              onSave={handleTemplateSaved}
            />
          )}

          {currentView === 'detail' && selectedTemplate && (
            <TemplateDetailView
              template={selectedTemplate}
              onBack={handleBackToDashboard}
              onEdit={handleEditTemplate}
            />
          )}
        </div>

        <DashboardFooter />
      </div>
    </ErrorBoundary>
  );
}
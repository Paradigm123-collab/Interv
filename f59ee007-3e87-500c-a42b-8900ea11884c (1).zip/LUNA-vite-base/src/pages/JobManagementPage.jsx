import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import DashboardFooter from '../components/dashboard/DashboardFooter';
import JobListView from '../components/jobs/JobListView';
import JobCreateForm from '../components/jobs/JobCreateForm';
import JobDetailView from '../components/jobs/JobDetailView';
import ErrorBoundary from '../components/common/ErrorBoundary';

export default function JobManagementPage() {
  const navigate = useNavigate();
  const [currentView, setCurrentView] = useState('list'); // 'list', 'create', 'detail'
  const [selectedJob, setSelectedJob] = useState(null);
  const [currentRole] = useState('employer');

  const handleCreateJob = () => {
    setCurrentView('create');
  };

  const handleViewJob = (job) => {
    setSelectedJob(job);
    setCurrentView('detail');
  };

  const handleBackToList = () => {
    setCurrentView('list');
    setSelectedJob(null);
  };

  const handleJobCreated = (newJob) => {
    setCurrentView('list');
    // Show success message
    const message = document.createElement('div');
    message.className = 'fixed top-20 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
    message.textContent = `Job "${newJob.title}" created successfully!`;
    document.body.appendChild(message);
    setTimeout(() => message.remove(), 3000);
  };

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <DashboardHeader currentRole={currentRole} onRoleChange={() => {}} />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-slate-800 mb-2">Job Management</h1>
                <p className="text-slate-600">Create, manage, and optimize your job postings with AI assistance</p>
              </div>
              {currentView === 'list' && (
                <button
                  onClick={handleCreateJob}
                  className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl font-medium flex items-center space-x-2 hover:scale-105 active:scale-95"
                >
                  <span className="text-xl">➕</span>
                  <span>Post New Job</span>
                </button>
              )}
            </div>
          </div>

          {/* Content Area */}
          {currentView === 'list' && (
            <JobListView onViewJob={handleViewJob} onCreateJob={handleCreateJob} />
          )}
          
          {currentView === 'create' && (
            <JobCreateForm onBack={handleBackToList} onJobCreated={handleJobCreated} />
          )}
          
          {currentView === 'detail' && selectedJob && (
            <JobDetailView job={selectedJob} onBack={handleBackToList} />
          )}
        </div>

        <DashboardFooter />
      </div>
    </ErrorBoundary>
  );
}
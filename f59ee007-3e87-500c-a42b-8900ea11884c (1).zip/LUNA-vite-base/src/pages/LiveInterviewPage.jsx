import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import DashboardFooter from '../components/dashboard/DashboardFooter';
import VideoConference from '../components/interview/VideoConference';
import CodingEditor from '../components/interview/CodingEditor';
import TranscriptionPanel from '../components/interview/TranscriptionPanel';
import AIMonitoringPanel from '../components/interview/AIMonitoringPanel';
import InterviewControls from '../components/interview/InterviewControls';
import ErrorBoundary from '../components/common/ErrorBoundary';

export default function LiveInterviewPage() {
  const navigate = useNavigate();
  const { interviewId } = useParams();
  const [currentRole] = useState('employer');
  const [interviewData, setInterviewData] = useState(null);
  const [isRecording, setIsRecording] = useState(false);
  const [showCodingEditor, setShowCodingEditor] = useState(false);
  const [showTranscription, setShowTranscription] = useState(true);
  const [showAIMonitoring, setShowAIMonitoring] = useState(true);
  const [interviewStatus, setInterviewStatus] = useState('waiting');

  useEffect(() => {
    const mockInterview = {
      id: interviewId || '1',
      candidate: {
        name: 'Sarah Mitchell',
        email: 'sarah.mitchell@email.com',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
        position: 'Senior React Developer'
      },
      interviewer: {
        name: 'John Anderson',
        email: 'john.anderson@company.com',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop'
      },
      type: 'Human',
      scheduledTime: '2:00 PM',
      duration: 45,
      company: 'TechCorp Solutions'
    };
    setInterviewData(mockInterview);
  }, [interviewId]);

  const handleStartInterview = () => {
    setInterviewStatus('active');
    setIsRecording(true);
    
    const message = document.createElement('div');
    message.className = 'fixed top-20 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
    message.innerHTML = `
      <div class="flex items-center space-x-3">
        <span class="text-xl">🎥</span>
        <div>
          <p class="font-semibold">Interview Started!</p>
          <p class="text-sm opacity-90">Recording and AI monitoring active</p>
        </div>
      </div>
    `;
    document.body.appendChild(message);
    setTimeout(() => message.remove(), 3000);
  };

  const handleEndInterview = () => {
    if (confirm('Are you sure you want to end this interview? All recordings will be saved.')) {
      setInterviewStatus('completed');
      setIsRecording(false);
      
      const message = document.createElement('div');
      message.className = 'fixed top-20 right-4 bg-indigo-600 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
      message.innerHTML = `
        <div class="flex items-center space-x-3">
          <span class="text-xl">✅</span>
          <div>
            <p class="font-semibold">Interview Completed!</p>
            <p class="text-sm opacity-90">Generating AI feedback report...</p>
          </div>
        </div>
      `;
      document.body.appendChild(message);
      
      setTimeout(() => {
        message.remove();
        navigate('/dashboard');
      }, 3000);
    }
  };

  if (!interviewData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-600">Loading interview...</p>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <DashboardHeader currentRole={currentRole} onRoleChange={() => {}} />
        
        <div className="max-w-[1920px] mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {/* Interview Header */}
          <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100 mb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-3">
                  <img
                    src={interviewData.candidate.avatar}
                    alt={interviewData.candidate.name}
                    className="w-12 h-12 rounded-full border-2 border-indigo-200"
                  />
                  <div>
                    <h2 className="text-xl font-bold text-slate-800">{interviewData.candidate.name}</h2>
                    <p className="text-sm text-slate-600">{interviewData.candidate.position}</p>
                  </div>
                </div>
                <div className="h-8 w-px bg-slate-200"></div>
                <div className="flex items-center space-x-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    interviewStatus === 'waiting' ? 'bg-amber-100 text-amber-800' :
                    interviewStatus === 'active' ? 'bg-green-100 text-green-800' :
                    'bg-blue-100 text-blue-800'
                  }`}>
                    {interviewStatus === 'waiting' ? '⏳ Waiting' :
                     interviewStatus === 'active' ? '🔴 Live' :
                     '✅ Completed'}
                  </span>
                  {isRecording && (
                    <span className="px-3 py-1 bg-red-100 text-red-800 rounded-full text-xs font-medium flex items-center space-x-1">
                      <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
                      <span>Recording</span>
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <button
                  onClick={() => setShowCodingEditor(!showCodingEditor)}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    showCodingEditor
                      ? 'bg-indigo-600 text-white'
                      : 'bg-white text-slate-700 border-2 border-slate-200 hover:border-indigo-300'
                  }`}
                >
                  💻 Coding Test
                </button>
                <button
                  onClick={() => setShowTranscription(!showTranscription)}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    showTranscription
                      ? 'bg-indigo-600 text-white'
                      : 'bg-white text-slate-700 border-2 border-slate-200 hover:border-indigo-300'
                  }`}
                >
                  📝 Transcription
                </button>
                <button
                  onClick={() => setShowAIMonitoring(!showAIMonitoring)}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    showAIMonitoring
                      ? 'bg-indigo-600 text-white'
                      : 'bg-white text-slate-700 border-2 border-slate-200 hover:border-indigo-300'
                  }`}
                >
                  🤖 AI Monitor
                </button>
              </div>
            </div>
          </div>

          {/* Main Interview Area */}
          <div className="grid grid-cols-12 gap-6">
            {/* Video Conference Area */}
            <div className={`${showCodingEditor ? 'col-span-6' : 'col-span-8'}`}>
              <VideoConference
                interviewData={interviewData}
                isRecording={isRecording}
                interviewStatus={interviewStatus}
              />
            </div>

            {/* Coding Editor (Conditional) */}
            {showCodingEditor && (
              <div className="col-span-6">
                <CodingEditor />
              </div>
            )}

            {/* Side Panels */}
            <div className="col-span-4 space-y-6">
              {showTranscription && (
                <TranscriptionPanel isActive={interviewStatus === 'active'} />
              )}
              
              {showAIMonitoring && (
                <AIMonitoringPanel isActive={interviewStatus === 'active'} />
              )}
            </div>
          </div>

          {/* Interview Controls */}
          <InterviewControls
            interviewStatus={interviewStatus}
            isRecording={isRecording}
            onStart={handleStartInterview}
            onEnd={handleEndInterview}
            onToggleRecording={() => setIsRecording(!isRecording)}
          />
        </div>

        <DashboardFooter />
      </div>
    </ErrorBoundary>
  );
}
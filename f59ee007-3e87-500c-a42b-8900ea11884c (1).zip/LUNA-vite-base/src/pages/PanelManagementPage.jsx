import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import DashboardFooter from '../components/dashboard/DashboardFooter';
import PanelManagementDashboard from '../components/panel/PanelManagementDashboard';
import ErrorBoundary from '../components/common/ErrorBoundary';

export default function PanelManagementPage() {
  const navigate = useNavigate();
  const [currentRole] = useState('admin');

  const handleViewPanelist = (panelist) => {
    alert(`Panelist Profile:\n\nName: ${panelist.name}\nRole: ${panelist.role}\nSpecialty: ${panelist.specialty}\nRating: ${panelist.rating}\nTotal Interviews: ${panelist.totalInterviews}\n\nDetailed profile view will be available with backend integration!`);
  };

  const handleAddPanelist = () => {
    alert('Add New Panelist:\n\nPanelist onboarding form will be available with backend integration!\n\nFeatures:\n- Personal information\n- Expertise areas\n- Availability settings\n- Payment details\n- Background verification');
  };

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <DashboardHeader currentRole={currentRole} onRoleChange={() => {}} />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-slate-800 mb-2">
                  👥 Panel Management
                </h1>
                <p className="text-slate-600">
                  Manage your interview panel members and track their performance
                </p>
              </div>
              <button
                onClick={() => navigate('/dashboard')}
                className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium flex items-center space-x-2"
              >
                <span>←</span>
                <span>Back to Dashboard</span>
              </button>
            </div>
          </div>

          {/* Content Area */}
          <PanelManagementDashboard
            onViewPanelist={handleViewPanelist}
            onAddPanelist={handleAddPanelist}
          />
        </div>

        <DashboardFooter />
      </div>
    </ErrorBoundary>
  );
}
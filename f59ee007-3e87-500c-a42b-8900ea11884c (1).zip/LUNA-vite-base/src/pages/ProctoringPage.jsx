import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import DashboardFooter from '../components/dashboard/DashboardFooter';
import ProctoringDashboard from '../components/proctoring/ProctoringDashboard';
import ProctoringSessionView from '../components/proctoring/ProctoringSessionView';
import ErrorBoundary from '../components/common/ErrorBoundary';

export default function ProctoringPage() {
  const navigate = useNavigate();
  const [currentView, setCurrentView] = useState('dashboard');
  const [selectedSession, setSelectedSession] = useState(null);
  const [currentRole] = useState('admin');

  const handleViewSession = (session) => {
    setSelectedSession(session);
    setCurrentView('session');
  };

  const handleViewAlert = (alert) => {
    alert(`Alert Details:\n\nType: ${alert.type}\nSeverity: ${alert.severity}\nCandidate: ${alert.candidateName}\nMessage: ${alert.message}\n\nDetailed alert management will be available with backend integration!`);
  };

  const handleBackToDashboard = () => {
    setCurrentView('dashboard');
    setSelectedSession(null);
  };

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <DashboardHeader currentRole={currentRole} onRoleChange={() => {}} />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-slate-800 mb-2">
                  🎥 AI Proctoring System
                </h1>
                <p className="text-slate-600">
                  Real-time monitoring and integrity analysis for all interviews
                </p>
              </div>
              {currentView === 'dashboard' && (
                <button
                  onClick={() => navigate('/dashboard')}
                  className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium flex items-center space-x-2"
                >
                  <span>←</span>
                  <span>Back to Dashboard</span>
                </button>
              )}
            </div>
          </div>

          {/* Content Area */}
          {currentView === 'dashboard' && (
            <ProctoringDashboard
              onViewSession={handleViewSession}
              onViewAlert={handleViewAlert}
            />
          )}

          {currentView === 'session' && selectedSession && (
            <ProctoringSessionView
              session={selectedSession}
              onBack={handleBackToDashboard}
            />
          )}
        </div>

        <DashboardFooter />
      </div>
    </ErrorBoundary>
  );
}
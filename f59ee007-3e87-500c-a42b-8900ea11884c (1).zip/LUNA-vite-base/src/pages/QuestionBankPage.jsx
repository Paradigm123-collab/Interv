import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import DashboardFooter from '../components/dashboard/DashboardFooter';
import QuestionBankList from '../components/questionbank/QuestionBankList';
import QuestionBankFilters from '../components/questionbank/QuestionBankFilters';
import QuestionBankCreateModal from '../components/questionbank/QuestionBankCreateModal';
import QuestionBankDetailView from '../components/questionbank/QuestionBankDetailView';
import ErrorBoundary from '../components/common/ErrorBoundary';

export default function QuestionBankPage() {
  const navigate = useNavigate();
  const [currentRole] = useState('employer');
  const [currentView, setCurrentView] = useState('list');
  const [selectedQuestion, setSelectedQuestion] = useState(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [filters, setFilters] = useState({
    search: '',
    role: 'all',
    skill: 'all',
    difficulty: 'all',
    category: 'all'
  });

  const handleViewQuestion = (question) => {
    setSelectedQuestion(question);
    setCurrentView('detail');
  };

  const handleBackToList = () => {
    setCurrentView('list');
    setSelectedQuestion(null);
  };

  const handleCreateQuestion = (newQuestion) => {
    setShowCreateModal(false);
    const message = document.createElement('div');
    message.className = 'fixed top-20 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
    message.textContent = `Question "${newQuestion.title}" created successfully!`;
    document.body.appendChild(message);
    setTimeout(() => message.remove(), 3000);
  };

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <DashboardHeader currentRole={currentRole} onRoleChange={() => {}} />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-slate-800 mb-2">Interview Question Bank</h1>
                <p className="text-slate-600">Manage and organize your interview questions with AI-powered suggestions</p>
              </div>
              {currentView === 'list' && (
                <button
                  onClick={() => setShowCreateModal(true)}
                  className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl font-medium flex items-center space-x-2 hover:scale-105 active:scale-95"
                >
                  <span className="text-xl">➕</span>
                  <span>Create Question</span>
                </button>
              )}
            </div>
          </div>

          {currentView === 'list' && (
            <>
              <QuestionBankFilters filters={filters} onFilterChange={setFilters} />
              <QuestionBankList 
                filters={filters} 
                onViewQuestion={handleViewQuestion}
                currentRole={currentRole}
              />
            </>
          )}

          {currentView === 'detail' && selectedQuestion && (
            <QuestionBankDetailView 
              question={selectedQuestion} 
              onBack={handleBackToList}
              currentRole={currentRole}
            />
          )}

          {showCreateModal && (
            <QuestionBankCreateModal
              onClose={() => setShowCreateModal(false)}
              onSave={handleCreateQuestion}
              currentRole={currentRole}
            />
          )}
        </div>

        <DashboardFooter />
      </div>
    </ErrorBoundary>
  );
}
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import DashboardFooter from '../components/dashboard/DashboardFooter';
import SchedulingCalendar from '../components/scheduling/SchedulingCalendar';
import SchedulingList from '../components/scheduling/SchedulingList';
import ScheduleInterviewModal from '../components/scheduling/ScheduleInterviewModal';
import CalendarSyncPanel from '../components/scheduling/CalendarSyncPanel';
import ErrorBoundary from '../components/common/ErrorBoundary';

export default function SchedulingPage() {
  const navigate = useNavigate();
  const [currentView, setCurrentView] = useState('calendar');
  const [currentRole] = useState('employer');
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [selectedInterview, setSelectedInterview] = useState(null);
  const [showCalendarSync, setShowCalendarSync] = useState(false);

  const handleScheduleInterview = () => {
    setSelectedInterview(null);
    setShowScheduleModal(true);
  };

  const handleEditInterview = (interview) => {
    setSelectedInterview(interview);
    setShowScheduleModal(true);
  };

  const handleInterviewScheduled = (interviewData) => {
    setShowScheduleModal(false);
    
    const message = document.createElement('div');
    message.className = 'fixed top-20 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
    message.innerHTML = `
      <div class="flex items-center space-x-3">
        <span class="text-xl">✅</span>
        <div>
          <p class="font-semibold">Interview Scheduled Successfully!</p>
          <p class="text-sm opacity-90">Notifications sent to all participants</p>
        </div>
      </div>
    `;
    document.body.appendChild(message);
    setTimeout(() => message.remove(), 4000);
  };

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <DashboardHeader currentRole={currentRole} onRoleChange={() => {}} />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-slate-800 mb-2">Interview Scheduling</h1>
                <p className="text-slate-600">Manage AI and human interviews with smart calendar integration</p>
              </div>
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => setShowCalendarSync(true)}
                  className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium flex items-center space-x-2"
                >
                  <span>🔗</span>
                  <span>Sync Calendar</span>
                </button>
                <button
                  onClick={handleScheduleInterview}
                  className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl font-medium flex items-center space-x-2 hover:scale-105 active:scale-95"
                >
                  <span className="text-xl">📅</span>
                  <span>Schedule Interview</span>
                </button>
              </div>
            </div>
          </div>

          {/* View Toggle */}
          <div className="bg-white rounded-xl p-2 shadow-lg border border-slate-100 mb-6 inline-flex">
            <button
              onClick={() => setCurrentView('calendar')}
              className={`px-6 py-2 rounded-lg font-medium transition-all ${
                currentView === 'calendar'
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              📅 Calendar View
            </button>
            <button
              onClick={() => setCurrentView('list')}
              className={`px-6 py-2 rounded-lg font-medium transition-all ${
                currentView === 'list'
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              📋 List View
            </button>
          </div>

          {/* Content Area */}
          {currentView === 'calendar' ? (
            <SchedulingCalendar 
              onScheduleInterview={handleScheduleInterview}
              onEditInterview={handleEditInterview}
            />
          ) : (
            <SchedulingList 
              onScheduleInterview={handleScheduleInterview}
              onEditInterview={handleEditInterview}
            />
          )}
        </div>

        {/* Schedule Interview Modal */}
        {showScheduleModal && (
          <ScheduleInterviewModal
            interview={selectedInterview}
            onClose={() => setShowScheduleModal(false)}
            onSchedule={handleInterviewScheduled}
          />
        )}

        {/* Calendar Sync Panel */}
        {showCalendarSync && (
          <CalendarSyncPanel onClose={() => setShowCalendarSync(false)} />
        )}

        <DashboardFooter />
      </div>
    </ErrorBoundary>
  );
}
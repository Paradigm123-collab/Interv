import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import DashboardFooter from '../components/dashboard/DashboardFooter';
import SkillsAssessmentDashboard from '../components/skills/SkillsAssessmentDashboard';
import AssessmentBuilder from '../components/skills/AssessmentBuilder';
import AssessmentDetailView from '../components/skills/AssessmentDetailView';
import ErrorBoundary from '../components/common/ErrorBoundary';

export default function SkillsAssessmentPage() {
  const navigate = useNavigate();
  const [currentRole] = useState('employer');
  const [currentView, setCurrentView] = useState('dashboard');
  const [selectedAssessment, setSelectedAssessment] = useState(null);

  const handleCreateAssessment = () => {
    setSelectedAssessment(null);
    setCurrentView('builder');
  };

  const handleViewAssessment = (assessment) => {
    setSelectedAssessment(assessment);
    setCurrentView('detail');
  };

  const handleEditAssessment = (assessment) => {
    setSelectedAssessment(assessment);
    setCurrentView('builder');
  };

  const handleBackToDashboard = () => {
    setCurrentView('dashboard');
    setSelectedAssessment(null);
  };

  const handleAssessmentSaved = (assessment) => {
    setCurrentView('dashboard');
    const message = document.createElement('div');
    message.className = 'fixed top-20 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
    message.innerHTML = `
      <div class="flex items-center space-x-3">
        <span class="text-xl">✅</span>
        <div>
          <p class="font-semibold">Assessment Saved!</p>
          <p class="text-sm opacity-90">${assessment.title} is ready to use</p>
        </div>
      </div>
    `;
    document.body.appendChild(message);
    setTimeout(() => message.remove(), 3000);
  };

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <DashboardHeader currentRole={currentRole} onRoleChange={() => {}} />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-slate-800 mb-2">
                  🎯 Skills Assessment Center
                </h1>
                <p className="text-slate-600">
                  Create and manage skill tests to complement your video interviews
                </p>
              </div>
              {currentView === 'dashboard' && (
                <button
                  onClick={handleCreateAssessment}
                  className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl font-medium flex items-center space-x-2 hover:scale-105 active:scale-95"
                >
                  <span className="text-xl">➕</span>
                  <span>Create Assessment</span>
                </button>
              )}
            </div>
          </div>

          {currentView === 'dashboard' && (
            <SkillsAssessmentDashboard
              onCreateAssessment={handleCreateAssessment}
              onViewAssessment={handleViewAssessment}
              onEditAssessment={handleEditAssessment}
            />
          )}

          {currentView === 'builder' && (
            <AssessmentBuilder
              assessment={selectedAssessment}
              onBack={handleBackToDashboard}
              onSave={handleAssessmentSaved}
            />
          )}

          {currentView === 'detail' && selectedAssessment && (
            <AssessmentDetailView
              assessment={selectedAssessment}
              onBack={handleBackToDashboard}
              onEdit={handleEditAssessment}
            />
          )}
        </div>

        <DashboardFooter />
      </div>
    </ErrorBoundary>
  );
}
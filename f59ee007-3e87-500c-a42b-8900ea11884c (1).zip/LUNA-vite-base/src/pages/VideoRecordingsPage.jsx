import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import DashboardFooter from '../components/dashboard/DashboardFooter';
import VideoRecordingsList from '../components/video/VideoRecordingsList';
import VideoPlayerModal from '../components/video/VideoPlayerModal';
import ErrorBoundary from '../components/common/ErrorBoundary';

export default function VideoRecordingsPage() {
  const navigate = useNavigate();
  const [currentRole] = useState('employer');
  const [selectedRecording, setSelectedRecording] = useState(null);
  const [showPlayer, setShowPlayer] = useState(false);

  const handlePlayRecording = (recording) => {
    setSelectedRecording(recording);
    setShowPlayer(true);
  };

  const handleClosePlayer = () => {
    setShowPlayer(false);
    setSelectedRecording(null);
  };

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <DashboardHeader currentRole={currentRole} onRoleChange={() => {}} />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-slate-800 mb-2">
                  🎥 Video Recordings
                </h1>
                <p className="text-slate-600">
                  Access and review all interview recordings with professional playback controls
                </p>
              </div>
              <button
                onClick={() => navigate('/dashboard')}
                className="px-6 py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-slate-50 transition-all duration-200 font-medium flex items-center space-x-2"
              >
                <span>←</span>
                <span>Back to Dashboard</span>
              </button>
            </div>
          </div>

          {/* Recordings List */}
          <VideoRecordingsList 
            currentRole={currentRole}
            onPlayRecording={handlePlayRecording}
          />
        </div>

        {/* Video Player Modal */}
        {showPlayer && selectedRecording && (
          <VideoPlayerModal
            recording={selectedRecording}
            onClose={handleClosePlayer}
          />
        )}

        <DashboardFooter />
      </div>
    </ErrorBoundary>
  );
}